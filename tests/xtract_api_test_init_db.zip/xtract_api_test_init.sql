-- MySQL dump 10.13  Distrib 5.7.20, for macos10.12 (x86_64)
--
-- Host: localhost    Database: api_test1
-- ------------------------------------------------------
-- Server version	5.7.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_number` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `address_id` int(11) DEFAULT NULL,
  `bill_to` int(11) DEFAULT NULL,
  `ship_to` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `archived` varchar(5) DEFAULT 'F',
  `notes` text NOT NULL,
  `reference_number` varchar(128) NOT NULL,
  `account_status_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  KEY `address_id` (`address_id`),
  KEY `bill_to` (`bill_to`),
  KEY `ship_to` (`ship_to`),
  KEY `account_account_status_id_foreign` (`account_status_id`),
  CONSTRAINT `account_account_status_id_foreign` FOREIGN KEY (`account_status_id`) REFERENCES `account_status` (`account_status_id`),
  CONSTRAINT `account_ibfk_1` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`),
  CONSTRAINT `account_ibfk_2` FOREIGN KEY (`bill_to`) REFERENCES `address` (`address_id`),
  CONSTRAINT `account_ibfk_3` FOREIGN KEY (`ship_to`) REFERENCES `address` (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,'8812152a-78be-11e8-bfed-f74fa44981ad','Default customer',NULL,NULL,NULL,'2018-06-25 21:27:15',NULL,'2018-06-25 21:27:15',NULL,NULL,'F','','',NULL);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_status`
--

DROP TABLE IF EXISTS `account_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_status` (
  `account_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`account_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_status`
--

LOCK TABLES `account_status` WRITE;
/*!40000 ALTER TABLE `account_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accumulator`
--

DROP TABLE IF EXISTS `accumulator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accumulator` (
  `accumulator_id` int(11) NOT NULL AUTO_INCREMENT,
  `data` text,
  `type` varchar(45) DEFAULT NULL,
  `storeTime` datetime DEFAULT NULL,
  `processTime` datetime DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `destination` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`accumulator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accumulator`
--

LOCK TABLES `accumulator` WRITE;
/*!40000 ALTER TABLE `accumulator` DISABLE KEYS */;
/*!40000 ALTER TABLE `accumulator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `address_id` int(11) NOT NULL AUTO_INCREMENT,
  `address_line_1` varchar(64) NOT NULL,
  `address_line_2` varchar(64) DEFAULT NULL,
  `city` varchar(64) NOT NULL,
  `state` varchar(64) NOT NULL,
  `zip` varchar(32) DEFAULT NULL,
  `province` varchar(64) DEFAULT NULL,
  `country` varchar(64) DEFAULT NULL,
  `archived` varchar(5) DEFAULT 'F',
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allergyintolerance`
--

DROP TABLE IF EXISTS `allergyintolerance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allergyintolerance` (
  `AllergyIntolerance_id` int(11) NOT NULL AUTO_INCREMENT,
  `onset` datetime DEFAULT NULL,
  `recordedDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `reporter_id` int(11) DEFAULT NULL,
  `substance` varchar(64) NOT NULL,
  `status` varchar(16) DEFAULT NULL,
  `criticality` varchar(10) DEFAULT NULL,
  `type` varchar(16) DEFAULT NULL,
  `catagory` varchar(16) DEFAULT NULL,
  `lastOccurence` datetime DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`AllergyIntolerance_id`),
  KEY `fk_AllergyIntolerance_user_id` (`user_id`),
  KEY `fk_AllergyIntolerance_patient_id` (`patient_id`),
  CONSTRAINT `fk_AllergyIntolerance_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  CONSTRAINT `fk_AllergyIntolerance_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allergyintolerance`
--

LOCK TABLES `allergyintolerance` WRITE;
/*!40000 ALTER TABLE `allergyintolerance` DISABLE KEYS */;
/*!40000 ALTER TABLE `allergyintolerance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `answer` (
  `answer_id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `response` varchar(64) NOT NULL,
  `ask` varchar(16) NOT NULL,
  `comment` text,
  `date` datetime NOT NULL,
  `patient_id` int(11) NOT NULL,
  `reviewedby` varchar(45) DEFAULT NULL,
  `locked` varchar(5) NOT NULL DEFAULT 'F',
  `question_id` int(11) DEFAULT NULL,
  `questionnaire_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`answer_id`),
  KEY `patient_id` (`patient_id`),
  KEY `questionnaire_id` (`questionnaire_id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE,
  CONSTRAINT `answer_ibfk_2` FOREIGN KEY (`questionnaire_id`) REFERENCES `questionnaire` (`questionnaire_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `answer_ibfk_3` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
INSERT INTO `answer` VALUES (1,'multi answer question number 3','1,3','T','Nurses comment','2018-01-15 00:00:00',2,NULL,'F',3,1);
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `antigen`
--

DROP TABLE IF EXISTS `antigen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `antigen` (
  `antigen_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `compatibility_class_id` int(11) DEFAULT NULL,
  `clinic_part_number` varchar(32) NOT NULL DEFAULT '-',
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  `extract_id` int(11) DEFAULT NULL,
  `test_order` int(11) NOT NULL,
  `for_test_only` varchar(45) DEFAULT 'F',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`antigen_id`),
  KEY `extract_id` (`extract_id`),
  KEY `compatibility_class_id` (`compatibility_class_id`),
  CONSTRAINT `antigen_compatibility_class_ibfk_1` FOREIGN KEY (`compatibility_class_id`) REFERENCES `compatibility_class` (`compatibility_class_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `antigen_extract_ibfk_1` FOREIGN KEY (`extract_id`) REFERENCES `extract` (`extract_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `antigen_ibfk_1` FOREIGN KEY (`extract_id`) REFERENCES `extract` (`extract_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `antigen`
--

LOCK TABLES `antigen` WRITE;
/*!40000 ALTER TABLE `antigen` DISABLE KEYS */;
INSERT INTO `antigen` VALUES (1,'Glycerinated Diluent',NULL,'-','F',2,1,'F','2018-01-13 21:50:12'),(2,'HSA',NULL,'-','F',3,2,'F','2018-01-13 21:50:12'),(3,'Aqueous Dil',NULL,'-','F',4,3,'F','2018-01-13 21:50:12'),(4,'Elm-Chinese',NULL,'-','F',5,4,'F','2018-01-13 21:50:12'),(5,'Ragweed, Giant',3,'-','F',6,5,'F','2018-01-13 21:50:12'),(6,'Alternaria',NULL,'-','F',7,6,'F','2018-01-13 21:50:12'),(7,'Pine Mix',1,'-','F',8,7,'F','2018-01-13 21:50:12'),(8,'Timothy Grass',NULL,'-','F',9,8,'F','2018-01-13 21:50:12'),(9,'Candida Albicans',2,'-','F',10,9,'F','2018-01-13 21:50:12'),(10,'AP Dog',NULL,'-','F',11,10,'F','2018-01-13 21:50:13');
/*!40000 ALTER TABLE `antigen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `antigen_extract`
--

DROP TABLE IF EXISTS `antigen_extract`;
/*!50001 DROP VIEW IF EXISTS `antigen_extract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `antigen_extract` AS SELECT 
 1 AS `antigen_id`,
 1 AS `name`,
 1 AS `clinic_part_number`,
 1 AS `test_order`,
 1 AS `extract_id`,
 1 AS `latinname`,
 1 AS `manufacturer`,
 1 AS `code`,
 1 AS `ndc`,
 1 AS `abbreviation`,
 1 AS `visible`,
 1 AS `percentGlycerin`,
 1 AS `percentPhenol`,
 1 AS `percentHSA`,
 1 AS `dilution`,
 1 AS `units`,
 1 AS `cost`,
 1 AS `sub`,
 1 AS `specificgravity`,
 1 AS `outdatealert`,
 1 AS `compatibility_class_id`,
 1 AS `imagefile`,
 1 AS `isDiluent`,
 1 AS `silhouette`,
 1 AS `color`,
 1 AS `topline`,
 1 AS `firstline`,
 1 AS `secondline`,
 1 AS `seasonStart`,
 1 AS `seasonEnd`,
 1 AS `deleted`,
 1 AS `updated_at`,
 1 AS `updated_by`,
 1 AS `created_at`,
 1 AS `created_by`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `api_failure_queue`
--

DROP TABLE IF EXISTS `api_failure_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_failure_queue` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_failure_queue`
--

LOCK TABLES `api_failure_queue` WRITE;
/*!40000 ALTER TABLE `api_failure_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_failure_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_log`
--

DROP TABLE IF EXISTS `api_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_log` (
  `api_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(255) DEFAULT NULL,
  `method` varchar(16) DEFAULT NULL,
  `json_parameters` text,
  `requester_ip` varchar(32) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `response_code` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`api_log_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_api_log_user_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_log`
--

LOCK TABLES `api_log` WRITE;
/*!40000 ALTER TABLE `api_log` DISABLE KEYS */;
INSERT INTO `api_log` VALUES (1,'v1/patient/2/answer','POST','[{\"question_id\":\"3\",\"questionnaire_id\":\"1\",\"answer\":\"1,3\",\"nurse_comment\":\"Nurses comment\",\"ask\":\"T\"}]','127.0.0.1',NULL,200,'2018-01-15 14:44:40'),(2,'v1/patient/2/prescription','POST','{\"name\":\"Rx for set_order update tests\",\"multiplier\":1,\"clinic_id\":2,\"provider_id\":1,\"diagnosis_id\":4,\"profile_id\":1,\"extracts\":[{\"extract_id\":2,\"name\":\"Glycerinated Diluent\",\"is_diluent\":\"T\"},{\"extract_id\":7,\"name\":\"Alternaria\",\"is_diluent\":\"F\"}]}','127.0.0.1',2,200,'2018-10-08 13:24:50'),(3,'v1/patient/2/purchase_order','POST','{\"account_id\":1,\"set_orders\":[{\"name\":\"for set_order update tests\",\"note\":\"for set_order update tests\",\"provider_id\":1,\"prescription_id\":4,\"clinic_id\":2,\"size\":\"5 mL\",\"dilutions\":[1,2,10,100,200],\"dosings\":[{\"dose\":\"2.000\",\"ent_dilution\":0,\"extract_id\":2},{\"dose\":\"1.000\",\"ent_dilution\":0,\"extract_id\":4},{\"dose\":\"1.750\",\"ent_dilution\":0,\"extract_id\":8}]}]}','127.0.0.1',2,200,'2018-10-08 13:24:50');
/*!40000 ALTER TABLE `api_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_queue`
--

DROP TABLE IF EXISTS `api_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_queue` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `api_queue_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_queue`
--

LOCK TABLES `api_queue` WRITE;
/*!40000 ALTER TABLE `api_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_log`
--

DROP TABLE IF EXISTS `billing_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_log` (
  `billing_id` int(11) NOT NULL AUTO_INCREMENT,
  `billing_date` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `skintest_id` int(11) NOT NULL,
  `event` varchar(128) NOT NULL,
  `billing_code` varchar(32) NOT NULL,
  `diagnosis_code` varchar(32) NOT NULL,
  `num_units` decimal(8,2) NOT NULL,
  PRIMARY KEY (`billing_id`),
  KEY `user_id` (`user_id`),
  KEY `provider_id` (`provider_id`),
  KEY `patient_id` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_log`
--

LOCK TABLES `billing_log` WRITE;
/*!40000 ALTER TABLE `billing_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_incompatibility`
--

DROP TABLE IF EXISTS `class_incompatibility`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_incompatibility` (
  `class_id_1` int(11) NOT NULL,
  `class_id_2` int(11) NOT NULL,
  UNIQUE KEY `class_id_1` (`class_id_1`,`class_id_2`),
  CONSTRAINT `fk_antigen_compatibility_class_1` FOREIGN KEY (`class_id_1`) REFERENCES `compatibility_class` (`compatibility_class_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_incompatibility`
--

LOCK TABLES `class_incompatibility` WRITE;
/*!40000 ALTER TABLE `class_incompatibility` DISABLE KEYS */;
INSERT INTO `class_incompatibility` VALUES (1,2),(1,3),(2,1),(3,1);
/*!40000 ALTER TABLE `class_incompatibility` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clinic`
--

DROP TABLE IF EXISTS `clinic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clinic` (
  `clinic_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `name2` varchar(150) DEFAULT NULL,
  `abbreviation` varchar(45) DEFAULT NULL,
  `contact` varchar(45) DEFAULT NULL,
  `addr1` varchar(100) DEFAULT NULL,
  `addr2` varchar(100) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zip` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `fax` varchar(45) DEFAULT NULL,
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  `province` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `phone2` varchar(45) DEFAULT NULL,
  `nonXtract` varchar(45) NOT NULL DEFAULT 'F',
  `external_id` varchar(100) DEFAULT '',
  `account_id` int(11) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`clinic_id`),
  KEY `account_id` (`account_id`),
  KEY `address_id` (`address_id`),
  CONSTRAINT `clinic_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`),
  CONSTRAINT `clinic_ibfk_2` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clinic`
--

LOCK TABLES `clinic` WRITE;
/*!40000 ALTER TABLE `clinic` DISABLE KEYS */;
INSERT INTO `clinic` VALUES (1,'empty',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'T','','','','F',NULL,1,NULL),(2,'Xtract Solutions','','XS','Xtract Admin','9954 SW Arctic','','beaverton','OR','97005','(503) 379-0110','(503) 715-1378','F','','','','F','',1,NULL);
/*!40000 ALTER TABLE `clinic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compatibility_class`
--

DROP TABLE IF EXISTS `compatibility_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compatibility_class` (
  `compatibility_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`compatibility_class_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compatibility_class`
--

LOCK TABLES `compatibility_class` WRITE;
/*!40000 ALTER TABLE `compatibility_class` DISABLE KEYS */;
INSERT INTO `compatibility_class` VALUES (2,'Bacteria'),(3,'Grasses'),(1,'Trees');
/*!40000 ALTER TABLE `compatibility_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compound`
--

DROP TABLE IF EXISTS `compound`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compound` (
  `compound_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `inventory_scan` int(11) DEFAULT NULL,
  `dose_scan` int(11) DEFAULT NULL,
  `compound_note` text,
  `timestamp` timestamp NULL DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  `dilution` varchar(45) DEFAULT NULL,
  `bottleNum` varchar(45) DEFAULT NULL,
  `active` varchar(5) DEFAULT 'F',
  `currVol` decimal(5,2) DEFAULT '0.00',
  `rx_id` int(11) NOT NULL,
  `provider_config_id` int(11) DEFAULT '-1',
  `shipMethod` varchar(20) DEFAULT '',
  `shipWith` varchar(20) DEFAULT '',
  `tracking` varchar(50) DEFAULT '',
  `external_id` varchar(100) DEFAULT '',
  `DIN` varchar(20) DEFAULT '',
  `compound_receipt_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `treatment_set_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`compound_id`),
  KEY `fk_rx_id_idx` (`rx_id`),
  KEY `fk_compound_compound_receipt_id` (`compound_receipt_id`),
  KEY `treatment_set_id` (`treatment_set_id`),
  CONSTRAINT `compound_ibfk_1` FOREIGN KEY (`treatment_set_id`) REFERENCES `treatment_set` (`treatment_set_id`),
  CONSTRAINT `fk_compound_compound_receipt_id` FOREIGN KEY (`compound_receipt_id`) REFERENCES `compound_receipt` (`compound_receipt_id`),
  CONSTRAINT `fk_rx_id` FOREIGN KEY (`rx_id`) REFERENCES `prescription` (`prescription_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compound`
--

LOCK TABLES `compound` WRITE;
/*!40000 ALTER TABLE `compound` DISABLE KEYS */;
INSERT INTO `compound` VALUES (1,2,NULL,NULL,'','2018-01-13 21:50:45','5 mL','MLD\\TRS','RED','200','1','T',5.00,3,1,'','','','','',1,'2018-06-25 21:27:16',NULL,'2018-01-13 21:50:45',NULL,1),(2,2,NULL,NULL,'','2018-01-13 21:50:45','5 mL','MLD\\TRS','YLW','100','2','T',5.00,3,1,'','','','','',1,'2018-06-25 21:27:16',NULL,'2018-01-13 21:50:45',NULL,1),(3,2,NULL,NULL,'','2018-01-13 21:50:45','5 mL','MLD\\TRS','BLUE','10','3','T',5.00,3,1,'','','','','',1,'2018-06-25 21:27:16',NULL,'2018-01-13 21:50:45',NULL,1),(4,2,NULL,NULL,'','2018-01-13 21:50:45','5 mL','MLD\\TRS','GRN','2','4','T',5.00,3,1,'','','','','',1,'2018-06-25 21:27:16',NULL,'2018-01-13 21:50:45',NULL,1),(5,2,NULL,NULL,'','2018-01-13 21:50:45','5 mL','MLD\\TRS','SLVR','1','5','F',5.00,3,1,'','','','','',1,'2018-06-25 21:27:16',NULL,'2018-01-13 21:50:45',NULL,1),(6,2,NULL,NULL,'Note for remake','2018-06-03 16:30:55','10 mL','MLD\\TRS - remake','RED','200','1A','F',10.00,3,1,'','','','','',NULL,'2018-06-25 21:27:16',NULL,'2018-06-03 16:30:55',NULL,2),(7,2,NULL,NULL,'Note for remake','2018-06-03 16:30:55','10 mL','MLD\\TRS - remake','YLW','100','2A','F',10.00,3,1,'','','','','',NULL,'2018-06-25 21:27:16',NULL,'2018-06-03 16:30:55',NULL,2),(8,2,NULL,NULL,'Note for remake','2018-06-03 16:30:55','10 mL','MLD\\TRS - remake','BLUE','10','3A','F',10.00,3,1,'','','','','',NULL,'2018-06-25 21:27:16',NULL,'2018-06-03 16:30:55',NULL,2),(9,2,NULL,NULL,'for set_order update tests','2018-10-08 20:24:50','5 mL','for set_order update tests','RED','1','1','F',0.00,4,1,'','','','','',NULL,'2018-10-08 20:24:50',NULL,'2018-10-08 20:24:50',2,4),(10,2,NULL,NULL,'for set_order update tests','2018-10-08 20:24:50','5 mL','for set_order update tests','YLW','2','2','F',0.00,4,1,'','','','','',NULL,'2018-10-08 20:24:50',NULL,'2018-10-08 20:24:50',2,4),(11,2,NULL,NULL,'for set_order update tests','2018-10-08 20:24:50','5 mL','for set_order update tests','BLUE','10','3','F',0.00,4,1,'','','','','',NULL,'2018-10-08 20:24:50',NULL,'2018-10-08 20:24:50',2,4),(12,2,NULL,NULL,'for set_order update tests','2018-10-08 20:24:50','5 mL','for set_order update tests','GRN','100','4','F',0.00,4,1,'','','','','',NULL,'2018-10-08 20:24:50',NULL,'2018-10-08 20:24:50',2,4),(13,2,NULL,NULL,'for set_order update tests','2018-10-08 20:24:50','5 mL','for set_order update tests','SLVR','200','5','F',0.00,4,1,'','','','','',NULL,'2018-10-08 20:24:50',NULL,'2018-10-08 20:24:50',2,4);
/*!40000 ALTER TABLE `compound` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER auto_create_treatment_set BEFORE INSERT ON `compound`
    FOR EACH ROW BEGIN
      IF (NEW.treatment_set_id IS NULL) THEN
        insert into treatment_set (patient_id, provider_id, prescription_id, clinic_id, source, created_at) select patient_id, provider_id, prescription_id, clinic_id, 'AUTO', CURRENT_TIMESTAMP from prescription where prescription_id = NEW.rx_id;
          set NEW.treatment_set_id=last_insert_id();
      END IF;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `compound_non_xps`
--

DROP TABLE IF EXISTS `compound_non_xps`;
/*!50001 DROP VIEW IF EXISTS `compound_non_xps`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `compound_non_xps` AS SELECT 
 1 AS `compound_id`,
 1 AS `bottle_name`,
 1 AS `bottle_type`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `compound_receipt`
--

DROP TABLE IF EXISTS `compound_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compound_receipt` (
  `compound_receipt_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier` varchar(128) DEFAULT '',
  `external_rx_num` varchar(64) DEFAULT NULL,
  `note` text,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `compName` varchar(100) DEFAULT '',
  PRIMARY KEY (`compound_receipt_id`),
  KEY `fk_compound_receipt_created_by_user` (`created_by`),
  KEY `fk_compound_receipt_updated_by_user` (`updated_by`),
  CONSTRAINT `fk_compound_receipt_created_by_user` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_compound_receipt_updated_by_user` FOREIGN KEY (`updated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compound_receipt`
--

LOCK TABLES `compound_receipt` WRITE;
/*!40000 ALTER TABLE `compound_receipt` DISABLE KEYS */;
INSERT INTO `compound_receipt` VALUES (1,'Greer','12345','',2,'2018-02-06 19:02:52',2,'0000-00-00 00:00:00','127.0.0.1');
/*!40000 ALTER TABLE `compound_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `section` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `value` text NOT NULL,
  `compname` varchar(100) DEFAULT 'ALL',
  `app` varchar(16) NOT NULL,
  PRIMARY KEY (`config_id`),
  UNIQUE KEY `config_unique` (`section`,`name`,`compname`,`app`)
) ENGINE=InnoDB AUTO_INCREMENT=249 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'hot_text','editInj1','VIAL#: ºCRºDOSE: LOCATION: ºCRºSIZE OF REACTION: ºCRºREACTION START TIME:ºCRºRESOLUTION:','ALL','XIS'),(2,'hot_text','editInj2','HIVES','ALL','XIS'),(3,'hot_text','editInj3','','ALL','XIS'),(4,'hot_text','editInj4','HYPOTENSIVE ','ALL','XIS'),(5,'hot_text','editInj5','','ALL','XIS'),(6,'hot_text','editInj6','','ALL','XIS'),(7,'hot_text','inject1','','ALL','XIS'),(8,'hot_text','inject2','','ALL','XIS'),(9,'hot_text','inject3','','ALL','XIS'),(10,'hot_text','inject4','','ALL','XIS'),(11,'hot_text','inject5','','ALL','XIS'),(12,'hot_text','inject6','','ALL','XIS'),(13,'hot_text','injectAdjust1','Patient Late','ALL','XIS'),(14,'hot_text','injectAdjust2','Recent Local','ALL','XIS'),(15,'hot_text','injectAdjust3','Recent Systemic','ALL','XIS'),(16,'hot_text','injectAdjust4','','ALL','XIS'),(17,'hot_text','injectAdjust5','','ALL','XIS'),(18,'hot_text','injectAdjust6','','ALL','XIS'),(19,'hot_text','bottleNote1','','ALL','XPS'),(20,'hot_text','bottleNote2','','ALL','XPS'),(21,'hot_text','bottleNote3','','ALL','XPS'),(22,'hot_text','bottleNote4','','ALL','XPS'),(23,'hot_text','bottleNote5','','ALL','XPS'),(24,'hot_text','bottleNote6','','ALL','XPS'),(25,'hot_text','bottleNote7','','ALL','XPS'),(26,'hot_text','bottleNote8','','ALL','XPS'),(27,'hot_text','bottleNote9','','ALL','XPS'),(28,'hot_text','bottleNote10','','ALL','XPS'),(29,'hot_text','bottleNote11','','ALL','XPS'),(30,'hot_text','bottleNote12','','ALL','XPS'),(31,'hot_text','bottleName1',' SET 1 OF 1','ALL','XPS'),(32,'hot_text','bottleName2','','ALL','XPS'),(33,'hot_text','bottleName3','','ALL','XPS'),(34,'hot_text','bottleName4',' SET 1 OF 2','ALL','XPS'),(35,'hot_text','bottleName5',' SET 2 OF 2','ALL','XPS'),(36,'hot_text','bottleName6','','ALL','XPS'),(37,'hot_text','bottleName7',' SET 1 OF 3','ALL','XPS'),(38,'hot_text','bottleName8',' SET 2 OF 3','ALL','XPS'),(39,'hot_text','bottleName9',' SET 3 OF 3','ALL','XPS'),(40,'hot_text','bottleName10','','ALL','XPS'),(41,'hot_text','bottleName11','','ALL','XPS'),(42,'hot_text','bottleName12','','ALL','XPS'),(43,'hot_text','patientNote1','','ALL','XPS'),(44,'hot_text','patientNote2','','ALL','XPS'),(45,'hot_text','patientNote3','','ALL','XPS'),(46,'hot_text','patientNote4','','ALL','XPS'),(47,'hot_text','patientNote5','','ALL','XPS'),(48,'hot_text','patientNote6','','ALL','XPS'),(49,'hot_text','patientNote7','','ALL','XPS'),(50,'hot_text','patientNote8','','ALL','XPS'),(51,'hot_text','patientNote9','','ALL','XPS'),(52,'hot_text','patientNote10','','ALL','XPS'),(53,'hot_text','patientNote11','','ALL','XPS'),(54,'hot_text','patientNote12','','ALL','XPS'),(55,'boxNames','box1','Systemic','ALL','XIS'),(56,'boxNames','box2','Asthma','ALL','XIS'),(57,'boxNames','box3','Medicare','ALL','XIS'),(58,'lobbyDisplay','slideDuration','5','ALL','Lobby'),(59,'lobbyDisplay','imagesDuration','20','ALL','Lobby'),(60,'lobbyDisplay','dashDuration','120','ALL','Lobby'),(61,'sounds','soundEnabled','0','ALL','XIS'),(62,'prefs','dftExport?','T','ALL','ALL'),(63,'prefs','adtForProvider?','F','ALL','XPS'),(64,'prefs','logDBenabled?','F','ALL','XPS'),(65,'prefs','dftExport?','F','ALL','XPS'),(66,'prefs','vialStartLetter','','ALL','XPS'),(67,'prefs','hrLogEnabled?','F','ALL','XPS'),(68,'prefs','show1stDilENT?','F','ALL','XPS'),(69,'prefs','showTP?','F','ALL','XPS'),(70,'prefs','sizes','5 mL,10 mL,15 mL','ALL','XPS'),(71,'prefs','showShotLoc?','F','ALL','XPS'),(72,'prefs','showConditions?','F','ALL','XPS'),(73,'ui','rx_pdf_default_download','F','ALL','XST'),(74,'ui','rx_pdf_default_upload','F','ALL','XST'),(75,'ui','test_pdf_default_download','F','ALL','XST'),(76,'ui','test_pdf_default_upload','F','ALL','XST'),(77,'ui','test_billing_default_upload','F','ALL','XST'),(78,'emr','source','none','ALL','XST'),(79,'emr','pdf_destination','','ALL','XST'),(80,'emr','dft_destination','','ALL','XST'),(81,'prefs','lockRxDoses?','F','ALL','XST'),(82,'prefs','zeroUntested?','F','ALL','XST'),(83,'ui','sort_extracts_by','test_order','ALL','XST'),(84,'ui','positive_scores_at_top','T','ALL','XST'),(85,'ui','sort_positives_by_score','T','ALL','XST'),(86,'ui','num_keys','30','ALL','XST'),(87,'vial_label_template','-','Zebra ZPL format PRN templates with \"name\" being a number and \"value\" being the template. The highest numbered template will be used.','ALL','XST'),(88,'receiving','enabled','T','ALL','XST'),(89,'sounds','soundEnabled','F','ALL','XST'),(90,'billing','diagnosis_code2','477.1 - Allergic rhinitis due to food','ALL','XST'),(91,'billing','diagnosis_code3','477.2 - Allergic rhinitis due to animal hair and dander','ALL','XST'),(92,'billing','diagnosis_code4','477.8 - Allergic rhinitis due to other allergen','ALL','XST'),(93,'billing','diagnosis_code5','477.9 - Allergic rhinitis, cause unspecified','ALL','XST'),(94,'billing','diagnosis_code6','493.00 - Extrinsic asthma, unspecified','ALL','XST'),(95,'billing','diagnosis_code7','493.01 - Extrinsic asthma, with status asthmaticus','ALL','XST'),(96,'billing','diagnosis_code8','493.02 - Extrinsic asthma, with (acute) exacerbation','ALL','XST'),(97,'billing','diagnosis_code9','493.90 - Unspecified asthma, unspecified','ALL','XST'),(98,'billing','diagnosis_code10','493.91 - Unspecified asthma, with status asthmaticus','ALL','XST'),(99,'billing','diagnosis_code11','493.92 - Unspecified asthma, with (acute) exacerbation','ALL','XST'),(100,'billing','billing_code1','95004 - Percutanteous Skin Test','ALL','XST'),(101,'billing','billing_code2','95024 - Intradermal Skin Test  ','ALL','XST'),(102,'test_status','0','In progress','ALL','XST'),(103,'test_status','99','Completed','ALL','XST'),(104,'supplier','1','Greer','ALL','XST'),(105,'supplier','2','Hollister','ALL','XST'),(106,'supplier','3','ALK','ALL','XST'),(107,'supplier','4','Allergy Labs','ALL','XST'),(110,'ICD','code1','J30.1','ALL','ALL'),(111,'ICD','code1Desc','Allergic rhinitis due to pollen','ALL','ALL'),(112,'ICD','code2','J30.89','ALL','ALL'),(113,'ICD','code2Desc','Other allergic rhinitis','ALL','ALL'),(114,'ICD','code3','J30.81','ALL','ALL'),(115,'ICD','code3Desc','Allergic rhinitis due to animal (cat)(dog) hair and dander','ALL','ALL'),(116,'CPT','code1','95165','ALL','ALL'),(117,'CPT','code1Desc','5 DOSE VIAL','ALL','ALL'),(118,'CPT','code2','95117','ALL','ALL'),(119,'CPT','code2Desc','Two or more injections','ALL','ALL'),(120,'CPT','code3','95115','ALL','ALL'),(121,'CPT','code3Desc','One Injection','ALL','ALL'),(124,'trackingNames','peak flow','min=-1.00max=-1.00','ALL','XIS'),(125,'trackingNames','peak flow 2','min=-2.00max=-2.00','ALL','XIS');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diagnosis`
--

DROP TABLE IF EXISTS `diagnosis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diagnosis` (
  `diagnosis_id` int(11) NOT NULL AUTO_INCREMENT,
  `formalname` varchar(45) DEFAULT NULL,
  `displayname` varchar(45) DEFAULT NULL,
  `diagDose` float DEFAULT NULL,
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  `extract_id` int(11) NOT NULL,
  PRIMARY KEY (`diagnosis_id`),
  KEY `fk_diagnosis_extract1_idx` (`extract_id`),
  CONSTRAINT `fk_diagnosis_extract1` FOREIGN KEY (`extract_id`) REFERENCES `extract` (`extract_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diagnosis`
--

LOCK TABLES `diagnosis` WRITE;
/*!40000 ALTER TABLE `diagnosis` DISABLE KEYS */;
INSERT INTO `diagnosis` VALUES (1,NULL,NULL,-1,'T',1),(2,NULL,'ALLERGIC RHINITIS & ASTHMA',NULL,'F',1),(3,NULL,'ANAPHYLAXIS',NULL,'F',1),(4,NULL,'ALLERGIC RHINITIS',NULL,'F',1),(5,NULL,'ALLERGIC RHINITIS',NULL,'T',1);
/*!40000 ALTER TABLE `diagnosis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doseruledetails`
--

DROP TABLE IF EXISTS `doseruledetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doseruledetails` (
  `doseRuleDetails_id` int(11) NOT NULL AUTO_INCREMENT,
  `start` varchar(20) DEFAULT NULL,
  `end` varchar(20) DEFAULT NULL,
  `reactType` varchar(2) DEFAULT NULL,
  `reactVal` varchar(20) DEFAULT NULL,
  `delta` varchar(20) DEFAULT NULL,
  `oldStyle` text,
  `deleted` varchar(2) DEFAULT NULL,
  `doseRuleNames_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`doseRuleDetails_id`),
  KEY `doseRuleDetails_doseRuleNames_id_idx` (`doseRuleNames_id`),
  CONSTRAINT `fk_doseRuleDetails_doseRuleName_id` FOREIGN KEY (`doseRuleNames_id`) REFERENCES `doserulenames` (`doseRuleNames_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doseruledetails`
--

LOCK TABLES `doseruledetails` WRITE;
/*!40000 ALTER TABLE `doseruledetails` DISABLE KEYS */;
INSERT INTO `doseruledetails` VALUES (1,'0','0','L','None','1',NULL,NULL,1),(2,'1','1','L','None','2',NULL,NULL,1),(3,'2','2','L','None','3',NULL,NULL,1),(4,'3','3','L','None','1',NULL,NULL,1),(5,'4','4','L','None','1',NULL,NULL,1),(6,'5','5','L','None','1',NULL,NULL,1),(7,'6','6','L','None','1',NULL,NULL,1),(8,'7','7','L','None','1',NULL,NULL,1),(9,'8','8','L','None','1',NULL,NULL,1),(10,'9','9','L','None','1',NULL,NULL,1),(11,'10','10','L','None','0',NULL,NULL,1),(12,'11','11','L','None','0',NULL,NULL,1),(13,'12','12','L','None','0',NULL,NULL,1),(14,'13','13','L','None','0',NULL,NULL,1),(15,'14','14','L','None','0',NULL,NULL,1),(16,'15','15','L','None','0',NULL,NULL,1),(17,'16','16','L','None','0',NULL,NULL,1),(18,'17','17','L','None','0',NULL,NULL,1),(19,'18','18','L','None','-1',NULL,NULL,1),(20,'19','19','L','None','-1',NULL,NULL,1),(21,'20','20','L','None','-1',NULL,NULL,1),(22,'21','21','L','None','-1',NULL,NULL,1),(23,'22','Inf','L','None','ASK',NULL,NULL,1),(24,'0','0','L','Dime','0',NULL,NULL,1),(25,'1','1','L','Dime','0',NULL,NULL,1),(26,'2','2','L','Dime','-1',NULL,NULL,1),(27,'3','3','L','Dime','-1',NULL,NULL,1),(28,'4','4','L','Dime','-1',NULL,NULL,1),(29,'5','5','L','Dime','-1',NULL,NULL,1),(30,'6','6','L','Dime','-1',NULL,NULL,1),(31,'7','7','L','Dime','-1',NULL,NULL,1),(32,'8','8','L','Dime','-1',NULL,NULL,1),(33,'9','9','L','Dime','-1',NULL,NULL,1),(34,'10','10','L','Dime','-2',NULL,NULL,1),(35,'11','11','L','Dime','-2',NULL,NULL,1),(36,'12','12','L','Dime','-2',NULL,NULL,1),(37,'13','13','L','Dime','-2',NULL,NULL,1),(38,'14','14','L','Dime','-2',NULL,NULL,1),(39,'15','15','L','Dime','-2',NULL,NULL,1),(40,'16','16','L','Dime','-2',NULL,NULL,1),(41,'17','17','L','Dime','-2',NULL,NULL,1),(42,'18','18','L','Dime','-3',NULL,NULL,1),(43,'19','19','L','Dime','-3',NULL,NULL,1),(44,'20','20','L','Dime','-3',NULL,NULL,1),(45,'21','21','L','Dime','-3',NULL,NULL,1),(46,'22','Inf','L','Dime','ASK',NULL,NULL,1),(47,'0','0','L','Nickel','-1',NULL,NULL,1),(48,'1','1','L','Nickel','-1',NULL,NULL,1),(49,'2','2','L','Nickel','-2',NULL,NULL,1),(50,'3','3','L','Nickel','-2',NULL,NULL,1),(51,'4','4','L','Nickel','-2',NULL,NULL,1),(52,'5','5','L','Nickel','-2',NULL,NULL,1),(53,'6','6','L','Nickel','-2',NULL,NULL,1),(54,'7','7','L','Nickel','-2',NULL,NULL,1),(55,'8','8','L','Nickel','-2',NULL,NULL,1),(56,'9','9','L','Nickel','-2',NULL,NULL,1),(57,'10','10','L','Nickel','-3',NULL,NULL,1),(58,'11','11','L','Nickel','-3',NULL,NULL,1),(59,'12','12','L','Nickel','-3',NULL,NULL,1),(60,'13','13','L','Nickel','-3',NULL,NULL,1),(61,'14','14','L','Nickel','-3',NULL,NULL,1),(62,'15','15','L','Nickel','-3',NULL,NULL,1),(63,'16','16','L','Nickel','-3',NULL,NULL,1),(64,'17','17','L','Nickel','-3',NULL,NULL,1),(65,'18','18','L','Nickel','-4',NULL,NULL,1),(66,'19','19','L','Nickel','-4',NULL,NULL,1),(67,'20','20','L','Nickel','-4',NULL,NULL,1),(68,'21','21','L','Nickel','-4',NULL,NULL,1),(69,'22','Inf','L','Nickel','ASK',NULL,NULL,1),(70,'0','0','L','Quarter','-1',NULL,NULL,1),(71,'1','1','L','Quarter','-1',NULL,NULL,1),(72,'2','2','L','Quarter','-2',NULL,NULL,1),(73,'3','3','L','Quarter','-2',NULL,NULL,1),(74,'4','4','L','Quarter','-2',NULL,NULL,1),(75,'5','5','L','Quarter','-2',NULL,NULL,1),(76,'6','6','L','Quarter','-2',NULL,NULL,1),(77,'7','7','L','Quarter','-2',NULL,NULL,1),(78,'8','8','L','Quarter','-2',NULL,NULL,1),(79,'9','9','L','Quarter','-2',NULL,NULL,1),(80,'10','10','L','Quarter','-3',NULL,NULL,1),(81,'11','11','L','Quarter','-3',NULL,NULL,1),(82,'12','12','L','Quarter','-3',NULL,NULL,1),(83,'13','13','L','Quarter','-3',NULL,NULL,1),(84,'14','14','L','Quarter','-3',NULL,NULL,1),(85,'15','15','L','Quarter','-3',NULL,NULL,1),(86,'16','16','L','Quarter','-3',NULL,NULL,1),(87,'17','17','L','Quarter','-3',NULL,NULL,1),(88,'18','18','L','Quarter','-4',NULL,NULL,1),(89,'19','19','L','Quarter','-4',NULL,NULL,1),(90,'20','20','L','Quarter','-4',NULL,NULL,1),(91,'21','21','L','Quarter','-4',NULL,NULL,1),(92,'22','Inf','L','Quarter','ASK',NULL,NULL,1),(93,'0','0','S','Y','ASK',NULL,NULL,1),(94,'1','1','S','Y','ASK',NULL,NULL,1),(95,'2','2','S','Y','ASK',NULL,NULL,1),(96,'3','3','S','Y','ASK',NULL,NULL,1),(97,'4','4','S','Y','ASK',NULL,NULL,1),(98,'5','5','S','Y','ASK',NULL,NULL,1),(99,'6','6','S','Y','ASK',NULL,NULL,1),(100,'7','7','S','Y','ASK',NULL,NULL,1),(101,'8','8','S','Y','ASK',NULL,NULL,1),(102,'9','9','S','Y','ASK',NULL,NULL,1),(103,'10','10','S','Y','ASK',NULL,NULL,1),(104,'11','11','S','Y','ASK',NULL,NULL,1),(105,'12','12','S','Y','ASK',NULL,NULL,1),(106,'13','13','S','Y','ASK',NULL,NULL,1),(107,'14','14','S','Y','ASK',NULL,NULL,1),(108,'15','15','S','Y','ASK',NULL,NULL,1),(109,'16','16','S','Y','ASK',NULL,NULL,1),(110,'17','17','S','Y','ASK',NULL,NULL,1),(111,'18','18','S','Y','ASK',NULL,NULL,1),(112,'19','19','S','Y','ASK',NULL,NULL,1),(113,'20','20','S','Y','ASK',NULL,NULL,1),(114,'21','21','S','Y','ASK',NULL,NULL,1),(115,'22','Inf','S','Y','ASK',NULL,NULL,1);
/*!40000 ALTER TABLE `doseruledetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doserulenames`
--

DROP TABLE IF EXISTS `doserulenames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doserulenames` (
  `doseRuleNames_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `deleted` char(1) DEFAULT 'F',
  PRIMARY KEY (`doseRuleNames_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doserulenames`
--

LOCK TABLES `doserulenames` WRITE;
/*!40000 ALTER TABLE `doserulenames` DISABLE KEYS */;
INSERT INTO `doserulenames` VALUES (1,'Default','F');
/*!40000 ALTER TABLE `doserulenames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dosing`
--

DROP TABLE IF EXISTS `dosing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dosing` (
  `dosing_id` int(11) NOT NULL AUTO_INCREMENT,
  `dose` decimal(6,3) DEFAULT NULL,
  `ent_dilution` int(11) DEFAULT NULL,
  `clickOrder` int(11) DEFAULT NULL,
  `prescription_id` int(11) NOT NULL,
  `extract_id` int(11) NOT NULL,
  `weight` decimal(7,3) DEFAULT '-999.999',
  PRIMARY KEY (`dosing_id`),
  KEY `fk_prescription_id` (`prescription_id`),
  KEY `fk_extract_id` (`extract_id`),
  CONSTRAINT `fk_extract_id` FOREIGN KEY (`extract_id`) REFERENCES `extract` (`extract_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_prescription_id` FOREIGN KEY (`prescription_id`) REFERENCES `prescription` (`prescription_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dosing`
--

LOCK TABLES `dosing` WRITE;
/*!40000 ALTER TABLE `dosing` DISABLE KEYS */;
INSERT INTO `dosing` VALUES (1,4.000,0,NULL,1,2,-999.999),(2,0.500,0,NULL,1,5,-999.999),(3,0.500,0,NULL,1,7,-999.999),(4,4.000,0,NULL,2,3,-999.999),(5,0.500,0,NULL,2,8,-999.999),(6,0.500,0,NULL,2,9,-999.999),(7,2.500,0,NULL,3,2,-999.999),(8,1.500,0,NULL,3,4,-999.999),(9,0.500,0,NULL,3,7,-999.999),(10,0.500,0,NULL,3,8,-999.999),(11,6.000,0,NULL,3,2,-999.999),(12,3.000,0,NULL,3,4,-999.999),(13,0.400,0,NULL,3,7,-999.999),(14,0.600,0,NULL,3,8,-999.999),(15,NULL,NULL,NULL,4,2,-999.999),(16,NULL,NULL,NULL,4,7,-999.999),(17,2.000,0,NULL,4,2,-999.999),(18,1.000,0,NULL,4,4,-999.999),(19,1.750,0,NULL,4,8,-999.999),(20,2.000,0,NULL,4,2,-999.999),(21,1.000,0,NULL,4,4,-999.999),(22,1.750,0,NULL,4,8,-999.999),(23,2.000,0,NULL,4,2,-999.999),(24,1.000,0,NULL,4,4,-999.999),(25,1.750,0,NULL,4,8,-999.999),(26,2.000,0,NULL,4,2,-999.999),(27,1.000,0,NULL,4,4,-999.999),(28,1.750,0,NULL,4,8,-999.999),(29,2.000,0,NULL,4,2,-999.999),(30,1.000,0,NULL,4,4,-999.999),(31,1.750,0,NULL,4,8,-999.999);
/*!40000 ALTER TABLE `dosing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extract`
--

DROP TABLE IF EXISTS `extract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `extract` (
  `extract_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `latinname` varchar(100) DEFAULT NULL,
  `manufacturer` varchar(45) DEFAULT NULL,
  `code` varchar(45) DEFAULT NULL,
  `ndc` varchar(13) DEFAULT NULL,
  `abbreviation` varchar(45) DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `percentGlycerin` decimal(5,2) DEFAULT '0.00',
  `percentPhenol` decimal(5,2) DEFAULT '0.00',
  `percentHSA` decimal(5,2) DEFAULT '0.00',
  `dilution` varchar(45) DEFAULT NULL,
  `units` int(11) DEFAULT '5',
  `cost` varchar(45) DEFAULT NULL,
  `sub` varchar(50) DEFAULT '',
  `specificgravity` varchar(45) DEFAULT NULL,
  `outdatealert` varchar(45) DEFAULT NULL,
  `compatibility_class_id` int(11) DEFAULT NULL,
  `imagefile` varchar(150) DEFAULT NULL,
  `isDiluent` varchar(5) DEFAULT 'F',
  `silhouette` varchar(45) DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  `topline` varchar(45) DEFAULT NULL,
  `firstline` varchar(45) DEFAULT NULL,
  `secondline` varchar(45) DEFAULT NULL,
  `seasonStart` varchar(45) DEFAULT NULL,
  `seasonEnd` varchar(45) DEFAULT NULL,
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`extract_id`),
  KEY `compatibility_class_id` (`compatibility_class_id`),
  KEY `fk_extract_units_units_id` (`units`),
  CONSTRAINT `fk_extract_compatibility_class` FOREIGN KEY (`compatibility_class_id`) REFERENCES `compatibility_class` (`compatibility_class_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_extract_units_units_id` FOREIGN KEY (`units`) REFERENCES `units` (`units_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extract`
--

LOCK TABLES `extract` WRITE;
/*!40000 ALTER TABLE `extract` DISABLE KEYS */;
INSERT INTO `extract` VALUES (1,NULL,NULL,NULL,'-999',NULL,'','T',0.00,0.00,0.00,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'F',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'T','2018-09-24 17:03:07',NULL,'2017-11-16 01:04:33',NULL),(2,'Glycerinated Diluent','','HOLLISTER','dil',NULL,'','T',50.00,0.00,0.00,'1:1',2,'0.00','','1.16',NULL,NULL,'Glycerinated_DIL.jpg','T',NULL,NULL,NULL,NULL,NULL,'*1/1','*12/31','F','2019-01-16 18:24:20',NULL,'2018-01-11 21:25:34',NULL),(3,'HSA','','Greer','dil',NULL,'','T',0.00,0.00,0.40,'1:1',2,'0.00','','1.00',NULL,NULL,'DILUENT_HSA.jpg','T',NULL,NULL,NULL,NULL,NULL,'*1/1','*12/31','F','2019-01-16 18:24:20',NULL,'2018-01-11 21:25:34',NULL),(4,'Aqueous Dil','','Greer','dil',NULL,'','T',0.00,0.00,0.40,'1:1',2,'0.00','','1.00',NULL,NULL,'DILUENT_HSA.jpg','T',NULL,NULL,NULL,NULL,NULL,'*1/1','*12/31','F','2019-01-16 18:24:20',NULL,'2018-01-11 21:25:34',NULL),(5,'Elm-Chinese','','HOLLISTER','4926',NULL,'TRS','T',50.00,0.00,0.00,'1:20',2,'0.00','','1.16',NULL,NULL,'ELM_CHINESE.jpg','F',NULL,NULL,NULL,NULL,NULL,'','','F','2019-01-16 18:24:20',NULL,'2018-01-11 21:25:34',NULL),(6,'Ragweed, Giant','','HOLLISTER','53620',NULL,'GRS','T',50.00,0.00,0.00,'1:20',2,'0.00','','1.16',NULL,3,'RAGWEED_GIANT.jpg','F',NULL,NULL,NULL,NULL,NULL,'','','F','2019-01-16 18:24:20',NULL,'2018-01-11 21:25:34',NULL),(7,'Alternaria','','HOLLISTER','50128',NULL,'MLD','T',50.00,0.00,0.00,'1:10',2,'0.00','','1.16',NULL,NULL,'ALTERNARIA_TENUIS.jpg','F',NULL,NULL,NULL,NULL,NULL,'','','F','2019-01-16 18:24:20',NULL,'2018-01-11 21:25:34',NULL),(8,'Pine Mix','','HOLLISTER','19412',NULL,'TRS','T',50.00,0.00,0.00,'1:20',2,'0.00','','1.16',NULL,1,'PINE_MIX.jpg','F',NULL,NULL,NULL,NULL,NULL,'','','F','2019-01-16 18:24:20',NULL,'2018-01-11 21:25:34',NULL),(9,'Timothy Grass','','HOLLISTER','66983',NULL,'GRS','T',50.00,0.00,0.00,'100,000',0,'0.00','','1.16',NULL,NULL,'TIMOTHY_GRASS.jpg','F',NULL,NULL,NULL,NULL,NULL,'','','F','2019-01-16 18:24:20',NULL,'2018-01-11 21:25:34',NULL),(10,'Candida Albicans','','GREER','247',NULL,'MLD','T',50.00,0.00,0.00,'1:100',2,'0.00','','1.16',NULL,2,'CANDIDA_ALBICANS.jpg','F',NULL,NULL,NULL,NULL,NULL,'','','F','2019-01-16 18:24:20',NULL,'2018-01-11 21:25:34',NULL),(11,'AP Dog','','GREER','55231',NULL,'DOG','T',50.00,0.00,0.00,'100,000',0,'0.00','','1.16',NULL,NULL,'AP_DOG.jpg','F',NULL,NULL,NULL,NULL,NULL,'','','F','2019-01-16 18:24:20',NULL,'2018-01-11 21:25:34',NULL);
/*!40000 ALTER TABLE `extract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extract_mix`
--

DROP TABLE IF EXISTS `extract_mix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `extract_mix` (
  `extract_mix_id` int(11) NOT NULL AUTO_INCREMENT,
  `constit_extract_id` int(11) NOT NULL,
  `dose` decimal(5,3) DEFAULT NULL,
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  `extract_id` int(11) NOT NULL,
  PRIMARY KEY (`extract_mix_id`),
  KEY `fk_extractMix_extract` (`extract_id`),
  CONSTRAINT `fk_extractMix_extract` FOREIGN KEY (`extract_id`) REFERENCES `extract` (`extract_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extract_mix`
--

LOCK TABLES `extract_mix` WRITE;
/*!40000 ALTER TABLE `extract_mix` DISABLE KEYS */;
/*!40000 ALTER TABLE `extract_mix` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flag`
--

DROP TABLE IF EXISTS `flag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flag` (
  `flag_id` int(11) NOT NULL AUTO_INCREMENT,
  `catagory` varchar(16) DEFAULT NULL,
  `status` varchar(16) DEFAULT 'active',
  `period_start` datetime NOT NULL,
  `period_end` datetime DEFAULT NULL,
  `period_interval` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code` tinytext,
  `identifier` varchar(32) DEFAULT NULL,
  `last_alert` datetime DEFAULT NULL,
  PRIMARY KEY (`flag_id`),
  KEY `fk_flag_patient_id` (`patient_id`),
  KEY `fk_flag_user_id` (`user_id`),
  CONSTRAINT `fk_flag_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  CONSTRAINT `fk_flag_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flag`
--

LOCK TABLES `flag` WRITE;
/*!40000 ALTER TABLE `flag` DISABLE KEYS */;
/*!40000 ALTER TABLE `flag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flags`
--

DROP TABLE IF EXISTS `flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flags` (
  `flag_id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) DEFAULT NULL,
  `urgency` varchar(45) DEFAULT NULL,
  `deleted` varchar(5) NOT NULL DEFAULT 'F',
  `code` varchar(45) DEFAULT NULL,
  `adminReq` varchar(5) DEFAULT 'F',
  `showMsg` varchar(5) DEFAULT 'F',
  PRIMARY KEY (`flag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flags`
--

LOCK TABLES `flags` WRITE;
/*!40000 ALTER TABLE `flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flaguse`
--

DROP TABLE IF EXISTS `flaguse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flaguse` (
  `flagUse_id` int(11) NOT NULL AUTO_INCREMENT,
  `flag_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  PRIMARY KEY (`flagUse_id`),
  KEY `flagUse_flag_id_idx` (`flag_id`),
  KEY `fk_flagUSe_patient_id_idx` (`patient_id`),
  CONSTRAINT `fk_flagUSe_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_flagUse_flag_id` FOREIGN KEY (`flag_id`) REFERENCES `flags` (`flag_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flaguse`
--

LOCK TABLES `flaguse` WRITE;
/*!40000 ALTER TABLE `flaguse` DISABLE KEYS */;
/*!40000 ALTER TABLE `flaguse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `gen2_log`
--

DROP TABLE IF EXISTS `gen2_log`;
/*!50001 DROP VIEW IF EXISTS `gen2_log`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `gen2_log` AS SELECT 
 1 AS `xis_log_id`,
 1 AS `api_log_id`,
 1 AS `timestamp`,
 1 AS `user_id`,
 1 AS `username`,
 1 AS `event`,
 1 AS `comp`,
 1 AS `patient_id`,
 1 AS `prescription_id`,
 1 AS `error`,
 1 AS `response_code`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `hrlog`
--

DROP TABLE IF EXISTS `hrlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hrlog` (
  `hrLog_id` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(150) DEFAULT NULL,
  `userName` varchar(45) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `botNums` varchar(45) DEFAULT NULL,
  `prescription_id` int(11) NOT NULL,
  PRIMARY KEY (`hrLog_id`),
  KEY `fk_hrLog_prescription_idx` (`prescription_id`),
  CONSTRAINT `fk_hrLog_prescription1` FOREIGN KEY (`prescription_id`) REFERENCES `prescription` (`prescription_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hrlog`
--

LOCK TABLES `hrlog` WRITE;
/*!40000 ALTER TABLE `hrlog` DISABLE KEYS */;
INSERT INTO `hrlog` VALUES (1,'view prescription','Xtract Admin','2018-02-06 11:00:52','',3),(2,'view prescription','Xtract Admin','2018-02-06 11:02:36','',3),(3,'receive prescription','Xtract Admin','2018-02-06 11:02:52','',3),(4,'view prescription','Xtract Admin','2018-06-03 09:30:04','',3),(5,'remake prescription','Xtract Admin','2018-06-03 09:30:56','1A,2A,3A',3);
/*!40000 ALTER TABLE `hrlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `identification`
--

DROP TABLE IF EXISTS `identification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identification` (
  `identification_id` int(11) NOT NULL AUTO_INCREMENT,
  `finger` int(11) NOT NULL,
  `fmd` varchar(1024) DEFAULT NULL,
  `fmd_construct` varchar(8192) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  PRIMARY KEY (`identification_id`),
  KEY `fk_patient_id_idx` (`patient_id`),
  CONSTRAINT `fk_patient_id2` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identification`
--

LOCK TABLES `identification` WRITE;
/*!40000 ALTER TABLE `identification` DISABLE KEYS */;
/*!40000 ALTER TABLE `identification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `data` text NOT NULL,
  `type` varchar(32) NOT NULL,
  PRIMARY KEY (`image_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `injadjust`
--

DROP TABLE IF EXISTS `injadjust`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `injadjust` (
  `injAdjust_id` int(11) NOT NULL AUTO_INCREMENT,
  `dose` float DEFAULT NULL,
  `dilution` varchar(45) DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  `reason` varchar(150) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `prescription_id` int(11) NOT NULL,
  `adjby` varchar(45) DEFAULT NULL,
  `reviewby` varchar(150) DEFAULT NULL,
  `deleted` varchar(45) DEFAULT 'F',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`injAdjust_id`),
  KEY `fk_injAdjust_prescription1_idx` (`prescription_id`),
  CONSTRAINT `fk_injAdjust_prescription1` FOREIGN KEY (`prescription_id`) REFERENCES `prescription` (`prescription_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `injadjust`
--

LOCK TABLES `injadjust` WRITE;
/*!40000 ALTER TABLE `injadjust` DISABLE KEYS */;
/*!40000 ALTER TABLE `injadjust` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `injection`
--

DROP TABLE IF EXISTS `injection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `injection` (
  `injection_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `timecheckin` datetime DEFAULT NULL,
  `timeinjection` datetime DEFAULT NULL,
  `timeexcuse` text,
  `dose` decimal(6,3) DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  `site` varchar(45) DEFAULT NULL,
  `code` varchar(45) DEFAULT NULL,
  `question` int(11) DEFAULT NULL,
  `vials` int(11) DEFAULT NULL,
  `notespatient` text,
  `notesuser` text,
  `reactionimage` varchar(45) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `reaction` varchar(32) DEFAULT 'F',
  `sysreaction` varchar(32) DEFAULT 'F',
  `user_id` int(11) NOT NULL,
  `compound_id` int(11) NOT NULL,
  `deleted` varchar(45) DEFAULT 'F',
  `attending` varchar(45) DEFAULT NULL,
  `tpdetails_id` varchar(45) DEFAULT '-1',
  `inj_adjust_id` int(11) DEFAULT NULL,
  `predicted_tpdetails_id` int(11) DEFAULT NULL,
  `treatment_plan_id` int(11) DEFAULT NULL,
  `tp_step` int(11) DEFAULT NULL,
  `is_rule_adjust` char(1) DEFAULT 'F',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`injection_id`),
  KEY `fk_injection_user1_idx` (`user_id`),
  KEY `fk_compound_id_idx` (`compound_id`),
  KEY `predicted_tpdetails_id` (`predicted_tpdetails_id`),
  KEY `inj_adjust_id` (`inj_adjust_id`),
  CONSTRAINT `fk_injection_compound1` FOREIGN KEY (`compound_id`) REFERENCES `compound` (`compound_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_injection_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `injection_ibfk_1` FOREIGN KEY (`predicted_tpdetails_id`) REFERENCES `treatplandetails` (`treatPlanDetails_id`),
  CONSTRAINT `injection_ibfk_2` FOREIGN KEY (`inj_adjust_id`) REFERENCES `injadjust` (`injAdjust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `injection`
--

LOCK TABLES `injection` WRITE;
/*!40000 ALTER TABLE `injection` DISABLE KEYS */;
/*!40000 ALTER TABLE `injection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `install_config`
--

DROP TABLE IF EXISTS `install_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `install_config` (
  `install_config_id` int(11) NOT NULL AUTO_INCREMENT,
  `section` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `value` text NOT NULL,
  `comment` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`install_config_id`),
  UNIQUE KEY `install_config_unique` (`section`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `install_config`
--

LOCK TABLES `install_config` WRITE;
/*!40000 ALTER TABLE `install_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `install_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `inventory_id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(45) DEFAULT NULL,
  `outdate` date DEFAULT NULL,
  `lotnumber` varchar(45) DEFAULT NULL,
  `dilutionENT` int(11) DEFAULT NULL,
  `vialSize` decimal(7,3) DEFAULT NULL,
  `volumeNew` decimal(7,3) DEFAULT NULL,
  `volumeCurrent` decimal(7,3) DEFAULT NULL,
  `installtime` timestamp NULL DEFAULT NULL,
  `removetime` timestamp NULL DEFAULT NULL,
  `changereason` varchar(150) DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  `discardDate` date DEFAULT NULL,
  `door` int(11) NOT NULL,
  `page` int(11) NOT NULL DEFAULT '1',
  `location` int(11) DEFAULT '0',
  `percentHSA` decimal(5,2) DEFAULT '0.00',
  `percentPhenol` decimal(5,2) DEFAULT '0.00',
  `percentGlycerin` decimal(5,2) DEFAULT '0.00',
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  `extract_id` int(11) NOT NULL,
  `installBy` varchar(50) DEFAULT NULL,
  `removeBy` varchar(50) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`inventory_id`),
  KEY `fk_inventory_extract1_idx` (`extract_id`),
  CONSTRAINT `fk_inventory_extract1` FOREIGN KEY (`extract_id`) REFERENCES `extract` (`extract_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,'500006','2018-02-01','86874',0,50.000,50.000,48.500,'2015-06-09 08:16:12',NULL,'Initial import',NULL,'1904-01-25',0,1,1,0.00,0.00,50.00,'F',5,NULL,NULL,'0000-00-00 00:00:00',NULL,'2018-01-11 21:25:34',NULL),(2,'500120','2016-05-17','23550',0,50.000,50.000,45.000,'2015-06-09 08:16:13',NULL,'Initial import',NULL,'1904-01-25',1,1,1,0.00,0.00,0.00,'F',6,NULL,NULL,'0000-00-00 00:00:00',NULL,'2018-01-11 21:25:34',NULL),(3,'500042','2018-01-14','99467',0,50.000,50.000,49.000,'2015-06-09 08:16:12',NULL,'Initial import',NULL,'1904-01-25',2,1,1,0.00,0.00,50.00,'F',7,NULL,NULL,'0000-00-00 00:00:00',NULL,'2018-01-11 21:25:34',NULL),(4,'500088','2016-08-13','75432',0,50.000,50.000,49.000,'2015-06-09 08:16:12',NULL,'Initial import',NULL,'1904-01-25',3,1,1,0.00,0.00,50.00,'F',8,NULL,NULL,'0000-00-00 00:00:00',NULL,'2018-01-11 21:25:34',NULL),(5,'500017','2017-07-04','99811',0,50.000,50.000,41.800,'2015-06-09 08:16:12',NULL,'Initial import',NULL,'1904-01-25',4,1,1,0.00,0.00,50.00,'F',9,NULL,NULL,'0000-00-00 00:00:00',NULL,'2018-01-11 21:25:34',NULL),(6,'500188','2100-01-01','14235',0,50.000,50.000,50.000,'2017-03-21 00:09:53',NULL,'Initial import',NULL,'1963-11-26',5,1,1,0.00,0.00,50.00,'F',10,NULL,NULL,'0000-00-00 00:00:00',NULL,'2018-01-11 21:25:34',NULL),(7,'500062','2018-01-14','90793',0,50.000,50.000,47.600,'2015-06-09 08:16:12',NULL,'Initial import',NULL,'1904-01-25',6,1,1,0.00,0.00,50.00,'F',11,NULL,NULL,'0000-00-00 00:00:00',NULL,'2018-01-11 21:25:34',NULL),(8,NULL,'2001-01-01','',0,0.000,0.000,0.000,'2018-01-13 21:50:45',NULL,'XST queue process','2018-01-13 21:50:45',NULL,-1,1,0,0.00,0.00,0.00,'T',2,'XST',NULL,'0000-00-00 00:00:00',NULL,'2018-01-13 21:50:46',NULL),(9,NULL,'2001-01-01','',0,0.000,0.000,0.000,'2018-01-13 21:50:45',NULL,'XST queue process','2018-01-13 21:50:45',NULL,-1,1,0,0.00,0.00,0.00,'T',4,'XST',NULL,'0000-00-00 00:00:00',NULL,'2018-01-13 21:50:46',NULL),(10,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'API set_order creation',NULL,NULL,-1,1,0,0.00,0.00,0.00,'T',2,'API',NULL,'2018-10-08 20:24:50',NULL,'2018-10-08 20:24:50',NULL);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `deleted` varchar(11) DEFAULT 'F',
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_xa`
--

DROP TABLE IF EXISTS `log_xa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_xa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reportname` varchar(256) DEFAULT NULL,
  `message` text,
  `patient` int(11) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `compName` varchar(100) DEFAULT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_xa`
--

LOCK TABLES `log_xa` WRITE;
/*!40000 ALTER TABLE `log_xa` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_xa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `loginTime` datetime DEFAULT NULL,
  `excuseTime` datetime DEFAULT NULL,
  `timeNext` datetime DEFAULT NULL,
  `timeOut` datetime DEFAULT NULL,
  `imagepath` varchar(150) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `timeLeft` datetime DEFAULT NULL,
  `state` int(11) NOT NULL,
  `clinic_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`login_id`),
  KEY `fk_login_clinic` (`clinic_id`),
  KEY `fk_login_patient_id` (`patient_id`),
  CONSTRAINT `fk_login_clinic` FOREIGN KEY (`clinic_id`) REFERENCES `clinic` (`clinic_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_login_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `days` int(7) DEFAULT NULL,
  `sql_code` text COLLATE utf8mb4_bin,
  `content` text COLLATE utf8mb4_bin,
  `method` char(1) COLLATE utf8mb4_bin NOT NULL DEFAULT 'E',
  `patientSelect` varchar(45) COLLATE utf8mb4_bin DEFAULT NULL,
  `singleSend` char(1) COLLATE utf8mb4_bin NOT NULL DEFAULT 'T',
  `custom` char(1) COLLATE utf8mb4_bin NOT NULL DEFAULT 'F',
  `enabled` char(1) COLLATE utf8mb4_bin NOT NULL DEFAULT 'T',
  `schedule` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` char(1) COLLATE utf8mb4_bin NOT NULL DEFAULT 'F',
  `subject` varchar(250) COLLATE utf8mb4_bin DEFAULT '',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_log`
--

DROP TABLE IF EXISTS `message_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message_log` (
  `message_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'P',
  `sentTime` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_log_id`),
  KEY `patient_id` (`patient_id`),
  KEY `message_id` (`message_id`),
  CONSTRAINT `message_log_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  CONSTRAINT `message_log_ibfk_2` FOREIGN KEY (`message_id`) REFERENCES `message` (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_log`
--

LOCK TABLES `message_log` WRITE;
/*!40000 ALTER TABLE `message_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_06_01_000001_create_oauth_auth_codes_table',1),(4,'2016_06_01_000002_create_oauth_access_tokens_table',1),(5,'2016_06_01_000003_create_oauth_refresh_tokens_table',1),(6,'2016_06_01_000004_create_oauth_clients_table',1),(7,'2016_06_01_000005_create_oauth_personal_access_clients_table',1),(26,'2019_03_12_114600_widget_window_conversion',2),(27,'2019_03_12_115925_add_for_test_to_antigen',2),(28,'2019_03_12_120310_add_default_fill_volume_to_provider_config',2),(29,'2019_03_13_073259_create_antigen_extract_view',2),(30,'2019_03_13_073740_create_gen2_log_view',2),(31,'2019_03_13_074042_create_printer_table',2),(32,'2019_03_13_074851_create_template_table',2),(33,'2019_03_13_075432_create_print_queue_table',2),(34,'2019_03_13_093608_create_template_printer_table',2),(35,'2019_03_13_094602_add_template_id_to_reports_table',2),(36,'2019_03_13_094614_add_document_to_reports_table',2),(37,'2019_03_13_095123_add_reports_id_to_patient_files_table',2),(38,'2019_03_13_095314_create_privilege_table',2),(39,'2019_03_13_095645_create_user_group_table',2),(40,'2019_03_13_095850_create_user_group_privilege_table',2),(41,'2019_03_13_102456_create_user_group_user_table',2),(42,'2019_03_26_080846_create_api_queue_table',2),(43,'2019_03_26_081607_create_api_failure_queue_table',2),(44,'2019_03_29_140610_create_account_status_table',2),(45,'2019_03_29_141138_add_notes_to_account',2),(46,'2019_03_29_141211_add_reference_number_to_account',2),(47,'2019_03_29_141228_add_account_status_id_to_account',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mirth_log`
--

DROP TABLE IF EXISTS `mirth_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mirth_log` (
  `mirth_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(16) NOT NULL,
  `channel_message_id` int(11) NOT NULL,
  `xtract_order_number` varchar(64) NOT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  `event` varchar(128) DEFAULT NULL,
  `error` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`mirth_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mirth_log`
--

LOCK TABLES `mirth_log` WRITE;
/*!40000 ALTER TABLE `mirth_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `mirth_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_tokens`
--

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
INSERT INTO `oauth_access_tokens` VALUES ('9a6f0c920d809601cc689b27b676bf08d07f4f3a7686a73bcff1fdfc1e77facc487d0493e8a9e728',2,2,NULL,'[]',0,'2018-10-08 20:24:49','2018-10-08 20:24:49','2018-10-08 13:34:49');
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `scopes` text COLLATE utf8_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_auth_codes`
--

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES (2,NULL,'Xtract Solutions Password Grant','4fhvhEGt000xB89ibIAJqSMMxGLTIl5K99ET4dBe','http://localhost',0,1,0,NULL,NULL);
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_personal_access_clients`
--

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
INSERT INTO `oauth_refresh_tokens` VALUES ('313f40f86e08f5fdef1786b7b4506f356c28ec08958ab0cbb651688465d144551909598e8a43c3ce','9a6f0c920d809601cc689b27b676bf08d07f4f3a7686a73bcff1fdfc1e77facc487d0493e8a9e728',0,'2018-10-08 13:39:49');
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `padlock`
--

DROP TABLE IF EXISTS `padlock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `padlock` (
  `lock_id` int(11) NOT NULL AUTO_INCREMENT,
  `locked_until` datetime NOT NULL,
  `locked_by` varchar(16) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`lock_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `padlock`
--

LOCK TABLES `padlock` WRITE;
/*!40000 ALTER TABLE `padlock` DISABLE KEYS */;
/*!40000 ALTER TABLE `padlock` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER auto_manage_legacy_patient_config_lock_delete BEFORE DELETE ON `padlock`
    FOR EACH ROW BEGIN
      delete from patient_config where lock_id=OLD.lock_id;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `panel`
--

DROP TABLE IF EXISTS `panel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `panel` (
  `panel_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `class` varchar(45) DEFAULT NULL,
  `panelcol` varchar(45) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`panel_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panel`
--

LOCK TABLES `panel` WRITE;
/*!40000 ALTER TABLE `panel` DISABLE KEYS */;
/*!40000 ALTER TABLE `panel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `panel_antigen`
--

DROP TABLE IF EXISTS `panel_antigen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `panel_antigen` (
  `panel_antigen_id` int(11) NOT NULL AUTO_INCREMENT,
  `panel_id` int(11) NOT NULL,
  `antigen_id` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`panel_antigen_id`),
  KEY `panel_id` (`panel_id`,`antigen_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panel_antigen`
--

LOCK TABLES `panel_antigen` WRITE;
/*!40000 ALTER TABLE `panel_antigen` DISABLE KEYS */;
/*!40000 ALTER TABLE `panel_antigen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `mi` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `botCheck` date DEFAULT '2039-12-18',
  `maintStart` date DEFAULT NULL,
  `shotStart` date DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `addr1` varchar(100) DEFAULT NULL,
  `addr2` varchar(100) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zip` varchar(45) DEFAULT NULL,
  `displayname` varchar(45) DEFAULT NULL,
  `faceimage` varchar(45) DEFAULT NULL,
  `chart` varchar(45) DEFAULT NULL,
  `lockState` int(11) DEFAULT '0',
  `lockby` varchar(45) DEFAULT NULL,
  `lock_id` int(11) DEFAULT NULL,
  `patient_notes` text,
  `eContact` varchar(45) DEFAULT NULL,
  `eContactNum` varchar(45) DEFAULT NULL,
  `idcode` varchar(45) DEFAULT NULL,
  `user_id` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `smsphone` varchar(45) DEFAULT NULL,
  `archived` varchar(45) NOT NULL DEFAULT 'F',
  `box1` varchar(5) DEFAULT NULL,
  `box2` varchar(5) DEFAULT NULL,
  `box3` varchar(5) DEFAULT NULL,
  `contactby` varchar(5) DEFAULT NULL,
  `listOptIn` varchar(65) DEFAULT NULL,
  `reviewby` varchar(150) DEFAULT NULL,
  `PV1segment` text,
  `PIDsegment` text,
  `gender` char(1) DEFAULT NULL,
  `ssn` char(11) DEFAULT NULL,
  `provider_id` int(11) DEFAULT NULL,
  `province` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `fax` varchar(45) DEFAULT NULL,
  `phoneNotes` varchar(400) DEFAULT NULL,
  `external_id` varchar(100) DEFAULT '',
  `login_notes` text,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `numLateInjections` int(11) DEFAULT '0',
  `lateInjectionsStartDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `address_id` int(11) DEFAULT NULL,
  `bill_to` int(11) DEFAULT NULL,
  `ship_to` int(11) DEFAULT NULL,
  `face_image_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`patient_id`),
  KEY `fk_patient_provider_id1` (`provider_id`),
  KEY `lock_id` (`lock_id`),
  KEY `idx_patient_lastname_archived` (`lastname`,`archived`),
  KEY `idx_patient_chart_archived` (`chart`,`archived`),
  KEY `address_id` (`address_id`),
  KEY `bill_to` (`bill_to`),
  KEY `ship_to` (`ship_to`),
  KEY `face_image_id` (`face_image_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `fk_patient_padlock` FOREIGN KEY (`lock_id`) REFERENCES `padlock` (`lock_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_patient_padlock_lock_id` FOREIGN KEY (`lock_id`) REFERENCES `padlock` (`lock_id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `fk_patient_provider_id1` FOREIGN KEY (`provider_id`) REFERENCES `provider` (`provider_id`),
  CONSTRAINT `patient_ibfk_1` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`),
  CONSTRAINT `patient_ibfk_2` FOREIGN KEY (`bill_to`) REFERENCES `address` (`address_id`),
  CONSTRAINT `patient_ibfk_3` FOREIGN KEY (`ship_to`) REFERENCES `address` (`address_id`),
  CONSTRAINT `patient_ibfk_4` FOREIGN KEY (`face_image_id`) REFERENCES `image` (`image_id`),
  CONSTRAINT `patient_ibfk_5` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (1,NULL,NULL,NULL,NULL,'2039-12-18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'manualIn',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'T',NULL,NULL,NULL,NULL,NULL,NULL,'PV1|PV1_WILL_GO_HERE_BUT_NONE_HAVE_BEEN_SENT_THROUGH_ADT||||||',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0000-00-00 00:00:00',NULL,'2017-11-16 17:09:34',NULL,0,'2018-06-25 21:26:56',NULL,NULL,NULL,NULL,NULL),(2,'TEST','XTRACT','Q','1970-01-01','2039-12-18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Test Display Name 2',NULL,'000000',0,NULL,NULL,'|||NOPOP',NULL,NULL,NULL,NULL,NULL,NULL,'F',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'',NULL,'2018-10-08 20:24:50',NULL,'2018-01-11 21:25:34',NULL,0,'2018-06-25 21:26:56',NULL,NULL,NULL,NULL,NULL),(3,'TEST','XTRACT','Q','1970-01-01','2039-12-18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Test Display Name 3',NULL,'000001',0,NULL,NULL,'|||NOPOP',NULL,NULL,NULL,NULL,NULL,NULL,'F',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'',NULL,'0000-00-00 00:00:00',NULL,'2018-01-11 21:25:34',NULL,0,'2018-06-25 21:26:56',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER auto_manage_legacy_patient_config_lock BEFORE UPDATE ON `patient`
    FOR EACH ROW BEGIN
      IF (NEW.lock_id is not null && (select count(*) from patient_config where lock_id=NEW.lock_id) < 1) THEN
        set @LockByName = '';
        set @LockBy = 0;
        set @LockAt = 0;
        select locked_by, created_at INTO @LockByName, @LockAt from padlock where lock_id=NEW.lock_id;
        select user_id INTO @LockBy from terminal where compname = @LockByName limit 1;
        insert into patient_config (name, value, patient_id, lock_id, created_by, created_at) values('lock', concat('legacy_lock',NEW.lock_id), OLD.patient_id, NEW.lock_id, @LockBy, @LockAt);
      ELSEIF (NEW.lock_id is null && OLD.lock_id is not NULL && (select count(*) from patient_config where lock_id=OLD.lock_id) > 0) THEN
        delete from patient_config where lock_id=OLD.lock_id;
      END IF;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `patient_config`
--

DROP TABLE IF EXISTS `patient_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_config` (
  `patient_config_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `value` text NOT NULL,
  `lock_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`patient_config_id`),
  KEY `fk_patient_config_patient_id_idx` (`patient_id`),
  KEY `lock_id` (`lock_id`),
  CONSTRAINT `fk_patient_config_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `patient_config_ibfk_1` FOREIGN KEY (`lock_id`) REFERENCES `padlock` (`lock_id`)
) ENGINE=InnoDB AUTO_INCREMENT=259 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_config`
--

LOCK TABLES `patient_config` WRITE;
/*!40000 ALTER TABLE `patient_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_files`
--

DROP TABLE IF EXISTS `patient_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_files` (
  `patient_files_id` int(11) NOT NULL AUTO_INCREMENT,
  `path1` varchar(150) DEFAULT NULL,
  `path2` varchar(150) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `deleted` varchar(11) DEFAULT 'F',
  `prescription_num` varchar(10) DEFAULT '',
  `reports_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`patient_files_id`),
  KEY `patient_file_user_id_idx` (`user_id`),
  KEY `patient_files_id_idx` (`patient_id`),
  KEY `patient_files_reports_id_foreign` (`reports_id`),
  CONSTRAINT `fk_paFiles_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_paFiles_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `patient_files_reports_id_foreign` FOREIGN KEY (`reports_id`) REFERENCES `reports` (`reports_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_files`
--

LOCK TABLES `patient_files` WRITE;
/*!40000 ALTER TABLE `patient_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_questionnaire`
--

DROP TABLE IF EXISTS `patient_questionnaire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_questionnaire` (
  `patient_id` int(11) NOT NULL,
  `questionnaire_id` int(11) NOT NULL,
  `recurring` char(1) DEFAULT 'F',
  `frequency` int(11) DEFAULT '0',
  UNIQUE KEY `patient_id` (`patient_id`,`questionnaire_id`),
  KEY `questionnaire_id` (`questionnaire_id`),
  CONSTRAINT `patient_questionnaire_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `patient_questionnaire_ibfk_2` FOREIGN KEY (`questionnaire_id`) REFERENCES `questionnaire` (`questionnaire_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_questionnaire`
--

LOCK TABLES `patient_questionnaire` WRITE;
/*!40000 ALTER TABLE `patient_questionnaire` DISABLE KEYS */;
INSERT INTO `patient_questionnaire` VALUES (2,1,'F',0);
/*!40000 ALTER TABLE `patient_questionnaire` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_temp`
--

DROP TABLE IF EXISTS `patient_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_temp` (
  `patient_temp_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `mi` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `chart` varchar(45) DEFAULT NULL,
  `external_id` varchar(100) DEFAULT NULL,
  `MSHsegment` varchar(1114) DEFAULT NULL,
  `eContact` varchar(45) DEFAULT NULL,
  `eContactNum` varchar(45) DEFAULT NULL,
  `PV1segment` text,
  `PIDsegment` text,
  `MRGsegment` varchar(500) DEFAULT NULL,
  `hl7message` text,
  `gender` char(1) DEFAULT '',
  `ssn` char(11) DEFAULT NULL,
  `deferred` varchar(45) DEFAULT 'F',
  `deferReason` text,
  `deferdate` timestamp NOT NULL DEFAULT '2000-01-01 08:00:00',
  `emaildate` timestamp NOT NULL DEFAULT '2000-01-01 08:00:00',
  `successdate` timestamp NOT NULL DEFAULT '2000-01-01 08:00:00',
  `successResult` text,
  `home_phone` varchar(20) DEFAULT NULL,
  `addr1` varchar(100) DEFAULT NULL,
  `addr2` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zip` varchar(45) DEFAULT NULL,
  `guar_last` varchar(45) DEFAULT NULL,
  `guar_first` varchar(45) DEFAULT NULL,
  `guar_mi` varchar(5) DEFAULT NULL,
  `guar_suffix` varchar(15) DEFAULT NULL,
  `guar_addr1` varchar(100) DEFAULT NULL,
  `guar_addr2` varchar(100) DEFAULT NULL,
  `guar_city` varchar(100) DEFAULT NULL,
  `guar_state` varchar(30) DEFAULT NULL,
  `guar_zip` varchar(20) DEFAULT NULL,
  `prim_carrier` varchar(20) DEFAULT NULL,
  `sec_carrier` varchar(20) DEFAULT NULL,
  `paLocPOC` varchar(45) DEFAULT '',
  `paLocFacility` varchar(45) DEFAULT '',
  `provFirst` varchar(45) DEFAULT '',
  `provLast` varchar(45) DEFAULT '',
  `provMI` varchar(45) DEFAULT '',
  `provCode` varchar(45) DEFAULT '',
  `provSuffix` varchar(45) DEFAULT '',
  `botCheck` date DEFAULT '2039-12-18',
  `maintStart` date DEFAULT '2039-12-18',
  `shotStart` date DEFAULT '2039-12-18',
  `phone` varchar(45) DEFAULT NULL,
  `displayName` varchar(45) DEFAULT NULL,
  `faceImage` varchar(45) DEFAULT NULL,
  `lockState` int(11) DEFAULT '0',
  `lockBy` varchar(45) DEFAULT NULL,
  `patient_notes` text,
  `idCode` varchar(45) DEFAULT NULL,
  `user_id` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `smsphone` varchar(45) DEFAULT NULL,
  `archived` varchar(45) NOT NULL DEFAULT 'F',
  `asthma` varchar(5) DEFAULT 'F',
  `medicare` varchar(5) DEFAULT 'F',
  `systemic` varchar(5) DEFAULT 'F',
  `contactBy` varchar(10) DEFAULT NULL,
  `listOptIn` varchar(65) DEFAULT NULL,
  `reviewBy` varchar(150) DEFAULT NULL,
  `owner` varchar(50) DEFAULT '',
  PRIMARY KEY (`patient_temp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_temp`
--

LOCK TABLES `patient_temp` WRITE;
/*!40000 ALTER TABLE `patient_temp` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postpone`
--

DROP TABLE IF EXISTS `postpone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postpone` (
  `postpone_id` int(11) NOT NULL AUTO_INCREMENT,
  `compound_id1` varchar(45) NOT NULL DEFAULT '0',
  `compound_id2` varchar(45) NOT NULL DEFAULT '0',
  `compound_id3` varchar(45) NOT NULL DEFAULT '0',
  `compound_id4` varchar(45) NOT NULL DEFAULT '0',
  `compound_id5` varchar(45) NOT NULL DEFAULT '0',
  `compound_id6` varchar(45) NOT NULL DEFAULT '0',
  `compound_id7` varchar(45) NOT NULL DEFAULT '0',
  `compound_id8` varchar(45) NOT NULL DEFAULT '0',
  `postponeDate` date DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `labelPrinted` varchar(11) DEFAULT 'F',
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  PRIMARY KEY (`postpone_id`),
  KEY `user_id_idx` (`user_id`),
  KEY `idx_postpone_deleted` (`deleted`),
  KEY `idx_postpone_compound1` (`compound_id1`),
  KEY `idx_postpone_compound2` (`compound_id2`),
  KEY `idx_postpone_compound3` (`compound_id3`),
  KEY `idx_postpone_compound4` (`compound_id4`),
  KEY `idx_postpone_compound5` (`compound_id5`),
  KEY `idx_postpone_compound6` (`compound_id6`),
  KEY `idx_postpone_compound7` (`compound_id7`),
  KEY `idx_postpone_compound8` (`compound_id8`),
  CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postpone`
--

LOCK TABLES `postpone` WRITE;
/*!40000 ALTER TABLE `postpone` DISABLE KEYS */;
INSERT INTO `postpone` VALUES (14,'6','7','8','0','0','0','0','0','2018-06-03',2,'F','F');
/*!40000 ALTER TABLE `postpone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `pp_bottles`
--

DROP TABLE IF EXISTS `pp_bottles`;
/*!50001 DROP VIEW IF EXISTS `pp_bottles`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `pp_bottles` AS SELECT 
 1 AS `postpone_id`,
 1 AS `bottles`,
 1 AS `user_id`,
 1 AS `labelPrinted`,
 1 AS `deleted`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `prescription`
--

DROP TABLE IF EXISTS `prescription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescription` (
  `prescription_id` int(11) NOT NULL AUTO_INCREMENT,
  `prescription_num` varchar(45) DEFAULT NULL,
  `provider_signature` varchar(45) DEFAULT NULL,
  `prescription_note` text,
  `strikethrough` varchar(10) DEFAULT NULL,
  `strikethrough_reason` text,
  `5or10` varchar(45) NOT NULL,
  `customUnits` varchar(45) DEFAULT 'v/v',
  `multiplier` int(11) DEFAULT '1',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `treatment_plan_id` int(11) DEFAULT '-1',
  `clinic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `diagnosis_id` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `provider_config_id` int(11) DEFAULT NULL,
  `priority` varchar(45) DEFAULT '-1',
  `site` varchar(64) DEFAULT NULL,
  `doseRuleNames_id` int(11) DEFAULT '-1',
  `source` varchar(45) DEFAULT 'XPS',
  `external_id` varchar(100) DEFAULT '',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`prescription_id`),
  KEY `fk_prescription_clinic1_idx` (`clinic_id`),
  KEY `fk_prescription_user1_idx` (`user_id`),
  KEY `fk_prescription_provider1_idx` (`provider_id`),
  KEY `fk_prescription_diagnosis1_idx` (`diagnosis_id`),
  KEY `fk_prescription_patient1_idx` (`patient_id`),
  KEY `fk_prescription_provider_config1` (`provider_config_id`),
  KEY `idx_prescription_strikethrough` (`strikethrough`),
  CONSTRAINT `fk_prescription_clinic1` FOREIGN KEY (`clinic_id`) REFERENCES `clinic` (`clinic_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_prescription_diagnosis1` FOREIGN KEY (`diagnosis_id`) REFERENCES `diagnosis` (`diagnosis_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_prescription_patient1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_prescription_provider1` FOREIGN KEY (`provider_id`) REFERENCES `provider` (`provider_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_prescription_provider_config1` FOREIGN KEY (`provider_config_id`) REFERENCES `provider_config` (`provider_config_id`),
  CONSTRAINT `fk_prescription_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescription`
--

LOCK TABLES `prescription` WRITE;
/*!40000 ALTER TABLE `prescription` DISABLE KEYS */;
INSERT INTO `prescription` VALUES (1,'900000',NULL,NULL,'F',NULL,'-1','v/v',1,'2018-01-05 20:32:28',-1,1,2,1,1,2,1,'0',NULL,-1,'XPS','','0000-00-00 00:00:00',NULL,'2018-01-05 20:32:28',NULL),(2,'900001',NULL,NULL,'F',NULL,'-1','v/v',1,'2018-01-05 20:32:57',-1,1,2,1,1,2,1,'0',NULL,-1,'XPS','','0000-00-00 00:00:00',NULL,'2018-01-05 20:32:57',NULL),(3,'900002',NULL,NULL,'F',NULL,'-1','v/v',1,'2018-02-06 19:02:52',1,2,2,1,1,2,1,'0',NULL,1,'XST','','2018-02-06 19:02:52',NULL,'2018-01-13 21:50:45',NULL),(4,'900003',NULL,NULL,'F',NULL,'-1','v/v',1,'2018-10-08 20:24:50',-1,2,2,1,4,2,1,'-1',NULL,-1,'API','','0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',NULL);
/*!40000 ALTER TABLE `prescription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `print_queue`
--

DROP TABLE IF EXISTS `print_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `print_queue` (
  `print_queue_id` int(11) NOT NULL AUTO_INCREMENT,
  `printer_id` int(11) NOT NULL,
  `copies` int(11) NOT NULL DEFAULT '1',
  `reports_id` int(11) NOT NULL,
  `processed_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT 'submitted',
  `auth_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`print_queue_id`),
  KEY `print_queue_reports_id_foreign` (`reports_id`),
  KEY `print_queue_printer_id_foreign` (`printer_id`),
  KEY `print_queue_created_by_foreign` (`created_by`),
  CONSTRAINT `print_queue_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `print_queue_printer_id_foreign` FOREIGN KEY (`printer_id`) REFERENCES `printer` (`printer_id`),
  CONSTRAINT `print_queue_reports_id_foreign` FOREIGN KEY (`reports_id`) REFERENCES `reports` (`reports_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_queue`
--

LOCK TABLES `print_queue` WRITE;
/*!40000 ALTER TABLE `print_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `print_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printer`
--

DROP TABLE IF EXISTS `printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `printer` (
  `printer_id` int(11) NOT NULL AUTO_INCREMENT,
  `external_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`printer_id`),
  UNIQUE KEY `printer_external_id_unique` (`external_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printer`
--

LOCK TABLES `printer` WRITE;
/*!40000 ALTER TABLE `printer` DISABLE KEYS */;
INSERT INTO `printer` VALUES (1,NULL,'Print to EMR','EMR',NULL);
/*!40000 ALTER TABLE `printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printlog`
--

DROP TABLE IF EXISTS `printlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `printlog` (
  `printLog_id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(200) DEFAULT NULL,
  `printDate` timestamp NULL DEFAULT NULL,
  `printErrMsg` text,
  `mirthDate` timestamp NULL DEFAULT NULL,
  `mirthErrMsg` text,
  `emrDate` timestamp NULL DEFAULT NULL,
  `emrErrMsg` text,
  `transaction` varchar(15) DEFAULT NULL,
  `deleted` varchar(5) NOT NULL DEFAULT 'F',
  `patient_id` int(11) NOT NULL,
  `terminal_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`printLog_id`),
  KEY `fk_printLog_patient_idx` (`patient_id`),
  KEY `fk_printLog_terminal_idx` (`terminal_id`),
  KEY `fk_printLog_user_idx` (`user_id`),
  CONSTRAINT `fk_printLog_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_printLog_terminal` FOREIGN KEY (`terminal_id`) REFERENCES `terminal` (`terminal_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_printLog_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printlog`
--

LOCK TABLES `printlog` WRITE;
/*!40000 ALTER TABLE `printlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `printlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `privilege`
--

DROP TABLE IF EXISTS `privilege`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilege` (
  `privilege_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`privilege_id`),
  UNIQUE KEY `privilege_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privilege`
--

LOCK TABLES `privilege` WRITE;
/*!40000 ALTER TABLE `privilege` DISABLE KEYS */;
INSERT INTO `privilege` VALUES (20,'activate_vials_update'),(41,'all_users_create'),(43,'all_users_delete'),(40,'all_users_read'),(42,'all_users_update'),(44,'config_create'),(46,'config_delete'),(45,'config_update'),(24,'dosing_plan_create'),(26,'dosing_plan_delete'),(25,'dosing_plan_update'),(37,'extract_create'),(39,'extract_delete'),(38,'extract_update'),(15,'injection_adjust_create'),(17,'injection_adjust_delete'),(16,'injection_adjust_update'),(2,'injection_create'),(4,'injection_delete'),(1,'injection_read'),(3,'injection_update'),(34,'inventory_create'),(36,'inventory_delete'),(35,'inventory_update'),(47,'message_create'),(28,'patient_create'),(30,'patient_delete'),(27,'patient_read'),(29,'patient_update'),(6,'prescription_create'),(10,'prescription_delete'),(8,'prescription_mix_update'),(5,'prescription_read'),(9,'prescription_status_update'),(7,'prescription_update'),(31,'provider_create'),(33,'provider_delete'),(32,'provider_update'),(18,'questionnaire_lockout_create'),(19,'questionnaire_lockout_delete'),(14,'skintest_delete'),(11,'skintest_read'),(13,'skintest_update'),(12,'skintestn_create'),(21,'treatment_plan_create'),(23,'treatment_plan_delete'),(22,'treatment_plan_update'),(49,'xtract_admin'),(48,'xtract_support');
/*!40000 ALTER TABLE `privilege` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `protocol`
--

DROP TABLE IF EXISTS `protocol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `protocol` (
  `protocol_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `test_config` text,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`protocol_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `protocol`
--

LOCK TABLES `protocol` WRITE;
/*!40000 ALTER TABLE `protocol` DISABLE KEYS */;
INSERT INTO `protocol` VALUES (1,'Simple','{\"name\":\"Simple\",\"score_column\":3,\"version\":2,\"cols\":[{\"name\":\"W1\",\"report_name\":\"Wheal 1\",\"width\":35,\"color\":\"#e5e8f4\"},{\"name\":\"W2\",\"report_name\":\"Wheal 2\",\"width\":35,\"color\":\"#e5f4e5\"},{\"name\":\"Score\",\"report_name\":\"Score\",\"width\":50,\"is_score\":true}],\"scoring_code\":\"\\/\\/ Very simple method\\r\\n\\r\\nfunction ScoreProtocol(parms) {\\r\\n\\t\\\"use strict\\\";\\r\\n\\t\\r\\n\\tvar context = parms;\\r\\n\\t\\r\\n\\t\\/\\/ define column names\\r\\n\\tvar wheal1Col = 1, wheal2Col = 2, scoreCol = 3;\\r\\n\\r\\n\\tvar wheal1Val\\t= function (v) { return context.cell_value(wheal1Col, v); };\\r\\n\\tvar wheal2Val\\t= function (v) { return context.cell_value(wheal2Col, v); };\\r\\n\\tvar scoreVal\\t= function (v) { return context.cell_value(scoreCol, v); };\\r\\n\\t\\r\\n\\tfunction changeScore (key, col, colcount, isControl){\\r\\n\\t\\t\\/\\/ the user has entered a key in a column, adjust score accordingly\\r\\n\\t\\t\\r\\n\\t\\tif (key == \'0\' && ((col == wheal1Col || col == wheal2Col))){\\r\\n\\t\\t\\tif (col == wheal2Col){\\r\\n\\t\\t\\t\\tcol--;\\r\\n\\t\\t\\t}\\r\\n\\t\\t\\tvar count = 0;\\r\\n\\t\\t\\twhile (count < colcount){\\r\\n\\t\\t\\t\\tvar tmp = col + count;\\r\\n\\t\\t\\t\\tcontext.cell_value(tmp,0);\\r\\n\\t\\t\\t\\tcount++;\\r\\n\\t\\t\\t}\\r\\n\\t\\t\\tcol = colcount + 1;\\r\\n\\t\\t}\\r\\n\\t\\telse{\\r\\n\\t\\t\\tcontext.cell_value(col, key);\\r\\n\\t\\t\\tif (col == wheal1Col || col == wheal2Col){\\r\\n\\t\\t\\t\\tvar a = wheal1Val();\\r\\n\\t\\t\\t\\tvar b = wheal2Val();\\r\\n\\t\\t\\t\\tvar total = a\\/2*b\\/2*Math.PI;\\t\\/\\/do scoring calculations\\r\\n\\t\\t\\t\\t\\r\\n\\t\\t\\t\\tif ((total >= 0) && (total < 10)){\\r\\n\\t\\t\\t\\t\\tscoreVal(\'0\');\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse if ((total >= 10) && (total < 100)){\\r\\n\\t\\t\\t\\t\\tscoreVal(\'1\');\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse if ((total >= 100) && (total < 200)){\\r\\n\\t\\t\\t\\t\\tscoreVal(\'2\');\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse if ((total >= 200) && (total < 300)){\\r\\n\\t\\t\\t\\t\\tscoreVal(\'3\');\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse if (total >= 300){\\r\\n\\t\\t\\t\\t\\tscoreVal(\'4\');\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse{\\r\\n\\t\\t\\t\\t\\tscoreVal(\'Err\');\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\t\\r\\n\\t\\t\\t\\tif (col == wheal1Col){\\r\\n\\t\\t\\t\\t\\tcol += 1;\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse{\\r\\n\\t\\t\\t\\t\\tcol += 2;\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t}\\r\\n\\t\\t}\\r\\n\\t\\t\\r\\n\\t\\tcontext.move_to(col);\\r\\n\\t}\\r\\n\\r\\n\\treturn {\\r\\n\\t\\tversion: function () {\\r\\n\\t\\t\\treturn \\\"2.0\\\"\\r\\n\\t\\t},\\r\\n\\t\\t\\r\\n\\t\\tscoreFormatCol: function (col, value){\\r\\n\\t\\t\\t\\/\\/ given a col number and a value, return a formatted string \\r\\n\\t\\t\\t\\r\\n\\t\\t\\tif (value === null || value === \'\'){\\r\\n\\t\\t\\t\\treturn \'\';\\r\\n\\t\\t\\t}\\r\\n\\t\\t\\t\\r\\n\\t\\t\\tif (col  ==  scoreCol && value > 0){\\r\\n\\t\\t\\t\\treturn value + \'+\';\\r\\n\\t\\t\\t}\\r\\n\\t\\t\\t\\r\\n\\t\\t\\treturn value;\\r\\n\\t\\t},\\r\\n\\t\\t\\r\\n\\t\\tscoreParseCol: function (col, value){\\r\\n\\t\\t\\t\\/\\/ given a col number and a string, parse the string and return a numeric value \\r\\n\\t\\t\\t\\r\\n\\t\\t\\treturn value == \'\' ? \'\' : parseFloat (value);\\r\\n\\t\\t},\\r\\n\\t\\t\\r\\n\\t\\tscoreKey: function (key, col, colcount, isControl, row){\\r\\n\\t\\t\\tif (col == wheal1Col || col == wheal2Col){\\r\\n\\t\\t\\t\\tif (context.cell_value(col) !== \'\' && (key === \'\' || parseInt(key) !== context.cell_value(col))){\\r\\n\\t\\t\\t\\t\\tcontext.confirm_change (context.cell_value(col), key, isControl, changeScore, row);\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse{\\r\\n\\t\\t\\t\\t\\tchangeScore (key, col, colcount, isControl);\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t}\\r\\n\\t\\t}\\r\\n\\t}\\r\\n}\\r\\n\"}','2018-01-18 17:52:42');
/*!40000 ALTER TABLE `protocol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider`
--

DROP TABLE IF EXISTS `provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provider` (
  `provider_id` int(11) NOT NULL AUTO_INCREMENT,
  `first` varchar(45) DEFAULT NULL,
  `last` varchar(45) DEFAULT NULL,
  `mi` varchar(45) DEFAULT NULL,
  `displayname` varchar(45) DEFAULT NULL,
  `displaynameS` varchar(45) DEFAULT NULL,
  `suffix` varchar(45) DEFAULT NULL,
  `addr1` varchar(45) DEFAULT NULL,
  `addr2` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zip` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `fax` varchar(45) DEFAULT NULL,
  `provider_notes` text,
  `rate` int(11) DEFAULT '10',
  `faceimage` varchar(45) DEFAULT NULL,
  `licensenumber` varchar(45) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `providerNum` varchar(45) DEFAULT NULL,
  `deaNum` varchar(45) DEFAULT NULL,
  `contactName` varchar(100) DEFAULT NULL,
  `contactPhone` varchar(100) DEFAULT NULL,
  `account` varchar(45) DEFAULT '',
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  `emrCode` varchar(11) DEFAULT NULL,
  `nonXtract` varchar(45) NOT NULL DEFAULT 'F',
  `general` varchar(150) DEFAULT NULL,
  `external_id` varchar(100) DEFAULT '',
  `country` varchar(45) DEFAULT NULL,
  `province` varchar(45) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`provider_id`),
  KEY `account_id` (`account_id`),
  KEY `address_id` (`address_id`),
  CONSTRAINT `provider_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`),
  CONSTRAINT `provider_ibfk_2` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider`
--

LOCK TABLES `provider` WRITE;
/*!40000 ALTER TABLE `provider` DISABLE KEYS */;
INSERT INTO `provider` VALUES (1,'Default','Doctor','','Default Doctor, MD','D. Doctor','MD','123 Main St.','','Anytown','OR','97000','(555) 555-5555','(555) 555-5555','Doctor sometimes has send-outs to satellite clinics.',10,NULL,' ','','','','','','','F','','F',NULL,'',NULL,NULL,1,NULL),(2,'Weyland','Yutani','C','Weyland C. Yutani, MD',NULL,'MD','','','','','','','','',10,NULL,'568465test','','','','','','','F',NULL,'F',NULL,'',NULL,NULL,1,NULL);
/*!40000 ALTER TABLE `provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_config`
--

DROP TABLE IF EXISTS `provider_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provider_config` (
  `provider_config_id` int(11) NOT NULL AUTO_INCREMENT,
  `numorder` int(11) DEFAULT NULL,
  `color` varchar(100) DEFAULT NULL,
  `colorNames` varchar(45) DEFAULT NULL,
  `dilutions10` varchar(80) DEFAULT NULL,
  `dilutions5` varchar(45) DEFAULT NULL,
  `expirations10` varchar(45) DEFAULT NULL,
  `expirations5` varchar(45) DEFAULT NULL,
  `billrate10` varchar(45) DEFAULT NULL,
  `billrate5` varchar(45) DEFAULT NULL,
  `profileRate` int(11) DEFAULT '10',
  `offset` int(11) DEFAULT '0',
  `profileName` varchar(45) NOT NULL DEFAULT '',
  `lowGlyc` decimal(5,2) DEFAULT '0.00',
  `highGlyc` decimal(5,2) DEFAULT '50.00',
  `defVialSize` varchar(15) DEFAULT '5 mL',
  `paAlertLast` varchar(11) DEFAULT '2015-1-1',
  `paAlertPeriod` varchar(11) DEFAULT '0',
  `paAlertEvent` varchar(11) DEFAULT '0',
  `paAlertVol` decimal(5,2) DEFAULT '0.00',
  `inclDilName` varchar(5) DEFAULT 'F',
  `prefGlycDil` int(11) DEFAULT NULL,
  `prefAqDil` int(11) DEFAULT NULL,
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  `provider_id` int(11) NOT NULL,
  `custDils` varchar(100) DEFAULT '',
  `doseRules` text,
  `default_fill_volume` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`provider_config_id`),
  KEY `fk_provider_config_provider1_idx` (`provider_id`),
  CONSTRAINT `fk_provider_config_provider1` FOREIGN KEY (`provider_id`) REFERENCES `provider` (`provider_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_config`
--

LOCK TABLES `provider_config` WRITE;
/*!40000 ALTER TABLE `provider_config` DISABLE KEYS */;
INSERT INTO `provider_config` VALUES (1,1,'16711680,16776960,255,65280,13684944,0,0,0','RED,YLW,BLUE,GRN,SLVR,,,','1,2,10,100,200,8,8,8','8,8,8,8,8,8,8,8','12,9,6,3,3,0,0,0','0,0,0,0,0,0,0,0',' , , , , , , , ',' , , , , , , , ',-1,0,'AAAAI_STND',20.00,50.00,'5 mL','2017-07-11','1','0',0.00,'F',2,4,'F',1,'',NULL,NULL),(2,1,'16711680,16776960,255,65280,13684944,0,0,0','RED,YLW,BLUE,GRN,SLVR,,,','0,1,2,3,4,8,8,8','8,8,8,8,8,8,8,8','12,9,6,3,3,0,0,0','0,0,0,0,0,0,0,0',NULL,NULL,10,0,'SCIT',0.00,100.00,'5 mL','2015-1-1','0','0',0.00,'F',2,4,'F',1,'',NULL,NULL),(3,1,'16711680,16776960,255,65280,0,0,0,0','RED,YLW,BLUE,GRN,,,,','8,8,8,8,8,8,8,8','0,1,2,3,8,8,8,8','0,0,0,0,0,0,0,0','6,6,6,6,0,0,0,0',NULL,NULL,5,0,'SLIT',0.00,100.00,'5 mL','2015-1-1','0','0',0.00,'F',2,4,'F',1,'',NULL,NULL),(4,1,'16711680,16776960,255,65280,13684944,4456618,0,0','RED,YLW,BLUE,GRN,SLVR,PRPL,,','0,1,2,3,4,5,8,8','8,8,8,8,8,8,8,8','12,9,6,3,3,3,0,0','0,0,0,0,0,0,0,0',' , , , , , , , ',' , , , , , , , ',10,0,'AAAAI Normal',0.00,50.00,'5 mL','2015-1-1','0','0',0.00,'F',2,3,'F',2,'',NULL,NULL),(5,0,'9002752,16748842,4456618,13684944,65280,255,16776960,16711680','GOLD,ORNG,PRPL,SLVR,GRN,BLUE,YLW,RED','7,6,5,4,3,2,1,0','8,8,8,8,8,8,8,8','3,3,3,3,3,6,9,12','0,0,0,0,0,0,0,0',NULL,NULL,10,0,'Dr. Baker (REVERSE)',0.00,50.00,'5 mL','2015-1-1','0','0',0.00,'F',2,3,'F',2,'',NULL,NULL),(6,1,'16711680,16776960,255,65280,0,0,0,0','RED,YLW,BLUE,GRN,,,,','8,8,8,8,8,8,8,8','0,1,2,3,8,8,8,8','0,0,0,0,0,0,0,0','6,6,6,6,0,0,0,0',NULL,NULL,5,0,'SLIT',0.00,50.00,'5 mL','2015-1-1','0','0',0.00,'F',2,3,'F',2,'',NULL,NULL),(7,1,'16711680,16776960,255,65280,13684944,4456618,16748842,9002752','RED,YLW,BLUE,GRN,SLVR,PRPL,ORNG,GOLD','20,200,2000,10000,100000,1000000,10000000,100000000','8,8,8,8,8,8,8,8','12,12,12,12,12,12,12,12','0,0,0,0,0,0,0,0',NULL,NULL,-1,0,'Custom Dilution',0.00,50.00,'5 mL','2015-1-1','0','0',0.00,'F',2,3,'F',2,'',NULL,NULL);
/*!40000 ALTER TABLE `provider_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_def`
--

DROP TABLE IF EXISTS `provider_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provider_def` (
  `provider_def_id` int(11) NOT NULL AUTO_INCREMENT,
  `dose` varchar(45) DEFAULT NULL,
  `inseasonstart` varchar(45) DEFAULT NULL,
  `inseasonend` varchar(45) DEFAULT NULL,
  `outdates10` varchar(45) DEFAULT NULL,
  `outdates5` varchar(45) DEFAULT NULL,
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  `extract_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `provider_config_id` int(11) NOT NULL,
  PRIMARY KEY (`provider_def_id`),
  KEY `fk_provider_def_extract1_idx` (`extract_id`),
  KEY `fk_provider_def_provider1_idx` (`provider_id`),
  KEY `fk_provDef_provider_config1` (`provider_config_id`),
  CONSTRAINT `fk_provDef_provider_config1` FOREIGN KEY (`provider_config_id`) REFERENCES `provider_config` (`provider_config_id`),
  CONSTRAINT `fk_provider_def_extract1` FOREIGN KEY (`extract_id`) REFERENCES `extract` (`extract_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_provider_def_provider1` FOREIGN KEY (`provider_id`) REFERENCES `provider` (`provider_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_def`
--

LOCK TABLES `provider_def` WRITE;
/*!40000 ALTER TABLE `provider_def` DISABLE KEYS */;
INSERT INTO `provider_def` VALUES (1,'','','',NULL,NULL,'F',1,1,1),(2,'','','',NULL,NULL,'F',2,1,1),(3,'','','',NULL,NULL,'F',3,1,1),(4,'','','',NULL,NULL,'F',4,1,1),(5,'0.5','','',NULL,NULL,'F',5,1,1),(6,'0.5','','',NULL,NULL,'F',6,1,1),(7,'0.5','','',NULL,NULL,'F',7,1,1),(8,'0.5','','',NULL,NULL,'F',8,1,1),(9,'0.5','','',NULL,NULL,'F',9,1,1),(10,'0.5','','',NULL,NULL,'F',10,1,1),(11,'1.50','','',NULL,NULL,'F',11,1,1);
/*!40000 ALTER TABLE `provider_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `provider_profile`
--

DROP TABLE IF EXISTS `provider_profile`;
/*!50001 DROP VIEW IF EXISTS `provider_profile`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `provider_profile` AS SELECT 
 1 AS `provider_id`,
 1 AS `provider_config_id`,
 1 AS `displayname`,
 1 AS `licensenumber`,
 1 AS `nonXtract`,
 1 AS `profileName`,
 1 AS `numorder`,
 1 AS `profileRate`,
 1 AS `colorNames`,
 1 AS `color`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `pt`
--

DROP TABLE IF EXISTS `pt`;
/*!50001 DROP VIEW IF EXISTS `pt`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `pt` AS SELECT 
 1 AS `patient_id`,
 1 AS `firstname`,
 1 AS `lastname`,
 1 AS `mi`,
 1 AS `chart`,
 1 AS `dob`,
 1 AS `displayname`,
 1 AS `gender`,
 1 AS `provider_id`,
 1 AS `archived`,
 1 AS `PV1segment`,
 1 AS `PIDsegment`,
 1 AS `patient_notes`,
 1 AS `ssn`,
 1 AS `addr1`,
 1 AS `city`,
 1 AS `state`,
 1 AS `zip`,
 1 AS `phone`,
 1 AS `smsphone`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `pt_provider`
--

DROP TABLE IF EXISTS `pt_provider`;
/*!50001 DROP VIEW IF EXISTS `pt_provider`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `pt_provider` AS SELECT 
 1 AS `patient_id`,
 1 AS `firstname`,
 1 AS `lastname`,
 1 AS `chart`,
 1 AS `provider_id`,
 1 AS `displayname`,
 1 AS `last`,
 1 AS `first`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `pt_rx_inj`
--

DROP TABLE IF EXISTS `pt_rx_inj`;
/*!50001 DROP VIEW IF EXISTS `pt_rx_inj`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `pt_rx_inj` AS SELECT 
 1 AS `patient_id`,
 1 AS `chart`,
 1 AS `firstname`,
 1 AS `lastname`,
 1 AS `provider_id`,
 1 AS `provider_config_id`,
 1 AS `prescription_id`,
 1 AS `prescription_num`,
 1 AS `rx_treatment_plan_id`,
 1 AS `compound_id`,
 1 AS `BottleName`,
 1 AS `size`,
 1 AS `color`,
 1 AS `dilution`,
 1 AS `bottleNum`,
 1 AS `active`,
 1 AS `currVol`,
 1 AS `injection_id`,
 1 AS `dose`,
 1 AS `site`,
 1 AS `injection_date`,
 1 AS `user_id`,
 1 AS `inj_adjust_id`,
 1 AS `reaction`,
 1 AS `sysreaction`,
 1 AS `timestamp`,
 1 AS `inj_treatment_plan_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `pt_rx_provider`
--

DROP TABLE IF EXISTS `pt_rx_provider`;
/*!50001 DROP VIEW IF EXISTS `pt_rx_provider`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `pt_rx_provider` AS SELECT 
 1 AS `patient_id`,
 1 AS `firstname`,
 1 AS `lastname`,
 1 AS `chart`,
 1 AS `prescription_id`,
 1 AS `prescription_num`,
 1 AS `provider_id`,
 1 AS `displayname`,
 1 AS `last`,
 1 AS `first`,
 1 AS `last_injection`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `purchase_order`
--

DROP TABLE IF EXISTS `purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order` (
  `purchase_order_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `bill_to` int(11) DEFAULT NULL,
  `ship_to` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `priority` varchar(45) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `bill_to_name` varchar(64) DEFAULT NULL,
  `bill_to_phone` varchar(45) DEFAULT NULL,
  `ship_to_name` varchar(64) DEFAULT NULL,
  `ship_to_phone` varchar(45) DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`purchase_order_id`),
  KEY `bill_to` (`bill_to`),
  KEY `ship_to` (`ship_to`),
  KEY `account_id` (`account_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `purchase_order_ibfk_1` FOREIGN KEY (`bill_to`) REFERENCES `address` (`address_id`),
  CONSTRAINT `purchase_order_ibfk_2` FOREIGN KEY (`ship_to`) REFERENCES `address` (`address_id`),
  CONSTRAINT `purchase_order_ibfk_3` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`),
  CONSTRAINT `purchase_order_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `purchase_order_status` (`purchase_order_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order`
--

LOCK TABLES `purchase_order` WRITE;
/*!40000 ALTER TABLE `purchase_order` DISABLE KEYS */;
INSERT INTO `purchase_order` VALUES (1,1,NULL,NULL,'2018-06-25 21:27:16',NULL,'1970-01-01 08:00:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,1,NULL,NULL,'2018-06-25 21:27:16',NULL,'2018-01-13 21:50:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,1,NULL,NULL,'2018-06-25 21:27:16',NULL,'2018-06-03 16:30:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,1,NULL,NULL,'2018-10-08 20:24:50',NULL,'2018-10-08 20:24:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `purchase_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_status`
--

DROP TABLE IF EXISTS `purchase_order_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_status` (
  `purchase_order_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`purchase_order_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_status`
--

LOCK TABLES `purchase_order_status` WRITE;
/*!40000 ALTER TABLE `purchase_order_status` DISABLE KEYS */;
INSERT INTO `purchase_order_status` VALUES (1,'In Queue',0),(2,'Complete',1);
/*!40000 ALTER TABLE `purchase_order_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question` (
  `question_id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(45) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `BOX1` varchar(5) NOT NULL DEFAULT 'F',
  `BOX2` varchar(5) NOT NULL DEFAULT 'F',
  `BOX3` varchar(5) NOT NULL DEFAULT 'F',
  `goodAns` varchar(16) NOT NULL DEFAULT 'Either',
  `deleted` varchar(5) DEFAULT 'F',
  `qorder` int(11) NOT NULL DEFAULT '-1',
  `all` varchar(5) NOT NULL DEFAULT 'T',
  `note` text,
  `type` varchar(64) DEFAULT 'yes,no',
  `allow_multiple` char(1) DEFAULT 'F',
  `bad_answer` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (1,NULL,'yes / no question number 1','F','F','F','Either','F',-1,'T','test note','yes,no','F',NULL),(2,NULL,'numeric question number 2','F','F','F','Either','F',-1,'T','note 2','1,2,3,4','F','1,2'),(3,NULL,'multi answer question number 3','F','F','F','Either','F',-1,'T','note 3','1,2,3,4,5','T','1,2'),(4,NULL,'text question number 3','F','F','F','Either','F',-1,'T','note 4','text','T',NULL);
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questionnaire`
--

DROP TABLE IF EXISTS `questionnaire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questionnaire` (
  `questionnaire_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT 'un-named questionnaire',
  `minimum_frequency` int(11) DEFAULT '0',
  `box1` char(1) DEFAULT 'F',
  `box2` char(1) DEFAULT 'F',
  `box3` char(1) DEFAULT 'F',
  `allPatients` char(1) DEFAULT 'F',
  `deleted` char(1) DEFAULT 'F',
  PRIMARY KEY (`questionnaire_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questionnaire`
--

LOCK TABLES `questionnaire` WRITE;
/*!40000 ALTER TABLE `questionnaire` DISABLE KEYS */;
INSERT INTO `questionnaire` VALUES (1,'test questionnaire',30,'F','F','F','F','F');
/*!40000 ALTER TABLE `questionnaire` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questionnaire_question`
--

DROP TABLE IF EXISTS `questionnaire_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questionnaire_question` (
  `questionnaire_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  UNIQUE KEY `question_id` (`question_id`,`questionnaire_id`),
  KEY `questionnaire_id` (`questionnaire_id`),
  CONSTRAINT `questionnaire_question_ibfk_1` FOREIGN KEY (`questionnaire_id`) REFERENCES `questionnaire` (`questionnaire_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `questionnaire_question_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questionnaire_question`
--

LOCK TABLES `questionnaire_question` WRITE;
/*!40000 ALTER TABLE `questionnaire_question` DISABLE KEYS */;
INSERT INTO `questionnaire_question` VALUES (1,1),(1,2),(1,3),(1,4);
/*!40000 ALTER TABLE `questionnaire_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `reports_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `terminal_id` int(11) DEFAULT NULL,
  `xml` text NOT NULL,
  `report_path` varchar(256) DEFAULT NULL,
  `output_path` varchar(256) DEFAULT NULL,
  `report_type` varchar(32) NOT NULL,
  `submit_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `complete_time` datetime DEFAULT NULL,
  `app` varchar(32) NOT NULL,
  `retries` int(11) NOT NULL DEFAULT '0',
  `template_id` int(11) DEFAULT NULL,
  `document` mediumblob,
  PRIMARY KEY (`reports_id`),
  KEY `patient_id` (`patient_id`),
  KEY `user_id` (`user_id`),
  KEY `terminal_id` (`terminal_id`),
  KEY `reports_template_id_foreign` (`template_id`),
  CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  CONSTRAINT `reports_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `reports_ibfk_3` FOREIGN KEY (`terminal_id`) REFERENCES `terminal` (`terminal_id`),
  CONSTRAINT `reports_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `template` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `rx_bottles`
--

DROP TABLE IF EXISTS `rx_bottles`;
/*!50001 DROP VIEW IF EXISTS `rx_bottles`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rx_bottles` AS SELECT 
 1 AS `prescription_id`,
 1 AS `prescription_num`,
 1 AS `bottles`,
 1 AS `user_id`,
 1 AS `strikethrough`,
 1 AS `priority`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `rx_co_vi_pt`
--

DROP TABLE IF EXISTS `rx_co_vi_pt`;
/*!50001 DROP VIEW IF EXISTS `rx_co_vi_pt`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rx_co_vi_pt` AS SELECT 
 1 AS `mixdate`,
 1 AS `rx_id`,
 1 AS `rx_num`,
 1 AS `strikethrough`,
 1 AS `treatment_plan_id`,
 1 AS `compound_id`,
 1 AS `compound_receipt_id`,
 1 AS `VialName`,
 1 AS `size`,
 1 AS `color`,
 1 AS `dilution`,
 1 AS `bottleNum`,
 1 AS `active`,
 1 AS `currVol`,
 1 AS `barcode`,
 1 AS `dosing_id`,
 1 AS `inventory_id`,
 1 AS `patient_id`,
 1 AS `lastname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `rx_extract`
--

DROP TABLE IF EXISTS `rx_extract`;
/*!50001 DROP VIEW IF EXISTS `rx_extract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rx_extract` AS SELECT 
 1 AS `rx_id`,
 1 AS `prescription_num`,
 1 AS `name`,
 1 AS `dilution`,
 1 AS `dose`,
 1 AS `extract_id`,
 1 AS `deleted`,
 1 AS `abbreviation`,
 1 AS `latinname`,
 1 AS `manufacturer`,
 1 AS `code`,
 1 AS `isDiluent`,
 1 AS `percentGlycerin`,
 1 AS `percentPhenol`,
 1 AS `percentHSA`,
 1 AS `units`,
 1 AS `seasonStart`,
 1 AS `seasonEnd`,
 1 AS `cost`,
 1 AS `sub`,
 1 AS `specificgravity`,
 1 AS `outdatealert`,
 1 AS `visible`,
 1 AS `imagefile`,
 1 AS `color`,
 1 AS `silhouette`,
 1 AS `topline`,
 1 AS `firstline`,
 1 AS `secondline`,
 1 AS `compatibility_class_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `score`
--

DROP TABLE IF EXISTS `score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score` (
  `score_id` int(11) NOT NULL AUTO_INCREMENT,
  `skintest_id` int(11) NOT NULL,
  `antigen_id` int(11) DEFAULT NULL,
  `notes` text NOT NULL,
  `score1` int(11) DEFAULT NULL,
  `score2` int(11) DEFAULT NULL,
  `score3` int(11) DEFAULT NULL,
  `score4` int(11) DEFAULT NULL,
  `score5` int(11) DEFAULT NULL,
  `score6` int(11) DEFAULT NULL,
  `score7` int(11) DEFAULT NULL,
  `score8` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  PRIMARY KEY (`score_id`),
  KEY `antigen_id` (`antigen_id`),
  KEY `skintest_id` (`skintest_id`),
  CONSTRAINT `fk_score_antigen_antigen_id` FOREIGN KEY (`antigen_id`) REFERENCES `antigen` (`antigen_id`),
  CONSTRAINT `fk_score_skintest_skintest_id` FOREIGN KEY (`skintest_id`) REFERENCES `skintest` (`skintest_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score`
--

LOCK TABLES `score` WRITE;
/*!40000 ALTER TABLE `score` DISABLE KEYS */;
INSERT INTO `score` VALUES (1,1,6,'',1,2,0,NULL,NULL,NULL,NULL,NULL,'2018-01-18 17:52:57','F'),(2,1,10,'',5,6,1,NULL,NULL,NULL,NULL,NULL,'2018-01-18 17:52:57','F'),(3,1,9,'',3,4,0,NULL,NULL,NULL,NULL,NULL,'2018-01-18 17:52:57','F');
/*!40000 ALTER TABLE `score` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skintest`
--

DROP TABLE IF EXISTS `skintest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skintest` (
  `skintest_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `state` int(11) DEFAULT '0',
  `patient_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `provider_config_id` int(11) NOT NULL,
  `test_notes` text NOT NULL,
  `test_log` text NOT NULL,
  `protocol_id` int(11) NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `complete_time` datetime DEFAULT NULL,
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`skintest_id`),
  KEY `patient_id` (`patient_id`),
  KEY `provider_id` (`provider_id`),
  KEY `user_id` (`user_id`),
  KEY `provider_config_id` (`provider_config_id`),
  KEY `skintest_temp_ibfk_5` (`protocol_id`),
  KEY `state` (`state`),
  CONSTRAINT `skintest_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  CONSTRAINT `skintest_ibfk_2` FOREIGN KEY (`provider_id`) REFERENCES `provider` (`provider_id`),
  CONSTRAINT `skintest_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `skintest_ibfk_4` FOREIGN KEY (`provider_config_id`) REFERENCES `provider_config` (`provider_config_id`),
  CONSTRAINT `skintest_ibfk_5` FOREIGN KEY (`protocol_id`) REFERENCES `protocol` (`protocol_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skintest`
--

LOCK TABLES `skintest` WRITE;
/*!40000 ALTER TABLE `skintest` DISABLE KEYS */;
INSERT INTO `skintest` VALUES (1,'Simple',0,2,1,2,1,'','',1,'2018-01-18 09:52:42',NULL,NULL,'F','0000-00-00 00:00:00',NULL,'2018-01-18 17:52:42',NULL);
/*!40000 ALTER TABLE `skintest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template`
--

DROP TABLE IF EXISTS `template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template` (
  `template_id` int(11) NOT NULL AUTO_INCREMENT,
  `template` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queriesCSV` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `template_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template`
--

LOCK TABLES `template` WRITE;
/*!40000 ALTER TABLE `template` DISABLE KEYS */;
INSERT INTO `template` VALUES (1,'{\n        \"file_info\": {\n            \"filename\":\n                \"{Data->Patient->lastname}_{Data->Patient->firstname}_{Data->Patient->mi}_{Data->Patient->chart}_{CurrentDateTime}\",\n            \"paper_size\": \"Letter\",\n            \"units\": \"mm\",\n            \"orientation\": \"P\"\n        },\n        \"metadata\": [\n            \"SetAuthor(\'Xtract Solutions\')\",\n            \"SetTitle(\'Dialy Injection Report\')\",\n            \"SetSubject(\'A report of {Data->Patient->firstname} {Data->Patient->lastname}\'s injections on {Data->report_date}\'\"\n        ],\n        \"header\": [\n            \"Image(\'storage/app/reports/logo.png\',160,5,50)\",\n            \"SetXY(15,{GetY})\",\n            \"SetFont(\'Arial\',\'\',20)\",\n            \"Write(10,\'Daily Injection Report\')\",\n            \"Ln()\",\n            \"FontAwesome(\'fas\',\'f007\',12)\",\n            \"SetXY(15,{GetY})\",\n            \"Template(\'patient_line\')\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(5,\'Visit: {Data->Report_date}\')\",\n            \"SetDrawColor(0,100,250)\",\n            \"SetLineWidth(.3)\",\n            \"Line(25,{GetY+10},190,{GetY+10})\",\n            \"SetXY({GetX},25)\"\n        ],\n        \"footer\": [\n            \"SetXY(15,-15)\",\n            \"Template(\'patient_line\')\",\n            \"SetXY(15,-10)\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(5,\'Report generated: {Data->Generated_date}\')\",\n            \"SetXY(-35,{GetY})\",\n            \"Write(5,\'Page {PageNo} of {TotalPages}\')\"\n        ],\n        \"body\": [\n            \"Template(\'providers\')\",\n            \"Template(\'injections_given\')\",\n            \"Template(\'reactions\')\",\n            \"Template(\'questionnaire_answers\')\"\n        ],\n        \"providers\": [\n            \"SetXY(15,{GetY+15})\",\n            \"FontAwesome(\'fas\',\'f0f0\',12)\",\n            \"SetXY(25,{GetY})\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(6,\'Injections administered by: {InjectingProviders}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Attending provider: {AttendingProviders}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Prescribing provider: {PrescribingProviders}\')\",\n            \"Ln()\",\n            \"SetDrawColor(0,0,0)\",\n            \"SetLineWidth(.1)\",\n            \"Line(25,{GetY+10},190,{GetY+10})\"\n        ],\n        \"reactions\": [\n            \"SetXY(15,{GetY+15})\",\n            \"FontAwesome(\'fal\',\'f071\',12)\",\n            \"SetXY(25,{GetY})\",\n            \"SetFont(\'Arial\',\'B\',12)\",\n            \"Write(6,\'Reactions\')\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Ln()\",\n            \"SetXY(30,{GetY+2})\",\n            \"SetFont(\'Arial\',\'UB\',10)\",\n            \"Write(5,\'Systemic\')\",\n            \"Systemics(\'systemic\')\",\n            \"Ln()\",\n            \"SetXY(30,{GetY+2})\",\n            \"SetFont(\'Arial\',\'UB\',10)\",\n            \"Write(5,\'Local\')\",\n            \"Locals(\'local\')\",\n            \"Ln(2)\",\n            \"SetDrawColor(0,0,0)\",\n            \"SetLineWidth(.1)\",\n            \"Line(25,{GetY+10},190,{GetY+10})\"\n        ],\n        \"systemic\": [\n            \"SetXY(60,{GetY+1})\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"MultiCell(50,4,\'{Data->compound->name}\')\",\n            \"Cell(50,4,\'{Data->systemic_reaction}\')\"\n        ],\n        \"local\": [\n            \"SetXY(60,{GetY+1})\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"MultiCell(50,4,\'{Data->compound->name}\')\",\n            \"Cell(50,4,\'{Data->local_reaction}\')\"\n        ],\n        \"questionnaire_answers\": [\n            \"SetXY(15,{GetY+15})\",\n            \"FontAwesome(\'fal\',\'f46d\',12)\",\n            \"SetXY(25,{GetY})\",\n            \"SetFont(\'Arial\',\'B\',12)\",\n            \"Write(6, \'Questionnaire responses\')\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Ln()\",\n            \"Template(\'answer\',{Data->Answers})\",\n            \"SetDrawColor(0,0,0)\",\n            \"SetLineWidth(.1)\",\n            \"Line(25,{GetY+10},190,{GetY+10})\"\n        ],\n        \"answer\": [\n            \"SetXY(20,{GetY+5})\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"MultiCell(85,4,{Data->question})\",\n            \"SetFont(\'Arial\',\'B\',10)\",\n            \"MultiCell(85,4,{Data->response})\",\n            \"Ln(2)\"\n        ],\n        \"injections_given\": [\n            \"SetXY(15,{GetY+15})\",\n            \"FontAwesome(\'fal\',\'f48e\',12)\",\n            \"SetXY(25,{GetY})\",\n            \"SetFont(\'Arial\',\'B\',12)\",\n            \"Write(6,\'Injections given\')\",\n            \"Template(\'injection\',{Data->Injections})\",\n            \"SetDrawColor(0,0,0)\",\n            \"SetLineWidth(.1)\",\n            \"Line(25,{GetY+10},190,{GetY+10}\"\n        ],\n        \"injection\": [\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Ln()\",\n            \"SetXY(20,{GetY+5})\",\n            \"MultiCell(45,3,\'{Data->compound->prescription->prescription_number} - {Data->compound->name}\')\",\n            \"Cell(18,3,\'{Data->dose} mL\')\",\n            \"Cell(26,3,\'{Data->site}\')\",\n            \"Cell(36,3,\'{Data->datetime_administered}\')\",\n            \"MultiCell(50,3,\'{Data->notes_patient}\')\",\n            \"Ln(2)\"\n        ],\n        \"patient_line\": [\n            \"SetFont(\'Arial\',\'B\',10)\",\n            \"Write(5, \'{Data->Patient->firstname} {Data->Patient->mi}. {Data->Patient->lastname}\')\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"SetTextColor(0,100,250)\",\n            \"Write(5,\' | \')\",\n            \"SetTextColor(0,0,0)\",\n            \"Write(5,\'DOB: {Data->Patient->dob}\')\",\n            \"SetTextColor(0,100,250)\",\n            \"Write(5,\' | \')\",\n            \"SetTextColor(0,0,0)\",\n            \"Write(5,\'MRN: {Data->Patient->chart}\')\",\n            \"Ln()\"\n        ]\n    }','pdf','Daily injection report','patient,dailyInjection,tracking,questionnaire'),(2,'{\n        \"file_info\": {\n            \"filename\":\n                \"{Data->Patient->lastname}_{Data->Patient->firstname}_{Data->Patient->mi}_{Data->Patient->chart}_{CurrentDateTime}\",\n            \"paper_size\": \"Letter\",\n            \"units\": \"mm\",\n            \"orientation\": \"P\"\n        },\n        \"metadata\": [\n            \"SetAuthor(\'Xtract Solutions\')\",\n            \"SetTitle(\'Mix receipt\')\",\n            \"SetSubject(\'A mix recepit for {Data->Patient->firstname} {Data->Patient->lastname}\'s prescription # {$Data->Prescription->prescription_num\"\')\n        ],\n        \"header\": [\n            \"Image(\'storage/app/reports/logo.png\',160,5,50)\",\n            \"SetXY(15,{GetY})\",\n            \"SetFont(\'Arial\',\'\',20)\",\n            \"Write(10,\'Allergy Prescription Mix Receipt\')\",\n            \"Ln()\",\n            \"FontAwesome(\'fas\',\'f007\',12)\",\n            \"SetXY(15,{GetY})\",\n            \"Template(\'patient_line\')\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(5,\'Visit: {Data->Report_date}\')\",\n            \"SetDrawColor(0,100,250)\",\n            \"SetLineWidth(.3)\",\n            \"Line(25,{GetY+10},190,{GetY+10})\",\n            \"SetXY({GetX},25)\"\n        ],\n        \"footer\": [\n            \"SetXY(15,-15)\",\n            \"Template(\'patient_line\')\",\n            \"SetXY(15,-10)\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(5,\'Report generated: {Data->Generated_date}\')\",\n            \"SetXY(-35,{GetY})\",\n            \"Write(5,\'Page {PageNo} of {TotalPages}\')\"\n        ],\n        \"body\": [\n            \"SetXY(15,{GetY+15})\",\n            \"SetFont(\'Arial\',\'\',16)\",\n            \"Write(8,\'Prescription Overview\')\",\n            \"Template(\'provider_details\')\",\n            \"Template(\'mix_details\')\",\n            \"Template(\'prescription_details\')\"\n        ],\n        \"provider_details\": [\n            \"SetXY(15,{GetY+10})\",\n            \"FontAwesome(\'fal\',\'f0f1\',12)\",\n            \"SetXY(25,{GetY})\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(6, \'Prescribing provider: {Data->TreatmentSet->prescription->provider->first} {Data->TreatmentSet->prescription->provider->mi} {Data->TreatmentSet->prescription->provider->last}, {Data->TreatmentSet->prescription->provider->suffix}\')\",\n            \"SetXY(25,{GetY})\",\n            \"SetDrawColor(0,0,0)\",\n            \"SetLineWidth(.1)\",\n            \"Line(25,{GetY+10},190,{GetY+10})\"\n        ],\n        \"mix_details\": [\n            \"SetXY(15,{GetY+15})\",\n            \"FontAwesome(\'fal\',\'f5a7\',12)\",\n            \"SetXY(25,{GetY})\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(6,\'Mixed by: {MixedBy}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Mixed on: {MixedOn}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Expiration: {LabelOutdate}\')\",\n            \"SetXY(25,{GetY})\",\n            \"SetDrawColor(0,0,0)\",\n            \"SetLineWidth(.1)\",\n            \"Line(25,{GetY+10},190,{GetY+10})\"\n        ],\n        \"prescription_details\": [\n            \"SetXY(15,{GetY+15})\",\n            \"FontAwesome(\'fal\',\'f486\',12)\",\n            \"SetXY(25,{GetY})\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(6,\'Prescription #: {Data->TreatmentSet->prescription->prescription_number}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Bottle name: {SetName}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Treatment plan: {Data->TreatmentSet->prescription->treatment_plan->name}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Vial size: {SetSize}\')\",\n            \"Template(\'dilutions_circles\', {Data->TreatmentSet->vials})\",\n            \"Template(\'extracts\')\",\n            \"Template(\'diluents\')\",\n            \"Template(\'mix_totals\')\"\n        ],\n        \"dilutions_circles\": [\n            \"SetFont(\'Arial\',\'\\,7)\",\n            \"SetFillColor({Data->color})\",\n            \"Text({GetX+45},{GetY-12},\'1:{Data->dilution}\')\",\n            \"Circle({GetX+50},{GetY-6},5,\'FD\')\",\n            \"SetFillColor(0,0,0)\",\n            \"SetX({GetX+12})\"\n        ],\n        \"extracts\": [\n            \"Ln()\",\n            \"Ln()\",\n            \"SetX({GetX+5})\",\n            \"SetFont(\'Arial\',\'B\',10)\",\n            \"DashedRect({GetX},{GetY},{GetX+185},{GetY+6},.25,100)\",\n            \"SetX({GetX+2})\",\n            \"MultiCell(55,6,\'Extract\')\",\n            \"MultiCell(20,6,\'Dose\')\",\n            \"MultiCell(30,6,\'Dilution\')\",\n            \"MultiCell(20,6,\'Units\')\",\n            \"MultiCell(30,6,\'Lot #\')\",\n            \"MultiCell(30,6,\'Outdate\')\",\n            \"Ln()\",\n            \"Template(\'extract\',{Data->TreatmentSet->vials[0]->vials})\"\n        ],\n        \"extract\": [\n            \"SetX(15)\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"MultiCell(55,4,\'{Data->inventory->extract->name}\', 1)\",\n            \"MultiCell(20,4,\'{Data->dosing->dose}\', 1)\",\n            \"MultiCell(30,4,\'{Data->inventory->extract->dilution}\', 1)\",\n            \"MultiCell(20,4,\'{Data->inventory->extract->unit_type->name}\', 1)\",\n            \"MultiCell(30,4,\'{Data->inventory->lotnumber}\', 1)\",\n            \"MultiCell(30,4,\'{Data->out_date}\', 1)\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Ln()\"\n        ],\n        \"diluents\": [],\n        \"mix_totals\": [],\n        \"patient_line\": [\n            \"SetFont(\'Arial\',\'B\',10)\",\n            \"Write(5, \'{Data->Patient->firstname} {Data->Patient->mi}. {Data->Patient->lastname}\')\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"SetTextColor(0,100,250)\",\n            \"Write(5,\' | \')\",\n            \"SetTextColor(0,0,0)\",\n            \"Write(5,\'DOB: {Data->Patient->dob}\')\",\n            \"SetTextColor(0,100,250)\",\n            \"Write(5,\' | \')\",\n            \"SetTextColor(0,0,0)\",\n            \"Write(5,\'MRN: {Data->Patient->chart}\')\",\n            \"Ln()\"\n        ]\n    }','pdf','Mix receipt','patient,treatmentset'),(3,'\n    {\n        \"file_info\": {\n            \"filename\":\n                \"{Data->Patient->lastname}_{Data->Patient->firstname}_{Data->Patient->mi}_{Data->Patient->chart}_{CurrentDateTime}\",\n            \"paper_size\": \"Letter\",\n            \"units\": \"mm\",\n            \"orientation\": \"P\"\n        },\n        \"metadata\": [\n            \"SetAuthor(\'Xtract Solutions\')\",\n            \"SetTitle(\'Order mix receipt\')\",\n            \"SetSubject(\'An order mix receipt for purchase_order # {$Data->Order->order_id}\'\"\n        ],\n        \"header\": [\n            \"Image(\'storage/app/reports/logo.png\',160,5,50)\",\n            \"SetXY(15,{GetY})\",\n            \"SetFont(\'Arial\',\'\',20)\",\n            \"Write(10,\'Purchase Order Mix Receipt\')\",\n            \"Ln()\",\n            \"FontAwesome(\'fas\',\'f007\',12)\",\n            \"SetXY(15,{GetY})\",\n            \"Template(\'patient_line\')\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(5,\'Visit: {Data->Report_date}\')\",\n            \"SetDrawColor(0,100,250)\",\n            \"SetLineWidth(.3)\",\n            \"Line(25,{GetY+10},190,{GetY+10})\",\n            \"SetXY({GetX},25)\"\n        ],\n        \"footer\": [\n            \"SetXY(15,-15)\",\n            \"Template(\'patient_line\')\",\n            \"SetXY(15,-10)\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(5,\'Report generated: {Data->Generated_date}\')\",\n            \"SetXY(-35,{GetY})\",\n            \"Write(5,\'Page {PageNo} of {TotalPages}\')\"\n        ],\n        \"body\": [\"Template(\'prescription\',{Data->Order->treatment_sets})\"],\n        \"prescription\": [\n            \"SetXY(15,{GetY+15})\",\n            \"SetFont(\'Arial\',\'\',16)\",\n            \"Write(8,\'Prescription Overview\')\",\n            \"Template(\'provider_details\',{Data->prescription->provider})\",\n            \"Template(\'mix_details\',{Data->vials[0]->vials[0]})\",\n            \"Template(\'prescription_details\',{Data})\"\n        ],\n        \"provider_details\": [\n            \"SetXY(15,{GetY+10})\",\n            \"FontAwesome(\'fal\',\'f0f1\',12)\",\n            \"SetXY(25,{GetY})\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(6, \'Prescribing provider: {Data->first} {Data->mi} {Data->last}, {Data->suffix}\')\",\n            \"SetXY(25,{GetY})\",\n            \"SetDrawColor(0,0,0)\",\n            \"SetLineWidth(.1)\",\n            \"Line(25,{GetY+10},190,{GetY+10})\"\n        ],\n        \"mix_details\": [\n            \"SetXY(15,{GetY+15})\",\n            \"FontAwesome(\'fal\',\'f5a7\',12)\",\n            \"SetXY(25,{GetY})\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(6,\'Mixed by: {Data->user->displayname}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Mixed on: {Data->mix_date}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Expiration: {Data->label_out_date}\')\",\n            \"SetXY(25,{GetY})\",\n            \"SetDrawColor(0,0,0)\",\n            \"SetLineWidth(.1)\",\n            \"Line(25,{GetY+10},190,{GetY+10})\"\n        ],\n        \"prescription_details\": [\n            \"SetXY(15,{GetY+15})\",\n            \"FontAwesome(\'fal\',\'f486\',12)\",\n            \"SetXY(25,{GetY})\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(6,\'Prescription #: {Data->prescription->prescription_number}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Bottle name: {Data->vials[0]->name}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6\\Treatment plan: {Data->prescription->treatment_plan->name}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Vial size: {Data->vials[0]->size}\')\",\n            \"Template(\'dilutions_circles\', {Data->vials})\",\n            \"Template(\'extracts\', {Data->vials[0]})\"\n        ],\n        \"dilutions_circles\": [\n            \"SetFont(\'Arial\',\'\',7)\",\n            \"SetFillColor({Data->color})\",\n            \"Text({GetX+45},{GetY-12},\'1:{Data->dilution}\')\",\n            \"Circle({GetX+50},{GetY-6},5,\'FD\')\",\n            \"SetFillColor(0,0,0)\",\n            \"SetX({GetX+12})\"\n        ],\n        \"extracts\": [\n            \"Ln()\",\n            \"Ln()\",\n            \"SetX({GetX+5})\",\n            \"SetFont(\'Arial\',\'B\',10)\",\n            \"DashedRect({GetX},{GetY},{GetX+185},{GetY+6},.25,100)\",\n            \"SetX({GetX+2})\",\n            \"MultiCell(55,6,\'Extract\')\",\n            \"MultiCell(20,6,\'Dose\')\",\n            \"MultiCell(30,6,\'Dilution\')\",\n            \"MultiCell(20,6,\'Units\')\",\n            \"MultiCell(30,6,\'Lot #\')\",\n            \"MultiCell(30,6,\'Outdate\')\",\n            \"Ln()\",\n            \"Template(\'extract\',{Data->vials})\"\n        ],\n        \"extract\": [\n            \"SetX(15)\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"MultiCell(55,4,\'{Data->inventory->extract->name}\', 1)\",\n            \"MultiCell(20,4,\'{Data->dosing->dose}\', 1)\",\n            \"MultiCell(30,4,\'{Data->inventory->extract->dilution}\', 1)\",\n            \"MultiCell(20,4,\'{Data->inventory->extract->unit_type->name}\', 1)\",\n            \"MultiCell(30,4,\'{Data->inventory->lotnumber}\', 1)\",\n            \"MultiCell(30,4,\'{Data->out_date}\', 1)\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Ln()\"\n        ],\n        \"patient_line\": [\n            \"SetFont(\'Arial\',\'B\',10)\",\n            \"Write(5, \'{Data->Patient->firstname} {Data->Patient->mi}. {Data->Patient->lastname}\')\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"SetTextColor(0,100,250)\",\n            \"Write(5,\' | \')\",\n            \"SetTextColor(0,0,0)\",\n            \"Write(5,\'DOB: {Data->Patient->dob}\')\",\n            \"SetTextColor(0,100,250)\",\n            \"Write(5,\' | \')\",\n            \"SetTextColor(0,0,0)\",\n            \"Write(5,\'MRN: {Data->Patient->chart}\')\",\n            \"Ln()\"\n        ]\n    }','pdf','Order mix receipt','patient,purchaseorder'),(4,'{\n        \"file_info\": {\n            \"filename\":\n                \"{Data->Patient->lastname}_{Data->Patient->firstname}_{Data->Patient->mi}_{Data->Patient->chart}_{CurrentDateTime}\",\n            \"paper_size\": \"Letter\",\n            \"units\": \"mm\",\n            \"orientation\": \"P\"\n        },\n        \"metadata\": [\n            \"SetAuthor(\'Xtract Solutions\')\",\n            \"SetTitle(\'Order receipt\')\",\n            \"SetSubject(\'An order receipt for purchase_order # {$Data->Order->order_id}\"\')\n        ],\n        \"header\": [\n            \"Image(\'storage/app/reports/logo.png\',160,5,50)\",\n            \"SetXY(15,{GetY})\",\n            \"SetFont(\'Arial\',\'\',20)\",\n            \"Write(10,\'Purchase Order Receipt\')\",\n            \"Ln()\",\n            \"FontAwesome(\'fas\',\'f007\',12)\",\n            \"SetXY(15,{GetY})\",\n            \"Template(\'patient_line\')\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(5,\'Visit: {Data->Report_date}\')\",\n            \"SetDrawColor(0,100,250)\",\n            \"SetLineWidth(.3)\",\n            \"Line(25,{GetY+10},190,{GetY+10})\",\n            \"SetXY({GetX},25)\"\n        ],\n        \"footer\": [\n            \"SetXY(15,-15)\",\n            \"Template(\'patient_line\')\",\n            \"SetXY(15,-10)\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(5,\'Report generated: {Data->Generated_date}\')\",\n            \"SetXY(-35,{GetY})\",\n            \"Write(5,\'Page {PageNo} of {TotalPages}\')\"\n        ],\n        \"body\": [\"Template(\'prescription\',{Data->Order->treatment_sets})\"],\n        \"prescription\": [\n            \"SetXY(15,{GetY+15})\",\n            \"SetFont(\'Arial\',\'\',16)\",\n            \"Write(8,\'Prescription Overview\')\",\n            \"Template(\'provider_details\',{Data->prescription->provider})\",\n            \"Template(\'prescription_details\',{Data})\"\n        ],\n        \"provider_details\": [\n            \"SetXY(15,{GetY+10})\",\n            \"FontAwesome(\'fal\',\'f0f1\',12)\",\n            \"SetXY(25,{GetY})\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(6, \'Prescribing provider: {Data->first} {Data->mi} {Data->last}, {Data->suffix}\')\",\n            \"SetXY(25,{GetY})\",\n            \"SetDrawColor(0,0,0)\",\n            \"SetLineWidth(.1)\",\n            \"Line(25,{GetY+10},190,{GetY+10})\"\n        ],\n        \"prescription_details\": [\n            \"SetXY(15,{GetY+15})\",\n            \"FontAwesome(\'fal\',\'f486\',12)\",\n            \"SetXY(25,{GetY})\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Write(6,\'Prescription #: {Data->prescription->prescription_number}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Bottle name: {Data->vials[0]->name}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Treatment plan: {Data->prescription->treatment_plan->name}\')\",\n            \"Ln()\",\n            \"SetXY(25,{GetY})\",\n            \"Write(6,\'Vial size: {Data->vials[0]->size}\')\",\n            \"Template(\'dilutions_circles\', {Data->vials})\",\n            \"Template(\'extracts\', {Data->vials[0]})\"\n        ],\n        \"dilutions_circles\": [\n            \"SetFont(\'Arial\',\'\',7)\",\n            \"SetFillColor({Data->color})\",\n            \"Text({GetX+45},{GetY-12},\'1:{Data->dilution}\')\",\n            \"Circle({GetX+50},{GetY-6},5,\'FD\')\",\n            \"SetFillColor(0,0,0)\",\n            \"SetX({GetX+12})\"\n        ],\n        \"extracts\": [\n            \"Ln()\",\n            \"Ln()\",\n            \"SetX({GetX+5})\",\n            \"SetFont(\'Arial\',\'B\',10)\",\n            \"DashedRect({GetX+25},{GetY},{GetX+150},{GetY+6},.25,70)\",\n            \"SetX({GetX+27})\",\n            \"MultiCell(55,6,\'Extract\')\",\n            \"MultiCell(20,6,\'Dose\')\",\n            \"MultiCell(30,6,\'Dilution\')\",\n            \"MultiCell(20,6,\'Units\')\",\n            \"Ln()\",\n            \"Template(\'extract\',{Data->vials})\"\n        ],\n        \"extract\": [\n            \"SetX(40)\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"MultiCell(55,4,\'{Data->inventory->extract->name}\', 1)\",\n            \"MultiCell(20,4,\'{Data->dosing->dose}\', 1)\",\n            \"MultiCell(30,4,\'{Data->inventory->extract->dilution}\', 1)\",\n            \"MultiCell(20,4,\'{Data->inventory->extract->unit_type->name}\', 1)\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"Ln()\"\n        ],\n        \"patient_line\": [\n            \"SetFont(\'Arial\',\'B\',10)\",\n            \"Write(5, \'{Data->Patient->firstname} {Data->Patient->mi}. {Data->Patient->lastname}\')\",\n            \"SetFont(\'Arial\',\'\',10)\",\n            \"SetTextColor(0,100,250)\",\n            \"Write(5,\' | \')\",\n            \"SetTextColor(0,0,0)\",\n            \"Write(5,\'DOB: {Data->Patient->dob}\')\",\n            \"SetTextColor(0,100,250)\",\n            \"Write(5,\' | \')\",\n            \"SetTextColor(0,0,0)\",\n            \"Write(5,\'MRN: {Data->Patient->chart}\')\",\n            \"Ln()\"\n        ]\n    }','pdf','Order receipt','patient,purchaseorder');
/*!40000 ALTER TABLE `template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_printer`
--

DROP TABLE IF EXISTS `template_printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template_printer` (
  `template_id` int(11) NOT NULL,
  `printer_id` int(11) NOT NULL,
  PRIMARY KEY (`template_id`,`printer_id`),
  KEY `template_printer_printer_id_foreign` (`printer_id`),
  CONSTRAINT `template_printer_printer_id_foreign` FOREIGN KEY (`printer_id`) REFERENCES `printer` (`printer_id`),
  CONSTRAINT `template_printer_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `template` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_printer`
--

LOCK TABLES `template_printer` WRITE;
/*!40000 ALTER TABLE `template_printer` DISABLE KEYS */;
INSERT INTO `template_printer` VALUES (1,1),(2,1),(3,1),(4,1);
/*!40000 ALTER TABLE `template_printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terminal`
--

DROP TABLE IF EXISTS `terminal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `terminal` (
  `terminal_id` int(11) NOT NULL AUTO_INCREMENT,
  `labeltypeprescription` int(11) DEFAULT NULL,
  `labeltypevial` int(11) DEFAULT NULL,
  `labelTypeDoor` int(11) DEFAULT NULL,
  `backups` varchar(150) DEFAULT NULL,
  `workflow` varchar(150) DEFAULT NULL,
  `changereasondefault1` varchar(45) DEFAULT NULL,
  `changereasondefault2` varchar(45) DEFAULT NULL,
  `changereasondefault3` varchar(45) DEFAULT NULL,
  `labelPrinter` varchar(100) DEFAULT NULL,
  `formPrinter` varchar(100) DEFAULT NULL,
  `discardCheck` varchar(100) DEFAULT NULL,
  `outdateCheck` varchar(45) DEFAULT NULL,
  `hardcopydwell` int(11) DEFAULT NULL,
  `startVols` varchar(45) DEFAULT NULL,
  `redThresh` varchar(45) DEFAULT NULL,
  `yellowThresh` varchar(45) DEFAULT NULL,
  `pagenames` varchar(150) DEFAULT '1,2,3,4,5,6',
  `names` text,
  `compName` varchar(100) DEFAULT '',
  `termName` varchar(100) DEFAULT '',
  `currUser` int(11) DEFAULT NULL,
  `emailServer` varchar(150) DEFAULT '',
  `emailUser` varchar(150) DEFAULT '',
  `emailPort` varchar(45) DEFAULT '',
  `emailPwd` varchar(150) DEFAULT '',
  `emailFrom` varchar(150) DEFAULT '',
  `smsSID` varchar(45) DEFAULT '',
  `smsNumber` varchar(45) DEFAULT '',
  `smsToken` varchar(45) DEFAULT '',
  `locAccess` varchar(100) DEFAULT '',
  `labelPrinter2` varchar(100) DEFAULT '',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `location` int(11) DEFAULT NULL,
  PRIMARY KEY (`terminal_id`),
  KEY `location` (`location`),
  CONSTRAINT `fk_clinic_terminal` FOREIGN KEY (`location`) REFERENCES `clinic` (`clinic_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terminal`
--

LOCK TABLES `terminal` WRITE;
/*!40000 ALTER TABLE `terminal` DISABLE KEYS */;
INSERT INTO `terminal` VALUES (1,2,1,NULL,'T,6/12/2015,T,,','T,T,T,F,F,F,F,F,F,T,T,F,F,F,F,F,F,F,T,F,T,T,T,T,F,T,F,F,F,F,F,T,T,F,T,F,F,F,F,T,F,F,F,F,T,F,F,F,F,T,F',NULL,NULL,NULL,'ZDesigner GX420t (Copy 1)','Open in Web Browser',' ,,T,,, , , , , , , ','T,7/6/2015,T,1,2',0,'4.50,9.50,0.00',NULL,NULL,'Trees,Weeds,Grasses,Molds,Misc.,Misc.','printReportEnabled?,printLabelEnabled?,showScaleMsgs?,loggingEnabled?,showCostInfo?,requireScanBottle?,requireScanKey?,showGlycInfo?,useOldSilhouettes?,confirmRxEntry?,form1multiple?,form2multiple?,form3multiple?,form4multiple?,form5multiple?,form6multiple?,form7multiple?,inclDiagnosis?,enqueueReceipt?,showDshbrd?,useDshbrd?,useRxLabels?,configRxLbls?,showTrayLocDialogs?,multiScanEnabled?,autoTo1:1?,endOfMonth?,detailedLogging?,reqChart#?,2xRxFor10mL?,>72 drugs?,>12 provider,show provider note,track diluent,useProvProfiles?,promptQprint?,custmNames?,allow0Doses?,paAddr?,paNote?,quickMix?,allFormsAtQ?,extENTDepth?,estMixDateAtQ?,bypassScans?,clinFullNames?,doPaImport?,ask2xPaLabel?,formExport?,showHotKeys?, showDiltMath?','TEMPLATE','TEMPLATE',0,'','','0','','','','','','7,8,9,10,11,13,14,15,16','',0,NULL),(2,2,1,NULL,'T,6/12/2015,T,,','T,T,T,F,F,F,F,F,F,T,T,F,F,F,F,F,F,F,T,F,T,T,T,T,F,T,F,F,F,F,F,T,T,F,T,F,F,F,F,T,F,F,F,F,T,F,F,F,F,T,F',NULL,NULL,NULL,'ZDesigner GX420t (Copy 1)','Open in Web Browser',' ,,T,,, , , , , , , ','T,7/6/2015,T,1,2',0,'4.50,9.50,0.00',NULL,NULL,'Trees,Weeds,Grasses,Molds,Misc.,Misc.','printReportEnabled?,printLabelEnabled?,showScaleMsgs?,loggingEnabled?,showCostInfo?,requireScanBottle?,requireScanKey?,showGlycInfo?,useOldSilhouettes?,confirmRxEntry?,form1multiple?,form2multiple?,form3multiple?,form4multiple?,form5multiple?,form6multiple?,form7multiple?,inclDiagnosis?,enqueueReceipt?,showDshbrd?,useDshbrd?,useRxLabels?,configRxLbls?,showTrayLocDialogs?,multiScanEnabled?,autoTo1:1?,endOfMonth?,detailedLogging?,reqChart#?,2xRxFor10mL?,>72 drugs?,>12 provider,show provider note,track diluent,useProvProfiles?,promptQprint?,custmNames?,allow0Doses?,paAddr?,paNote?,quickMix?,allFormsAtQ?,extENTDepth?,estMixDateAtQ?,bypassScans?,clinFullNames?,doPaImport?,ask2xPaLabel?,formExport?,showHotKeys?, showDiltMath?','TEMPLATE','TEMPLATE',0,'','','0','','','','','','7,8,9,10,11,13,14,15,16','',2,NULL);
/*!40000 ALTER TABLE `terminal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terminalstate`
--

DROP TABLE IF EXISTS `terminalstate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `terminalstate` (
  `terminalState_id` int(11) NOT NULL AUTO_INCREMENT,
  `compName` varchar(100) DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  `data1` text,
  `data2` text,
  `data3` text,
  PRIMARY KEY (`terminalState_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terminalstate`
--

LOCK TABLES `terminalstate` WRITE;
/*!40000 ALTER TABLE `terminalstate` DISABLE KEYS */;
/*!40000 ALTER TABLE `terminalstate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tracking`
--

DROP TABLE IF EXISTS `tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tracking` (
  `tracking_id` int(11) NOT NULL AUTO_INCREMENT,
  `trackingName` varchar(32) NOT NULL,
  `value` decimal(18,2) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `patient_id` int(11) NOT NULL,
  PRIMARY KEY (`tracking_id`),
  KEY `fk_tracking_patient_id` (`patient_id`),
  CONSTRAINT `fk_tracking_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tracking`
--

LOCK TABLES `tracking` WRITE;
/*!40000 ALTER TABLE `tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trackingconfig`
--

DROP TABLE IF EXISTS `trackingconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trackingconfig` (
  `trackingConfig_id` int(11) NOT NULL AUTO_INCREMENT,
  `trackingName` varchar(32) NOT NULL,
  `min` decimal(5,2) DEFAULT NULL,
  `max` decimal(5,2) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  PRIMARY KEY (`trackingConfig_id`),
  UNIQUE KEY `trackingConfig_unique` (`trackingName`,`patient_id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `trackingconfig_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trackingconfig`
--

LOCK TABLES `trackingconfig` WRITE;
/*!40000 ALTER TABLE `trackingconfig` DISABLE KEYS */;
/*!40000 ALTER TABLE `trackingconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatment_plan`
--

DROP TABLE IF EXISTS `treatment_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `treatment_plan` (
  `treatment_plan_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `deleted` varchar(5) NOT NULL DEFAULT 'F',
  `maint_steps_back` varchar(45) DEFAULT NULL,
  `doserulenames_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`treatment_plan_id`),
  KEY `doserulenames_id` (`doserulenames_id`),
  CONSTRAINT `treatment_plan_ibfk_1` FOREIGN KEY (`doserulenames_id`) REFERENCES `doserulenames` (`doseRuleNames_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatment_plan`
--

LOCK TABLES `treatment_plan` WRITE;
/*!40000 ALTER TABLE `treatment_plan` DISABLE KEYS */;
INSERT INTO `treatment_plan` VALUES (1,'Xtract Default Treatment Plan','Universal','F','-2',NULL,'0000-00-00 00:00:00',NULL,'2018-01-11 21:25:34',1);
/*!40000 ALTER TABLE `treatment_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatment_set`
--

DROP TABLE IF EXISTS `treatment_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `treatment_set` (
  `treatment_set_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction` varchar(32) DEFAULT NULL,
  `purchase_order_id` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `prescription_id` int(11) NOT NULL,
  `clinic_id` int(11) NOT NULL,
  `status_id` int(11) DEFAULT NULL,
  `source` varchar(45) DEFAULT 'API',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`treatment_set_id`),
  KEY `patient_id` (`patient_id`),
  KEY `provider_id` (`provider_id`),
  KEY `prescription_id` (`prescription_id`),
  KEY `clinic_id` (`clinic_id`),
  KEY `purchase_order_id` (`purchase_order_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `treatment_set_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  CONSTRAINT `treatment_set_ibfk_2` FOREIGN KEY (`provider_id`) REFERENCES `provider` (`provider_id`),
  CONSTRAINT `treatment_set_ibfk_3` FOREIGN KEY (`prescription_id`) REFERENCES `prescription` (`prescription_id`),
  CONSTRAINT `treatment_set_ibfk_5` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_order` (`purchase_order_id`),
  CONSTRAINT `treatment_set_ibfk_6` FOREIGN KEY (`status_id`) REFERENCES `treatment_set_status` (`treatment_set_status_id`),
  CONSTRAINT `treatment_set_ibfk_7` FOREIGN KEY (`status_id`) REFERENCES `treatment_set_status` (`treatment_set_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatment_set`
--

LOCK TABLES `treatment_set` WRITE;
/*!40000 ALTER TABLE `treatment_set` DISABLE KEYS */;
INSERT INTO `treatment_set` VALUES (1,'800000',2,2,1,3,2,NULL,'XST','2018-09-04 17:42:36',NULL,'2018-01-13 21:50:45',NULL),(2,'800001',3,2,1,3,2,NULL,'XST','2018-09-04 17:42:36',NULL,'2018-06-03 16:30:55',NULL),(4,'800002',5,2,1,4,2,NULL,'API','2018-10-08 20:24:50',NULL,'2018-10-08 20:24:50',NULL);
/*!40000 ALTER TABLE `treatment_set` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER auto_create_purchase_order BEFORE INSERT ON `treatment_set`
    FOR EACH ROW BEGIN
      IF (NEW.purchase_order_id IS NULL) THEN
        insert into purchase_order (account_id) select min(account_id) from account;
        set NEW.purchase_order_id = last_insert_id();
      END IF;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `treatment_set_status`
--

DROP TABLE IF EXISTS `treatment_set_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `treatment_set_status` (
  `treatment_set_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`treatment_set_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatment_set_status`
--

LOCK TABLES `treatment_set_status` WRITE;
/*!40000 ALTER TABLE `treatment_set_status` DISABLE KEYS */;
INSERT INTO `treatment_set_status` VALUES (1,'Ready for review',0),(2,'Reviewed',1),(3,'Ready to mix',2),(4,'Mixed',3);
/*!40000 ALTER TABLE `treatment_set_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatplandetails`
--

DROP TABLE IF EXISTS `treatplandetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `treatplandetails` (
  `treatPlanDetails_id` int(11) NOT NULL AUTO_INCREMENT,
  `dose` decimal(6,3) DEFAULT NULL,
  `minInterval` float DEFAULT NULL,
  `maxInterval` float DEFAULT NULL,
  `minIntervalUnit` int(11) DEFAULT NULL,
  `maxIntervalUnit` int(11) DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  `5or10` varchar(45) DEFAULT NULL,
  `dilution` int(11) DEFAULT NULL,
  `treatment_plan_id` int(11) NOT NULL,
  `step` int(11) NOT NULL,
  PRIMARY KEY (`treatPlanDetails_id`),
  KEY `fk_treatment_plan_id_idx` (`treatment_plan_id`),
  CONSTRAINT `fk_treatment_plan_id1` FOREIGN KEY (`treatment_plan_id`) REFERENCES `treatment_plan` (`treatment_plan_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatplandetails`
--

LOCK TABLES `treatplandetails` WRITE;
/*!40000 ALTER TABLE `treatplandetails` DISABLE KEYS */;
INSERT INTO `treatplandetails` VALUES (77,0.050,2,10,0,0,'16711680','10',200,1,0),(78,0.100,2,10,0,0,'16711680','10',200,1,1),(79,0.200,2,10,0,0,'16711680','10',200,1,2),(80,0.350,2,10,0,0,'16711680','10',200,1,3),(81,0.500,2,10,0,0,'16711680','10',200,1,4),(82,0.050,2,10,0,0,'16776960','10',100,1,5),(83,0.100,2,10,0,0,'16776960','10',100,1,6),(84,0.200,2,10,0,0,'16776960','10',100,1,7),(85,0.350,2,10,0,0,'16776960','10',100,1,8),(86,0.500,2,10,0,0,'16776960','10',100,1,9),(87,0.050,2,10,0,0,'255','10',10,1,10),(88,0.070,2,10,0,0,'255','10',10,1,11),(89,0.100,2,10,0,0,'255','10',10,1,12),(90,0.150,2,10,0,0,'255','10',10,1,13),(91,0.250,2,10,0,0,'255','10',10,1,14),(92,0.350,2,10,0,0,'255','10',10,1,15),(93,0.500,2,10,0,0,'255','10',10,1,16),(94,0.050,2,10,0,0,'65280','10',2,1,17),(95,0.070,2,10,0,0,'65280','10',2,1,18),(96,0.100,2,10,0,0,'65280','10',2,1,19),(97,0.150,2,10,0,0,'65280','10',2,1,20),(98,0.250,2,10,0,0,'65280','10',2,1,21),(99,0.350,2,10,0,0,'65280','10',2,1,22),(100,0.500,2,10,0,0,'65280','10',2,1,23),(101,0.050,2,10,0,0,'13684944','10',1,1,24),(102,0.070,2,10,0,0,'13684944','10',1,1,25),(103,0.100,2,10,0,0,'13684944','10',1,1,26),(104,0.150,2,10,0,0,'13684944','10',1,1,27),(105,0.200,2,10,0,0,'13684944','10',1,1,28),(106,0.250,2,10,0,0,'13684944','10',1,1,29),(107,0.300,2,10,0,0,'13684944','10',1,1,30);
/*!40000 ALTER TABLE `treatplandetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `units` (
  `units_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  PRIMARY KEY (`units_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (0,'BAU/mL'),(1,'AU/mL'),(2,'W/V'),(3,'PNU/mL'),(4,'IU/mL'),(5,'--');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `displayname` varchar(45) DEFAULT NULL,
  `title` varchar(45) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `lockState` int(11) DEFAULT '0',
  `privilege` varchar(45) DEFAULT NULL,
  `faceimage` varchar(45) DEFAULT NULL,
  `deleted` varchar(45) NOT NULL DEFAULT 'F',
  `general` varchar(150) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Admin',NULL,'Admin',NULL,NULL,0,NULL,NULL,'T','',NULL,NULL,'2018-06-25 21:27:15',NULL,'2018-01-11 21:25:26',NULL,1),(2,'Xtract','Admin','Xtract Admin',NULL,'$2a$10$Okp.dWAMf9fWjTGlW77MxOYDbbK81wA8YPSHjTTiohAFSiCAiJVF2',0,'Admin',NULL,'F','','xps@xtractsolutions.com',NULL,'2018-06-25 21:27:15',NULL,'2018-01-11 21:25:26',NULL,1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_config`
--

DROP TABLE IF EXISTS `user_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_config` (
  `user_config_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`user_config_id`),
  UNIQUE KEY `user_config_unique` (`user_id`,`name`),
  KEY `fk_user_config_user_id_idx` (`user_id`),
  CONSTRAINT `fk_user_config_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=257 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_config`
--

LOCK TABLES `user_config` WRITE;
/*!40000 ALTER TABLE `user_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group`
--

DROP TABLE IF EXISTS `user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_group` (
  `user_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`user_group_id`),
  UNIQUE KEY `user_group_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group`
--

LOCK TABLES `user_group` WRITE;
/*!40000 ALTER TABLE `user_group` DISABLE KEYS */;
INSERT INTO `user_group` VALUES (3,'Admin'),(8,'Injection Limited'),(6,'Injection Super'),(7,'Injection User'),(11,'Mix Limited'),(10,'Mix Tech'),(9,'Pharmacy User'),(4,'Provider'),(5,'Provider limited'),(1,'Xtract Admin'),(2,'Xtract Support');
/*!40000 ALTER TABLE `user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_privilege`
--

DROP TABLE IF EXISTS `user_group_privilege`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_group_privilege` (
  `user_group_id` int(11) NOT NULL,
  `privilege_id` int(11) NOT NULL,
  PRIMARY KEY (`user_group_id`,`privilege_id`),
  KEY `user_group_privilege_privilege_id_foreign` (`privilege_id`),
  CONSTRAINT `user_group_privilege_privilege_id_foreign` FOREIGN KEY (`privilege_id`) REFERENCES `privilege` (`privilege_id`),
  CONSTRAINT `user_group_privilege_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_group` (`user_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_privilege`
--

LOCK TABLES `user_group_privilege` WRITE;
/*!40000 ALTER TABLE `user_group_privilege` DISABLE KEYS */;
INSERT INTO `user_group_privilege` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(1,2),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),(1,3),(2,3),(3,3),(4,3),(5,3),(6,3),(7,3),(8,3),(1,4),(2,4),(3,4),(4,4),(5,4),(6,4),(1,5),(3,5),(4,5),(5,5),(6,5),(7,5),(8,5),(9,5),(10,5),(11,5),(1,6),(2,6),(3,6),(4,6),(5,6),(6,6),(7,6),(9,6),(1,7),(2,7),(3,7),(4,7),(5,7),(6,7),(7,7),(9,7),(1,8),(2,8),(3,8),(4,8),(5,8),(6,8),(7,8),(9,8),(10,8),(1,9),(2,9),(3,9),(4,9),(5,9),(6,9),(9,9),(10,9),(11,9),(1,10),(2,10),(3,10),(4,10),(5,10),(6,10),(9,10),(1,11),(2,11),(3,11),(4,11),(5,11),(6,11),(7,11),(8,11),(9,11),(1,12),(3,12),(4,12),(5,12),(6,12),(7,12),(8,12),(1,13),(2,13),(3,13),(4,13),(5,13),(6,13),(7,13),(8,13),(1,14),(2,14),(3,14),(4,14),(5,14),(6,14),(7,14),(8,14),(1,15),(3,15),(4,15),(5,15),(6,15),(7,15),(1,16),(2,16),(3,16),(4,16),(5,16),(6,16),(7,16),(1,17),(2,17),(3,17),(4,17),(5,17),(6,17),(7,17),(1,18),(2,18),(3,18),(4,18),(5,18),(6,18),(7,18),(1,19),(2,19),(3,19),(4,19),(5,19),(6,19),(7,19),(1,20),(2,20),(3,20),(4,20),(5,20),(6,20),(7,20),(8,20),(9,20),(1,21),(2,21),(3,21),(4,21),(6,21),(1,22),(2,22),(3,22),(4,22),(6,22),(1,23),(2,23),(3,23),(4,23),(6,23),(1,24),(3,24),(1,25),(2,25),(3,25),(1,26),(2,26),(3,26),(1,27),(2,27),(3,27),(4,27),(5,27),(6,27),(7,27),(8,27),(9,27),(10,27),(11,27),(1,28),(3,28),(4,28),(5,28),(6,28),(7,28),(8,28),(9,28),(1,29),(2,29),(3,29),(4,29),(5,29),(6,29),(7,29),(8,29),(9,29),(1,30),(2,30),(3,30),(4,30),(5,30),(6,30),(7,30),(8,30),(9,30),(1,31),(2,31),(3,31),(4,31),(6,31),(9,31),(1,32),(2,32),(3,32),(4,32),(6,32),(9,32),(1,33),(2,33),(3,33),(4,33),(6,33),(9,33),(1,34),(2,34),(3,34),(4,34),(9,34),(10,34),(1,35),(2,35),(3,35),(4,35),(9,35),(10,35),(1,36),(2,36),(3,36),(4,36),(9,36),(10,36),(1,37),(2,37),(3,37),(4,37),(9,37),(1,38),(2,38),(3,38),(4,38),(9,38),(1,39),(2,39),(3,39),(4,39),(9,39),(1,40),(2,40),(3,40),(4,40),(9,40),(1,41),(3,41),(1,42),(3,42),(1,43),(3,43),(1,44),(3,44),(1,45),(3,45),(1,46),(3,46),(1,47),(3,47),(1,48),(2,48),(1,49);
/*!40000 ALTER TABLE `user_group_privilege` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_user`
--

DROP TABLE IF EXISTS `user_group_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_group_user` (
  `user_group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`user_group_id`),
  KEY `user_group_user_user_group_id_foreign` (`user_group_id`),
  CONSTRAINT `user_group_user_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_group` (`user_group_id`),
  CONSTRAINT `user_group_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_user`
--

LOCK TABLES `user_group_user` WRITE;
/*!40000 ALTER TABLE `user_group_user` DISABLE KEYS */;
INSERT INTO `user_group_user` VALUES (1,2);
/*!40000 ALTER TABLE `user_group_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version`
--

DROP TABLE IF EXISTS `version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `version` (
  `version` decimal(5,2) DEFAULT NULL,
  `installDate` date DEFAULT NULL,
  `ENT` varchar(5) DEFAULT 'F',
  `minimum_version` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
INSERT INTO `version` VALUES (0.00,NULL,'F',0.00);
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vial`
--

DROP TABLE IF EXISTS `vial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vial` (
  `vial_id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(45) DEFAULT NULL,
  `outdate` date DEFAULT NULL,
  `mixdate` datetime DEFAULT NULL,
  `traylocation` varchar(45) DEFAULT NULL,
  `bottleNote` varchar(255) DEFAULT NULL,
  `postponed` varchar(10) NOT NULL DEFAULT 'F',
  `mixAfter` date DEFAULT NULL,
  `labelOutdate` date DEFAULT NULL,
  `transaction` int(11) DEFAULT '0',
  `cost` decimal(6,2) DEFAULT '0.00',
  `diltPos` varchar(10) DEFAULT '',
  `sterilityStart` date DEFAULT '2001-03-01',
  `sterilityEnd` date DEFAULT '2001-03-01',
  `shipDate` date DEFAULT '2001-03-01',
  `approvalDate` date DEFAULT '2001-03-01',
  `treatment_plan_id` int(11) DEFAULT NULL,
  `dosing_id` int(11) NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `compound_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`vial_id`),
  KEY `fk_dosing_id_idx` (`dosing_id`),
  KEY `fk_inventory_id_idx` (`inventory_id`),
  KEY `fk_compund_id_idx` (`compound_id`),
  KEY `fk_user_id_idx` (`user_id`),
  KEY `idx_vial_postponed` (`postponed`),
  CONSTRAINT `fk_compound_id` FOREIGN KEY (`compound_id`) REFERENCES `compound` (`compound_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_dosing_id` FOREIGN KEY (`dosing_id`) REFERENCES `dosing` (`dosing_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_inventory_id` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vial`
--

LOCK TABLES `vial` WRITE;
/*!40000 ALTER TABLE `vial` DISABLE KEYS */;
INSERT INTO `vial` VALUES (1,'100000','2019-02-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2019-02-01',800000,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,7,8,1,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(2,'100000','2019-02-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2019-02-01',800000,0.00,'2','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,8,9,1,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(3,'100000','2019-02-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2019-02-01',800000,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,9,3,1,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(4,'100000','2019-02-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2019-02-01',800000,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,10,4,1,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(5,'100001','2018-11-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-11-01',800000,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,7,8,2,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(6,'100001','2018-11-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-11-01',800000,0.00,'2','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,8,9,2,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(7,'100001','2018-11-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-11-01',800000,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,9,3,2,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(8,'100001','2018-11-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-11-01',800000,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,10,4,2,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(9,'100002','2018-08-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-08-01',800000,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,7,8,3,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(10,'100002','2018-08-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-08-01',800000,0.00,'2','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,8,9,3,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(11,'100002','2018-08-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-08-01',800000,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,9,3,3,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(12,'100002','2018-08-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-08-01',800000,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,10,4,3,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(13,'100003','2018-05-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-05-01',800000,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,7,8,4,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(14,'100003','2018-05-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-05-01',800000,0.00,'2','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,8,9,4,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(15,'100003','2018-05-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-05-01',800000,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,9,3,4,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(16,'100003','2018-05-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-05-01',800000,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,10,4,4,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(17,'100004','2018-05-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-05-01',800000,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,7,8,5,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(18,'100004','2018-05-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-05-01',800000,0.00,'2','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,8,9,5,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(19,'100004','2018-05-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-05-01',800000,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,9,3,5,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(20,'100004','2018-05-01','2018-02-01 00:00:00','',NULL,'F','2018-01-13','2018-05-01',800000,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,10,4,5,2,'2018-02-06 19:02:52',NULL,'2018-01-13 21:50:46',NULL),(21,'100005','2001-01-01','2018-06-03 09:30:55','Different location',NULL,'T','2018-06-03','2001-01-01',800001,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,11,8,6,2,'2018-06-03 16:30:56',NULL,'2018-06-03 16:30:55',NULL),(22,'100005','2001-01-01','2018-06-03 09:30:55','Different location',NULL,'T','2018-06-03','2001-01-01',800001,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,12,9,6,2,'2018-06-03 16:30:56',NULL,'2018-06-03 16:30:55',NULL),(23,'100005','2001-01-01','2018-06-03 09:30:55','Different location',NULL,'T','2018-06-03','2001-01-01',800001,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,13,3,6,2,'2018-06-03 16:30:56',NULL,'2018-06-03 16:30:55',NULL),(24,'100005','2001-01-01','2018-06-03 09:30:55','Different location',NULL,'T','2018-06-03','2001-01-01',800001,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,14,4,6,2,'2018-06-03 16:30:56',NULL,'2018-06-03 16:30:55',NULL),(25,'100006','2001-01-01','2018-06-03 09:30:55','Different location',NULL,'T','2018-06-03','2001-01-01',800001,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,11,8,7,2,'2018-06-03 16:30:56',NULL,'2018-06-03 16:30:56',NULL),(26,'100006','2001-01-01','2018-06-03 09:30:55','Different location',NULL,'T','2018-06-03','2001-01-01',800001,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,12,9,7,2,'2018-06-03 16:30:56',NULL,'2018-06-03 16:30:56',NULL),(27,'100006','2001-01-01','2018-06-03 09:30:55','Different location',NULL,'T','2018-06-03','2001-01-01',800001,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,13,3,7,2,'2018-06-03 16:30:56',NULL,'2018-06-03 16:30:56',NULL),(28,'100006','2001-01-01','2018-06-03 09:30:55','Different location',NULL,'T','2018-06-03','2001-01-01',800001,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,14,4,7,2,'2018-06-03 16:30:56',NULL,'2018-06-03 16:30:56',NULL),(29,'100007','2001-01-01','2018-06-03 09:30:55','Different location',NULL,'T','2018-06-03','2001-01-01',800001,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,11,8,8,2,'2018-06-03 16:30:56',NULL,'2018-06-03 16:30:56',NULL),(30,'100007','2001-01-01','2018-06-03 09:30:55','Different location',NULL,'T','2018-06-03','2001-01-01',800001,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,12,9,8,2,'2018-06-03 16:30:56',NULL,'2018-06-03 16:30:56',NULL),(31,'100007','2001-01-01','2018-06-03 09:30:55','Different location',NULL,'T','2018-06-03','2001-01-01',800001,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,13,3,8,2,'2018-06-03 16:30:56',NULL,'2018-06-03 16:30:56',NULL),(32,'100007','2001-01-01','2018-06-03 09:30:55','Different location',NULL,'T','2018-06-03','2001-01-01',800001,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',NULL,14,4,8,2,'2018-06-03 16:30:56',NULL,'2018-06-03 16:30:56',NULL),(33,'100008',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,17,10,9,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(34,'100009',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,18,10,9,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(35,'100010',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,19,10,9,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(36,'100011',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,20,10,10,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(37,'100012',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,21,10,10,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(38,'100013',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,22,10,10,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(39,'100014',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,23,10,11,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(40,'100015',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,24,10,11,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(41,'100016',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,25,10,11,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(42,'100017',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,26,10,12,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(43,'100018',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,27,10,12,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(44,'100019',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,28,10,12,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(45,'100020',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'0','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,29,10,13,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(46,'100021',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'1','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,30,10,13,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2),(47,'100022',NULL,NULL,NULL,NULL,'T',NULL,NULL,800002,0.00,'','2001-03-01','2001-03-01','2001-03-01','2001-03-01',-1,31,10,13,2,'0000-00-00 00:00:00',NULL,'2018-10-08 20:24:50',2);
/*!40000 ALTER TABLE `vial` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER auto_fix_treatment_set_transaction BEFORE INSERT ON `vial`
    FOR EACH ROW BEGIN
      IF ((select transaction from treatment_set, compound where NEW.compound_id = compound.compound_id and compound.treatment_set_id=treatment_set.treatment_set_id) IS NULL) THEN
        update treatment_set, compound set transaction = new.transaction where NEW.compound_id = compound.compound_id and compound.treatment_set_id=treatment_set.treatment_set_id;
      END IF;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `xis_log`
--

DROP TABLE IF EXISTS `xis_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xis_log` (
  `xis_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(256) DEFAULT NULL,
  `userName` varchar(45) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `compName` varchar(100) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `prescription_id` int(11) DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`xis_log_id`),
  KEY `fk_xis_log_prescription_idx` (`prescription_id`),
  KEY `fk_xis_log_patient_idx` (`patient_id`),
  CONSTRAINT `fk_xis_log_patient1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_xis_log_prescription1` FOREIGN KEY (`prescription_id`) REFERENCES `prescription` (`prescription_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xis_log`
--

LOCK TABLES `xis_log` WRITE;
/*!40000 ALTER TABLE `xis_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `xis_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xisprefs`
--

DROP TABLE IF EXISTS `xisprefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xisprefs` (
  `prefSet1` varchar(45) DEFAULT NULL,
  `prefSet2` varchar(45) DEFAULT NULL,
  `prefSet3` varchar(45) DEFAULT NULL,
  `waitTime` decimal(5,2) DEFAULT '20.00',
  `boxNames` varchar(500) DEFAULT 'SYSTEMIC,ASTHMA,MEDICARE',
  `reactNamesS` varchar(500) DEFAULT 'F,T',
  `reactNamesL` varchar(500) DEFAULT 'F,T',
  `accInt` decimal(1,0) DEFAULT '4',
  `loginPIN` int(11) NOT NULL DEFAULT '1111'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xisprefs`
--

LOCK TABLES `xisprefs` WRITE;
/*!40000 ALTER TABLE `xisprefs` DISABLE KEYS */;
INSERT INTO `xisprefs` VALUES ('T,F,F,F,F,F,F,F,F,F','F,F,F,F,F,F,F,F,F,F','F,F,F,F,F,F,F,F,F,F',20.00,'SYSTEMIC,ASTHMA,MEDICARE','N,Y','None,Dime,Nickel,Quarter',4,1111);
/*!40000 ALTER TABLE `xisprefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xisversion`
--

DROP TABLE IF EXISTS `xisversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xisversion` (
  `version` decimal(5,2) NOT NULL,
  `installDate` date DEFAULT NULL,
  `ENT` varchar(5) DEFAULT 'F',
  `xpsExist` tinyint(4) DEFAULT NULL,
  `xpsLocal` tinyint(4) DEFAULT NULL,
  `xpsAddr` varchar(45) DEFAULT NULL,
  `minimum_version` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xisversion`
--

LOCK TABLES `xisversion` WRITE;
/*!40000 ALTER TABLE `xisversion` DISABLE KEYS */;
INSERT INTO `xisversion` VALUES (0.00,NULL,'F',NULL,NULL,NULL,0.00);
/*!40000 ALTER TABLE `xisversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xps_log`
--

DROP TABLE IF EXISTS `xps_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xps_log` (
  `xps_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(256) DEFAULT NULL,
  `userName` varchar(45) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `compName` varchar(100) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `prescription_id` int(11) DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`xps_log_id`),
  KEY `fk_xps_log_prescription_idx` (`prescription_id`),
  KEY `fk_xps_log_patient_idx` (`patient_id`),
  CONSTRAINT `fk_xps_log_patient1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_xps_log_prescription1` FOREIGN KEY (`prescription_id`) REFERENCES `prescription` (`prescription_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xps_log`
--

LOCK TABLES `xps_log` WRITE;
/*!40000 ALTER TABLE `xps_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `xps_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xpsprefs`
--

DROP TABLE IF EXISTS `xpsprefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xpsprefs` (
  `priority_names` varchar(500) DEFAULT NULL,
  `prefset1` varchar(500) DEFAULT NULL,
  `halocolors` varchar(500) DEFAULT '6618880,15750402'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xpsprefs`
--

LOCK TABLES `xpsprefs` WRITE;
/*!40000 ALTER TABLE `xpsprefs` DISABLE KEYS */;
INSERT INTO `xpsprefs` VALUES ('PENDED,SIGNED,PREVERIFIED,FILL,VERIFIED,CMD','T,F,F,F,F,F,F,F,F,F','6618880,16750402');
/*!40000 ALTER TABLE `xpsprefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xst_log`
--

DROP TABLE IF EXISTS `xst_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xst_log` (
  `xst_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(256) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `compName` varchar(100) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `prescription_id` int(11) DEFAULT NULL,
  `error` text,
  `skintest_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`xst_log_id`),
  KEY `fk_xst_log_prescription_idx` (`prescription_id`),
  KEY `fk_xst_log_patient_idx` (`patient_id`),
  CONSTRAINT `fk_xst_log_patient1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_xst_log_prescription1` FOREIGN KEY (`prescription_id`) REFERENCES `prescription` (`prescription_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xst_log`
--

LOCK TABLES `xst_log` WRITE;
/*!40000 ALTER TABLE `xst_log` DISABLE KEYS */;
INSERT INTO `xst_log` VALUES (1,'login','Xtract Admin','2018-01-18 09:52:05',NULL,NULL,NULL,'',NULL),(2,'view patient','Xtract Admin','2018-01-18 09:52:10',NULL,NULL,NULL,'',NULL),(3,'view patient','Xtract Admin','2018-01-18 09:52:24',NULL,2,NULL,'',NULL),(4,'new skin test','Xtract Admin','2018-01-18 09:52:42',NULL,2,NULL,'',1),(5,'view skin test','Xtract Admin','2018-01-18 09:52:46',NULL,2,NULL,'',1),(6,'test scores updated','Xtract Admin','2018-01-18 09:52:57',NULL,2,NULL,'',1),(7,'login','Xtract Admin','2018-02-06 11:00:46',NULL,NULL,NULL,'',NULL),(8,'view patient','Xtract Admin','2018-02-06 11:00:48',NULL,2,NULL,'',NULL),(9,'edit config: XST, ALL, receiving, enabled','Xtract Admin','2018-02-06 11:02:30',NULL,NULL,NULL,'',NULL),(10,'view patient','Xtract Admin','2018-02-06 11:02:35',NULL,2,NULL,'',NULL),(11,'login','Xtract Admin','2018-06-03 09:29:55','Martin-PC',NULL,NULL,'',NULL),(12,'view patient','Xtract Admin','2018-06-03 09:29:59','Martin-PC',2,NULL,'',NULL);
/*!40000 ALTER TABLE `xst_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xstprefs`
--

DROP TABLE IF EXISTS `xstprefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xstprefs` (
  `section` varchar(128) NOT NULL,
  `entry` varchar(128) NOT NULL,
  `value` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`section`,`entry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xstprefs`
--

LOCK TABLES `xstprefs` WRITE;
/*!40000 ALTER TABLE `xstprefs` DISABLE KEYS */;
INSERT INTO `xstprefs` VALUES ('license','skintest','T','2018-01-18 17:52:00'),('recent_patients','2','2,','2018-01-18 17:52:24'),('recent_search_type','2','last','2018-01-18 17:52:07'),('scoring_code','Simple','{\"name\":\"Simple\",\"score_column\":3,\"version\":2,\"cols\":[{\"name\":\"W1\",\"report_name\":\"Wheal 1\",\"width\":35,\"color\":\"#e5e8f4\"},{\"name\":\"W2\",\"report_name\":\"Wheal 2\",\"width\":35,\"color\":\"#e5f4e5\"},{\"name\":\"Score\",\"report_name\":\"Score\",\"width\":50,\"is_score\":true}],\"scoring_code\":\"\\/\\/ Very simple method\\r\\n\\r\\nfunction ScoreProtocol(parms) {\\r\\n\\t\\\"use strict\\\";\\r\\n\\t\\r\\n\\tvar context = parms;\\r\\n\\t\\r\\n\\t\\/\\/ define column names\\r\\n\\tvar wheal1Col = 1, wheal2Col = 2, scoreCol = 3;\\r\\n\\r\\n\\tvar wheal1Val\\t= function (v) { return context.cell_value(wheal1Col, v); };\\r\\n\\tvar wheal2Val\\t= function (v) { return context.cell_value(wheal2Col, v); };\\r\\n\\tvar scoreVal\\t= function (v) { return context.cell_value(scoreCol, v); };\\r\\n\\t\\r\\n\\tfunction changeScore (key, col, colcount, isControl){\\r\\n\\t\\t\\/\\/ the user has entered a key in a column, adjust score accordingly\\r\\n\\t\\t\\r\\n\\t\\tif (key == \'0\' && ((col == wheal1Col || col == wheal2Col))){\\r\\n\\t\\t\\tif (col == wheal2Col){\\r\\n\\t\\t\\t\\tcol--;\\r\\n\\t\\t\\t}\\r\\n\\t\\t\\tvar count = 0;\\r\\n\\t\\t\\twhile (count < colcount){\\r\\n\\t\\t\\t\\tvar tmp = col + count;\\r\\n\\t\\t\\t\\tcontext.cell_value(tmp,0);\\r\\n\\t\\t\\t\\tcount++;\\r\\n\\t\\t\\t}\\r\\n\\t\\t\\tcol = colcount + 1;\\r\\n\\t\\t}\\r\\n\\t\\telse{\\r\\n\\t\\t\\tcontext.cell_value(col, key);\\r\\n\\t\\t\\tif (col == wheal1Col || col == wheal2Col){\\r\\n\\t\\t\\t\\tvar a = wheal1Val();\\r\\n\\t\\t\\t\\tvar b = wheal2Val();\\r\\n\\t\\t\\t\\tvar total = a\\/2*b\\/2*Math.PI;\\t\\/\\/do scoring calculations\\r\\n\\t\\t\\t\\t\\r\\n\\t\\t\\t\\tif ((total >= 0) && (total < 10)){\\r\\n\\t\\t\\t\\t\\tscoreVal(\'0\');\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse if ((total >= 10) && (total < 100)){\\r\\n\\t\\t\\t\\t\\tscoreVal(\'1\');\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse if ((total >= 100) && (total < 200)){\\r\\n\\t\\t\\t\\t\\tscoreVal(\'2\');\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse if ((total >= 200) && (total < 300)){\\r\\n\\t\\t\\t\\t\\tscoreVal(\'3\');\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse if (total >= 300){\\r\\n\\t\\t\\t\\t\\tscoreVal(\'4\');\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse{\\r\\n\\t\\t\\t\\t\\tscoreVal(\'Err\');\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\t\\r\\n\\t\\t\\t\\tif (col == wheal1Col){\\r\\n\\t\\t\\t\\t\\tcol += 1;\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse{\\r\\n\\t\\t\\t\\t\\tcol += 2;\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t}\\r\\n\\t\\t}\\r\\n\\t\\t\\r\\n\\t\\tcontext.move_to(col);\\r\\n\\t}\\r\\n\\r\\n\\treturn {\\r\\n\\t\\tversion: function () {\\r\\n\\t\\t\\treturn \\\"2.0\\\"\\r\\n\\t\\t},\\r\\n\\t\\t\\r\\n\\t\\tscoreFormatCol: function (col, value){\\r\\n\\t\\t\\t\\/\\/ given a col number and a value, return a formatted string \\r\\n\\t\\t\\t\\r\\n\\t\\t\\tif (value === null || value === \'\'){\\r\\n\\t\\t\\t\\treturn \'\';\\r\\n\\t\\t\\t}\\r\\n\\t\\t\\t\\r\\n\\t\\t\\tif (col  ==  scoreCol && value > 0){\\r\\n\\t\\t\\t\\treturn value + \'+\';\\r\\n\\t\\t\\t}\\r\\n\\t\\t\\t\\r\\n\\t\\t\\treturn value;\\r\\n\\t\\t},\\r\\n\\t\\t\\r\\n\\t\\tscoreParseCol: function (col, value){\\r\\n\\t\\t\\t\\/\\/ given a col number and a string, parse the string and return a numeric value \\r\\n\\t\\t\\t\\r\\n\\t\\t\\treturn value == \'\' ? \'\' : parseFloat (value);\\r\\n\\t\\t},\\r\\n\\t\\t\\r\\n\\t\\tscoreKey: function (key, col, colcount, isControl, row){\\r\\n\\t\\t\\tif (col == wheal1Col || col == wheal2Col){\\r\\n\\t\\t\\t\\tif (context.cell_value(col) !== \'\' && (key === \'\' || parseInt(key) !== context.cell_value(col))){\\r\\n\\t\\t\\t\\t\\tcontext.confirm_change (context.cell_value(col), key, isControl, changeScore, row);\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\telse{\\r\\n\\t\\t\\t\\t\\tchangeScore (key, col, colcount, isControl);\\r\\n\\t\\t\\t\\t}\\r\\n\\t\\t\\t}\\r\\n\\t\\t}\\r\\n\\t}\\r\\n}\\r\\n\"}','2018-01-18 17:51:59'),('session_timeout','default','30','2016-08-08 22:40:48'),('session_warning_timeout','default','1','2016-08-08 22:40:48'),('test_timer_default','default','20','2016-08-08 22:40:48'),('test_timer_options','default','5, 10, 15, 20, 25, 30','2016-08-08 22:40:48');
/*!40000 ALTER TABLE `xstprefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xtract_schema`
--

DROP TABLE IF EXISTS `xtract_schema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xtract_schema` (
  `version` varchar(10) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xtract_schema`
--

LOCK TABLES `xtract_schema` WRITE;
/*!40000 ALTER TABLE `xtract_schema` DISABLE KEYS */;
INSERT INTO `xtract_schema` VALUES ('1.06_rc05','2019-03-29 19:29:44');
/*!40000 ALTER TABLE `xtract_schema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'api_test1'
--

--
-- Final view structure for view `antigen_extract`
--

/*!50001 DROP VIEW IF EXISTS `antigen_extract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `antigen_extract` AS select `antigen`.`antigen_id` AS `antigen_id`,`antigen`.`name` AS `name`,`antigen`.`clinic_part_number` AS `clinic_part_number`,`antigen`.`test_order` AS `test_order`,`extract`.`extract_id` AS `extract_id`,`extract`.`latinname` AS `latinname`,`extract`.`manufacturer` AS `manufacturer`,`extract`.`code` AS `code`,`extract`.`ndc` AS `ndc`,`extract`.`abbreviation` AS `abbreviation`,`extract`.`visible` AS `visible`,`extract`.`percentGlycerin` AS `percentGlycerin`,`extract`.`percentPhenol` AS `percentPhenol`,`extract`.`percentHSA` AS `percentHSA`,`extract`.`dilution` AS `dilution`,`extract`.`units` AS `units`,`extract`.`cost` AS `cost`,`extract`.`sub` AS `sub`,`extract`.`specificgravity` AS `specificgravity`,`extract`.`outdatealert` AS `outdatealert`,`extract`.`compatibility_class_id` AS `compatibility_class_id`,`extract`.`imagefile` AS `imagefile`,`extract`.`isDiluent` AS `isDiluent`,`extract`.`silhouette` AS `silhouette`,`extract`.`color` AS `color`,`extract`.`topline` AS `topline`,`extract`.`firstline` AS `firstline`,`extract`.`secondline` AS `secondline`,`extract`.`seasonStart` AS `seasonStart`,`extract`.`seasonEnd` AS `seasonEnd`,ifnull(`extract`.`deleted`,'F') AS `deleted`,`extract`.`updated_at` AS `updated_at`,`extract`.`updated_by` AS `updated_by`,`extract`.`created_at` AS `created_at`,`extract`.`created_by` AS `created_by` from (`antigen` left join `extract` on((`antigen`.`extract_id` = `extract`.`extract_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `compound_non_xps`
--

/*!50001 DROP VIEW IF EXISTS `compound_non_xps`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `compound_non_xps` AS select `c`.`compound_id` AS `compound_id`,`c`.`name` AS `bottle_name`,`e`.`name` AS `bottle_type` from (((`compound` `c` join `vial` `v` on((`v`.`compound_id` = `c`.`compound_id`))) join `inventory` `iv` on((`iv`.`inventory_id` = `v`.`inventory_id`))) join `extract` `e` on((`e`.`extract_id` = `iv`.`extract_id`))) where (`e`.`name` = 'NON-XPS') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `gen2_log`
--

/*!50001 DROP VIEW IF EXISTS `gen2_log`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `gen2_log` AS select `xis_log`.`xis_log_id` AS `xis_log_id`,'' AS `api_log_id`,`xis_log`.`timestamp` AS `timestamp`,`user`.`user_id` AS `user_id`,`xis_log`.`userName` AS `username`,`xis_log`.`event` AS `event`,`xis_log`.`compName` AS `comp`,`xis_log`.`patient_id` AS `patient_id`,`xis_log`.`prescription_id` AS `prescription_id`,`xis_log`.`error` AS `error`,'' AS `response_code` from (`xis_log` left join `user` on((`user`.`displayname` = `xis_log`.`userName`))) union all select '' AS `xis_log_id`,`api_log`.`api_log_id` AS `api_log_id`,`api_log`.`timestamp` AS `timestamp`,`api_log`.`user_id` AS `user_id`,`user`.`displayname` AS `username`,concat(`api_log`.`method`,' - ',`api_log`.`path`) AS `event`,`api_log`.`requester_ip` AS `comp`,'' AS `patient_id`,'' AS `prescription_id`,if((`api_log`.`response_code` = 200),'',`api_log`.`response_code`) AS `error`,`api_log`.`response_code` AS `response_code` from (`api_log` left join `user` on((`user`.`user_id` = `api_log`.`user_id`))) order by `timestamp` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pp_bottles`
--

/*!50001 DROP VIEW IF EXISTS `pp_bottles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pp_bottles` AS select `postpone`.`postpone_id` AS `postpone_id`,(case when (`postpone`.`compound_id1` = '0') then '0' when (`postpone`.`compound_id2` = '0') then `postpone`.`compound_id1` when (`postpone`.`compound_id3` = '0') then concat(`postpone`.`compound_id1`,',',`postpone`.`compound_id2`) when (`postpone`.`compound_id4` = '0') then concat(`postpone`.`compound_id1`,',',`postpone`.`compound_id2`,',',`postpone`.`compound_id3`) when (`postpone`.`compound_id5` = '0') then concat(`postpone`.`compound_id1`,',',`postpone`.`compound_id2`,',',`postpone`.`compound_id3`,',',`postpone`.`compound_id4`) when (`postpone`.`compound_id6` = '0') then concat(`postpone`.`compound_id1`,',',`postpone`.`compound_id2`,',',`postpone`.`compound_id3`,',',`postpone`.`compound_id4`,',',`postpone`.`compound_id5`) when (`postpone`.`compound_id7` = '0') then concat(`postpone`.`compound_id1`,',',`postpone`.`compound_id2`,',',`postpone`.`compound_id3`,',',`postpone`.`compound_id4`,',',`postpone`.`compound_id5`,',',`postpone`.`compound_id6`) when (`postpone`.`compound_id8` = '0') then concat(`postpone`.`compound_id1`,',',`postpone`.`compound_id2`,',',`postpone`.`compound_id3`,',',`postpone`.`compound_id4`,',',`postpone`.`compound_id5`,',',`postpone`.`compound_id6`,',',`postpone`.`compound_id7`) else concat(`postpone`.`compound_id1`,',',`postpone`.`compound_id2`,',',`postpone`.`compound_id3`,',',`postpone`.`compound_id4`,',',`postpone`.`compound_id5`,',',`postpone`.`compound_id6`,',',`postpone`.`compound_id7`,',',`postpone`.`compound_id8`) end) AS `bottles`,`postpone`.`user_id` AS `user_id`,`postpone`.`labelPrinted` AS `labelPrinted`,`postpone`.`deleted` AS `deleted` from `postpone` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `provider_profile`
--

/*!50001 DROP VIEW IF EXISTS `provider_profile`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `provider_profile` AS select `p`.`provider_id` AS `provider_id`,`pc`.`provider_config_id` AS `provider_config_id`,`p`.`displayname` AS `displayname`,`p`.`licensenumber` AS `licensenumber`,`p`.`nonXtract` AS `nonXtract`,`pc`.`profileName` AS `profileName`,`pc`.`numorder` AS `numorder`,`pc`.`profileRate` AS `profileRate`,`pc`.`colorNames` AS `colorNames`,`pc`.`color` AS `color` from (`provider` `p` left join `provider_config` `pc` on((`p`.`provider_id` = `pc`.`provider_id`))) where ((`p`.`deleted` = 'F') and (`pc`.`deleted` = 'F')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pt`
--

/*!50001 DROP VIEW IF EXISTS `pt`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pt` AS select `patient`.`patient_id` AS `patient_id`,`patient`.`firstname` AS `firstname`,`patient`.`lastname` AS `lastname`,`patient`.`mi` AS `mi`,`patient`.`chart` AS `chart`,`patient`.`dob` AS `dob`,`patient`.`displayname` AS `displayname`,`patient`.`gender` AS `gender`,`patient`.`provider_id` AS `provider_id`,`patient`.`archived` AS `archived`,`patient`.`PV1segment` AS `PV1segment`,`patient`.`PIDsegment` AS `PIDsegment`,`patient`.`patient_notes` AS `patient_notes`,`patient`.`ssn` AS `ssn`,`patient`.`addr1` AS `addr1`,`patient`.`city` AS `city`,`patient`.`state` AS `state`,`patient`.`zip` AS `zip`,`patient`.`phone` AS `phone`,`patient`.`smsphone` AS `smsphone` from `patient` order by `patient`.`lastname`,`patient`.`firstname` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pt_provider`
--

/*!50001 DROP VIEW IF EXISTS `pt_provider`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pt_provider` AS select `p1`.`patient_id` AS `patient_id`,`p1`.`firstname` AS `firstname`,`p1`.`lastname` AS `lastname`,`p1`.`chart` AS `chart`,`p1`.`provider_id` AS `provider_id`,`p2`.`displayname` AS `displayname`,`p2`.`last` AS `last`,`p2`.`first` AS `first` from (`patient` `p1` left join `provider` `p2` on((`p1`.`provider_id` = `p2`.`provider_id`))) order by `p1`.`lastname`,`p1`.`firstname`,`p2`.`last` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pt_rx_inj`
--

/*!50001 DROP VIEW IF EXISTS `pt_rx_inj`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pt_rx_inj` AS select `p1`.`patient_id` AS `patient_id`,`p1`.`chart` AS `chart`,`p1`.`firstname` AS `firstname`,`p1`.`lastname` AS `lastname`,`p2`.`provider_id` AS `provider_id`,`p2`.`provider_config_id` AS `provider_config_id`,`p2`.`prescription_id` AS `prescription_id`,`p2`.`prescription_num` AS `prescription_num`,`p2`.`treatment_plan_id` AS `rx_treatment_plan_id`,`c`.`compound_id` AS `compound_id`,`c`.`name` AS `BottleName`,`c`.`size` AS `size`,`c`.`color` AS `color`,`c`.`dilution` AS `dilution`,`c`.`bottleNum` AS `bottleNum`,`c`.`active` AS `active`,`c`.`currVol` AS `currVol`,`i`.`injection_id` AS `injection_id`,`i`.`dose` AS `dose`,`i`.`site` AS `site`,`i`.`date` AS `injection_date`,`i`.`user_id` AS `user_id`,`i`.`inj_adjust_id` AS `inj_adjust_id`,`i`.`reaction` AS `reaction`,`i`.`sysreaction` AS `sysreaction`,`i`.`timestamp` AS `timestamp`,`i`.`treatment_plan_id` AS `inj_treatment_plan_id` from (((`patient` `p1` left join `prescription` `p2` on((`p1`.`patient_id` = `p2`.`patient_id`))) left join `compound` `c` on((`p2`.`prescription_id` = `c`.`rx_id`))) left join `injection` `i` on((`c`.`compound_id` = `i`.`compound_id`))) where (`i`.`deleted` = 'F') order by `p1`.`lastname`,`p1`.`firstname`,`p2`.`prescription_num`,`c`.`dilution`,`i`.`date` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pt_rx_provider`
--

/*!50001 DROP VIEW IF EXISTS `pt_rx_provider`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pt_rx_provider` AS select `p1`.`patient_id` AS `patient_id`,`p1`.`firstname` AS `firstname`,`p1`.`lastname` AS `lastname`,`p1`.`chart` AS `chart`,`p2`.`prescription_id` AS `prescription_id`,`p2`.`prescription_num` AS `prescription_num`,`p2`.`provider_id` AS `provider_id`,`p3`.`displayname` AS `displayname`,`p3`.`last` AS `last`,`p3`.`first` AS `first`,max(`i`.`date`) AS `last_injection` from ((((`patient` `p1` left join `prescription` `p2` on((`p1`.`patient_id` = `p2`.`patient_id`))) left join `provider` `p3` on((`p2`.`provider_id` = `p3`.`provider_id`))) left join `compound` `c` on((`p2`.`prescription_id` = `c`.`rx_id`))) left join `injection` `i` on((`c`.`compound_id` = `i`.`compound_id`))) group by `p2`.`prescription_id` order by `p1`.`lastname`,`p1`.`firstname`,`p2`.`prescription_num` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rx_bottles`
--

/*!50001 DROP VIEW IF EXISTS `rx_bottles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rx_bottles` AS select `prescription`.`prescription_id` AS `prescription_id`,`prescription`.`prescription_num` AS `prescription_num`,group_concat(`c`.`compound_id` separator ',') AS `bottles`,`prescription`.`user_id` AS `user_id`,`prescription`.`strikethrough` AS `strikethrough`,`prescription`.`priority` AS `priority` from (`prescription` left join `compound` `c` on((`prescription`.`prescription_id` = `c`.`rx_id`))) group by `prescription`.`prescription_num` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rx_co_vi_pt`
--

/*!50001 DROP VIEW IF EXISTS `rx_co_vi_pt`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rx_co_vi_pt` AS select `v`.`mixdate` AS `mixdate`,`p2`.`prescription_id` AS `rx_id`,`p2`.`prescription_num` AS `rx_num`,`p2`.`strikethrough` AS `strikethrough`,`p2`.`treatment_plan_id` AS `treatment_plan_id`,`c`.`compound_id` AS `compound_id`,`c`.`compound_receipt_id` AS `compound_receipt_id`,`c`.`name` AS `VialName`,`c`.`size` AS `size`,`c`.`color` AS `color`,`c`.`dilution` AS `dilution`,`c`.`bottleNum` AS `bottleNum`,`c`.`active` AS `active`,`c`.`currVol` AS `currVol`,`v`.`barcode` AS `barcode`,`v`.`dosing_id` AS `dosing_id`,`v`.`inventory_id` AS `inventory_id`,`p1`.`patient_id` AS `patient_id`,`p1`.`lastname` AS `lastname` from (((`prescription` `p2` left join `patient` `p1` on((`p1`.`patient_id` = `p2`.`patient_id`))) left join `compound` `c` on((`p2`.`prescription_id` = `c`.`rx_id`))) left join `vial` `v` on((`c`.`compound_id` = `v`.`compound_id`))) order by `p2`.`prescription_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rx_extract`
--

/*!50001 DROP VIEW IF EXISTS `rx_extract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rx_extract` AS select `prescription`.`prescription_id` AS `rx_id`,`prescription`.`prescription_num` AS `prescription_num`,`extract`.`name` AS `name`,`extract`.`dilution` AS `dilution`,`dosing`.`dose` AS `dose`,`extract`.`extract_id` AS `extract_id`,`extract`.`deleted` AS `deleted`,`extract`.`abbreviation` AS `abbreviation`,`extract`.`latinname` AS `latinname`,`extract`.`manufacturer` AS `manufacturer`,`extract`.`code` AS `code`,`extract`.`isDiluent` AS `isDiluent`,`extract`.`percentGlycerin` AS `percentGlycerin`,`extract`.`percentPhenol` AS `percentPhenol`,`extract`.`percentHSA` AS `percentHSA`,`extract`.`units` AS `units`,`extract`.`seasonStart` AS `seasonStart`,`extract`.`seasonEnd` AS `seasonEnd`,`extract`.`cost` AS `cost`,`extract`.`sub` AS `sub`,`extract`.`specificgravity` AS `specificgravity`,`extract`.`outdatealert` AS `outdatealert`,`extract`.`visible` AS `visible`,`extract`.`imagefile` AS `imagefile`,`extract`.`color` AS `color`,`extract`.`silhouette` AS `silhouette`,`extract`.`topline` AS `topline`,`extract`.`firstline` AS `firstline`,`extract`.`secondline` AS `secondline`,`extract`.`compatibility_class_id` AS `compatibility_class_id` from ((`dosing` join `extract`) join `prescription`) where ((`dosing`.`extract_id` = `extract`.`extract_id`) and (`dosing`.`prescription_id` = `prescription`.`prescription_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-29 15:33:54
